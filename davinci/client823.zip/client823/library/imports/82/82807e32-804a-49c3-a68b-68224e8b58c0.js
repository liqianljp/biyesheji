"use strict";
cc._RF.push(module, '828074ygEpJw6aLaCJOi1jA', 'GameOver');
// Script/GameOver.js

"use strict";

var http = require("HttpUtils");
var card = require("CardActivity");
var userdata = require("UserData");
var soket = require("SoketUtils");

cc.Class({
    extends: cc.Component,
    properties: {},

    // use this for initialization
    onLoad: function onLoad() {},

    //点击返回大厅按钮
    BackToHall: function BackToHall() {
        var self = this;
        http.isBackToHall = true;
        soket.close_ws();
        cc.director.loadScene("HallScene");
    },

    //点击再来一局按钮
    ReMatchGame: function ReMatchGame() {
        //关闭上一局游戏的http和socket,跳转到大厅
        var self = this;
        http.isBackToHall = true;
        soket.close_ws();
        cc.director.loadScene("HallScene");
        //马上执行快速匹配对手
        var hall = self.node.getComponent("HallScene");
        hall.FindPlayer();
    }
});

cc._RF.pop();