"use strict";
cc._RF.push(module, '3f50fzXhZ9GqrfsDfSWh5QB', 'CardMgr');
// Script/CardMgr.js

"use strict";

//根据位置，牌的颜色，牌的点数获取相应牌的图片
var cardSprites = []; //卡牌精灵数组
cc.Class({
    extends: cc.Component,

    properties: {
        leftAtlas: { //左边玩家卡牌图片信息
            default: null,
            type: cc.SpriteAtlas
        },

        rightAtlas: { //右边玩家卡牌图片信息
            default: null,
            type: cc.SpriteAtlas
        },

        oppositeAtlas: { //对面玩家卡牌图片信息
            default: null,
            type: cc.SpriteAtlas
        },

        myselfAtlas: { //自己玩家卡牌图片信息
            default: null,
            type: cc.SpriteAtlas
        },

        unknownAtlas: { //未知卡牌图片信息
            default: null,
            type: cc.SpriteAtlas
        },

        _sides: null,
        _pres: null,
        cardSprites: null

    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        self._sides = ["myself", "right", "opposite", "left"];
        self._pres = ["M_", "R_", "O_", "L_"];

        //卡牌点数
        for (var i = 0; i < 14; ++i) {
            cardSprites.push(i); //0~11存储0~11点牌，12存万能牌，13存储未知牌
        }
    },

    //通过牌的点数获取对应图片的点数
    getCardSpriteByID: function getCardSpriteByID(id) {
        return cardSprites[id];
    },

    //通过牌的颜色获取牌的类型
    getCardType: function getCardType(color) {
        var str = "";
        if (color == "white") {
            str = "whitecard_";
            return str;
        }
        if (color == "black") {
            str = "blackcard_";
            return str;
        }
    },

    //通过前缀，颜色类型和点数得到卡牌图片的名字
    getSpriteFrameByCardID: function getSpriteFrameByCardID(pre, color, cardId) {
        var type = this.getCardType(color);
        var spriteFrameName = this.getCardSpriteByID(cardId);
        spriteFrameName = pre + type + spriteFrameName;
        if (pre == "M_") {
            if (cardId == 12) {
                spriteFrameName = pre + type + " random";
                return this.myselfAtlas.getSpriteFrame(spriteFrameName);
            } else if (cardId == 13) {
                //自己的手牌没有13点，即未知牌
                return null;
            } else {
                spriteFrameName = pre + type + cardId;
                return this.myselfAtlas.getSpriteFrame(spriteFrameName);
            }
        } else if (pre == "O_") {
            if (cardId == 12) {
                spriteFrameName = pre + type + " random";
                return this.oppositeAtlas.getSpriteFrame(spriteFrameName);
            } else if (cardId == 13) {
                spriteFrameName = pre + type + "unk";
                return this.oppositeAtlas.getSpriteFrame(spriteFrameName);
            } else {
                spriteFrameName = pre + type + cardId;
                return this.oppositeAtlas.getSpriteFrame(spriteFrameName);
            }
        } else if (pre == "L_") {
            if (cardId == 12) {
                spriteFrameName = pre + type + " random";
                return this.leftAtlas.getSpriteFrame(spriteFrameName);
            } else if (cardId == 13) {
                spriteFrameName = pre + type + "unk";
                return this.leftAtlas.getSpriteFrame(spriteFrameName);
            } else {
                spriteFrameName = pre + type + cardId;
                return this.leftAtlas.getSpriteFrame(spriteFrameName);
            }
        } else if (pre == "R_") {
            if (cardId == 12) {
                spriteFrameName = pre + type + " random";
                return this.rightAtlas.getSpriteFrame(spriteFrameName);
            } else if (cardId == 13) {
                spriteFrameName = pre + type + "unk";
                return this.rightAtlas.getSpriteFrame(spriteFrameName);
            } else {
                spriteFrameName = pre + type + cardId;
                return this.rightAtlas.getSpriteFrame(spriteFrameName);
            }
        }
    }

});

cc._RF.pop();