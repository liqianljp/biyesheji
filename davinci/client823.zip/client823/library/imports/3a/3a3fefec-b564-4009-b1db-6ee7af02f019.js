"use strict";
cc._RF.push(module, '3a3fe/stWRACbHbbuevAvAZ', 'HallScene');
// Script/HallScene.js

"use strict";

var http = require("HttpUtils");
var card = require("CardActivity");
var userdata = require("UserData");
var soket = require("SoketUtils");
cc.Class({
    extends: cc.Component,

    properties: {
        help_ui: cc.Prefab,
        game_num: {
            default: null,
            type: cc.Node
        },
        playerID: null

    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        //刚进入游戏大厅就要申请登陆好友系统
        self.LoginFriendSystem();
    },

    //申请登陆好友系统
    LoginFriendSystem: function LoginFriendSystem() {
        var self = this;
        var content = JSON.stringify({ Id: userdata.id,
            Type: 10041,
            Name: userdata.mname
        });

        cc.log("向好友服务器发送申请登陆消息：");
        cc.log(JSON.parse(content));
        soket.connect(); //建立websoket对象ws
        soket.ws.onopen = function () {
            soket.getChatMsg();
            soket.ws.send(content); //发送消息
        };
    },

    //点击back_to_login按钮，返回到登陆界面
    ToWelcomeScene: function ToWelcomeScene() {
        cc.director.loadScene('WelcomeScene');
    },

    //点击match按钮，向服务器发送命令，快速匹配对手
    FindPlayer: function FindPlayer() {
        var self = this;
        http.isBackToHall = false;
        var url = "http://192.168.0.229:8080/test";
        var params1 = JSON.stringify({ Id: userdata.id,
            "Content": { "Type": 10008, "Uid": "666" } });
        var msg = "msg=" + params1;
        cc.log("点击快速匹配按钮发送消息：" + msg);
        http.HttpPost(url, msg, function (rv_mes) {
            if (rv_mes === -1) {
                cc.log('请检查网络');
            } else {
                cc.log("返回信息：" + rv_mes);
                rv_mes = JSON.parse(rv_mes);
                if (rv_mes.Type === 10010) {
                    cc.log('服务器拒绝开始请求，匹配队列已满 ：' + rv_mes.Type);
                } else if (rv_mes.Type === 10009) {
                    cc.log('服务器收到开始请求，进入匹配队列 ：' + rv_mes.Type);
                    self.Polling();
                }
            }
        });
    },

    //点击帮助按钮弹，出帮助浮框
    HelpTips: function HelpTips() {
        var self = this;
        var helptips_ui = cc.instantiate(self.help_ui);
        helptips_ui.parent = self.node;
        helptips_ui.setPosition(0, 0);
    },

    //点击快速需找对手按钮，弹出游戏模式选择框（可选）
    GameModelSelect: function GameModelSelect() {
        var self = this;
    },

    //下面实现，客户端在接受到允许进入匹配队列后，开始轮询请求
    //请求匹配玩家时，轮询请求函数.
    //当返回的值等于10014(找到对手)时，不反复执行此函数
    //当返回的值等于10015(未找到对手)时，在一定时间内反复执行此函数
    Polling: function Polling() {
        var self = this;
        var url = "http://192.168.0.229:8080/test";
        var params = JSON.stringify({ Id: userdata.id,
            "Content": { "Type": 10013 } });
        var msg = "msg=" + params;
        cc.log("匹配轮询时发送消息：" + msg);
        http.HttpPost(url, msg, function (rv_mes) {
            if (rv_mes === -1) {
                cc.log('请检查网络！');
            } else {
                rv_mes = JSON.parse(rv_mes);
                cc.log(rv_mes);
                if (rv_mes.Type === 10015) {
                    setTimeout(function () {
                        self.Polling();
                    }, 1000);
                    cc.log("未找到对手");
                } else if (rv_mes.Type === 10014) {
                    userdata.restBlackCount = rv_mes.RestCard.black;
                    userdata.restWhiteCount = rv_mes.RestCard.white;
                    card.Init_four_players(rv_mes);
                    cc.log("找到对手");
                    //向聊天服务器发送请求连接聊天室
                    userdata.chatRoomKey = rv_mes.Key;
                    setTimeout(function () {
                        cc.director.loadScene("WaitingGameScene");
                    }, 1000);
                }
            }
        });
    },

    update: function update(dt) {
        var self = this;
        soket.getChatMsg();
    }
});

cc._RF.pop();