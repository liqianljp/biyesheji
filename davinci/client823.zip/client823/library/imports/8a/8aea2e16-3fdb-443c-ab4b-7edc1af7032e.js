"use strict";
cc._RF.push(module, '8aea24WP9tEPKtLftwa9wMu', 'FloatingBox');
// Script/FloatingBox.js

"use strict";

var soket = require("SoketUtils");
var userdata = require("UserData");
cc.Class({
    extends: cc.Component,
    properties: {
        floatingBox: { //浮框显示
            default: null,
            type: cc.Node
        },
        IsDisplay: null,
        askingButton: { //
            default: null,
            type: cc.Node
        }
    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        self.IsDisplay = false;
    },

    //弹出浮框
    ShowFloatingBox: function ShowFloatingBox() {
        var self = this;
        if (self.IsDisplay == false) {
            self.IsDisplay = true;
        } else if (self.IsDisplay == true) {
            self.IsDisplay = false;
        }

        if (self.IsDisplay == true) {
            self.floatingBox.active = true;
        } else if (self.IsDisplay == false) {
            self.floatingBox.active = false;
        }
    },

    //关闭浮框
    CloseFloatingBox: function CloseFloatingBox() {
        var self = this;
        self.floatingBox.active = false;
        self.IsDisplay = false;
        userdata.selectedMailID = null;
    },

    //
    update: function update(dt) {
        var self = this;
        //  if(userdata.askingFriendInfo!=null&&userdata.askingFriendInfo.length!=0){
        //     self.askingButton.color = new cc.Color(0,191,255);
        // }else{
        //     self.askingButton.color = new cc.Color(255,255,255,255); 
        // }
    }
});

cc._RF.pop();