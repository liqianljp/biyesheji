"use strict";
cc._RF.push(module, 'cdabbzxdQ1DoLhZ/EccETbj', 'HelpTips');
// Script/HelpTips.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        helpbg: { //help弹出框的背景
            default: null,
            type: cc.Node
        }
    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        self.helpbg.on('touchstart', self.eatTouch, self);
    },

    eatTouch: function eatTouch(event) {
        cc.log('eatTouch');
        event.stopPropagation();
    },
    close: function close() {
        this.node.destroy();
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();