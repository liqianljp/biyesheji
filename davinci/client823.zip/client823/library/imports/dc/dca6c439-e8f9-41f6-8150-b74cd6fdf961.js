"use strict";
cc._RF.push(module, 'dca6cQ56PlB9oFQt0zW/flh', 'FriendActivity');
// Script/FriendActivity.js

"use strict";

//好友系统客户端和服务器的数据交互
var userdata = require('UserData');
module.exports = {
    friendNum: 0, //好友数量
    searchFriendNum: 0, //搜索好友数量
    //初始化用户好友信息或者搜索的玩家信息
    Init_friend_info: function Init_friend_info(friends, array) {
        //现在服务器还没有传数据过来，先本地测试一下
        //假设好友信息存有id,用户头像，用户昵称，用户等级
        for (var i = this.friendNum - 1; i >= 0; i--) {
            var friend = new Map();
            friend.ID = friends[i].P_id;
            friend.FriendIcon = friends[i].HeadImage;
            friend.FriendName = friends[i].Name;
            friend.FriendGrade = friends[i].Grade;
            friend.FriendStatus = friends[i].GameStatus;
            array[i] = friend;
        }
    },

    Init_searchedfriend_info: function Init_searchedfriend_info(friends, array) {
        //现在服务器还没有传数据过来，先本地测试一下
        //假设好友信息存有id,用户头像，用户昵称，用户等级
        for (var i = this.searchFriendNum - 1; i >= 0; i--) {
            var friend = new Map();
            friend.ID = friends[i].P_id;
            friend.FriendIcon = friends[i].HeadImage;
            friend.FriendName = friends[i].Name;
            friend.FriendGrade = friends[i].Grade;
            friend.FriendStatus = friends[i].GameStatus;
            array[i] = friend;
        }
    },

    Init_askingfriend_info: function Init_askingfriend_info(friend, array) {
        var f = new Map();
        f.ID = -1;
        f.FriendIcon = friend.HeadImage;
        f.FriendName = friend.Name;
        f.FriendGrade = friend.Grade;
        array.push(f);
    },

    //初始化邮箱中邮件列表的邮件信息
    Init_mail_info: function Init_mail_info(mails, array) {
        for (var i = 0; i < mails.length; ++i) {
            var mail = new Map();
            mail.ID = mails[i].ID;
            mail.FriendIcon = mails[i].FriendIcon;
            mail.FriendName = mails[i].FriendName;
            mail.Content = mails[i].Content;
            array[i] = mail;
        }
    },
    //初始化用户好友信息
    Init_friend: function Init_friend(e) {
        userdata.friendInfo = new Array();
        this.Init_friend_info(e, userdata.friendInfo);
    },

    //初始化搜索的玩家信息
    Init_search_friend: function Init_search_friend(e) {
        if (this.searchFriendNum == 0) {
            cc.log("搜索为空");
        } else {
            userdata.searchFriendInfo = new Array();
            this.Init_searchedfriend_info(e, userdata.searchFriendInfo);
        }
    },

    //初始化请求玩家信息
    Init_asking_friend: function Init_asking_friend(e) {
        userdata.askingFriendInfo = new Array();
        this.Init_askingfriend_info(e, userdata.askingFriendInfo);
    },

    //初始化邮件信息
    Init_mail: function Init_mail(e) {
        userdata.mailInfo = new Array();
        this.Init_mail_info(e.MailList, userdata.mailInfo);
    },

    //增加好友
    Add_friend: function Add_friend(friendID) {
        for (var i = 0; i < userdata.searchFriendInfo.length; i++) {
            var friend = userdata.searchFriendInfo[i];
            if (friend.ID == friendID) {
                userdata.friendInfo.push(friend);
                break;
            }
        }
    },

    //通过好友ID删除好友
    Delete_friend: function Delete_friend(friendID) {
        for (var i = 0; i < userdata.friendInfo.length; i++) {
            var friend = userdata.friendInfo[i];
            if (friend.ID == friendID) {
                userdata.friendInfo.splice(i, 1);
                break;
            }
        }
    },

    //通过邮件ID删除邮件
    Delete_mail: function Delete_mail(mailID) {
        for (var i = 0; i < userdata.mailInfo.length; i++) {
            var mail = userdata.mailInfo[i];
            if (mail.ID == mailID) {
                userdata.mailInfo.splice(i, 1);
                break;
            }
        }
    },

    //通过名称删除
    Delete_asking_friend: function Delete_asking_friend(friendName) {
        for (var i = 0; i < userdata.askingFriendInfo.length; i++) {
            var friend = userdata.askingFriendInfo[i];
            if (friend.FriendName == friendName) {
                userdata.askingFriendInfo.splice(i, 1);
                break;
            }
        }
    },

    //通过好友ID获得好友名字
    GetFriendName: function GetFriendName(friendID) {
        for (var i = 0; i < userdata.friendInfo.length; i++) {
            var friend = userdata.friendInfo[i];
            if (parseInt(friend.ID) == friendID) {
                return userdata.friendInfo[i].FriendName;
            }
        }
    },

    //清空列表信息
    Clear_list: function Clear_list(array) {
        array.splice(0, array.length);
    }

};

cc._RF.pop();