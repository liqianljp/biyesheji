"use strict";
cc._RF.push(module, 'dcf79OXlbFMlLqJkzYaiZGQ', 'LoginScene');
// Script/LoginScene.js

"use strict";

var http = require('HttpUtils');
var userdata = require("UserData");
cc.Class({
    extends: cc.Component,
    properties: {
        idEditBox: {
            default: null,
            type: cc.EditBox
        },
        padEditBox: {
            default: null,
            type: cc.EditBox
        }
    },

    // use this for initialization
    onLoad: function onLoad() {},

    ToHall: function ToHall() {
        var self = this;
        var url = "http://192.168.0.229:8080/test";
        userdata.mname = self.idEditBox.string;
        var content = JSON.stringify({
            Type: 10001,
            Uid: self.idEditBox.string,
            Psd: self.padEditBox.string
        });
        content = JSON.parse(content);
        var id_mes = JSON.stringify({
            Content: content
        });
        content = "msg=" + id_mes;
        cc.log(content);
        http.HttpPost(url, content, function (rv_mes) {
            if (rv_mes === -1) {
                //console.log("请检查网络");
            } else {
                cc.log(rv_mes);
                var rv = JSON.parse(rv_mes);
                if (rv.Type === 10002) {
                    cc.log("6666");
                    userdata.id = rv.ID;
                    userdata.grade = rv.Grade;
                    var bg = cc.find("Canvas/bg");
                    // var seq2=cc.sequence(cc.fadeOut(1),cc.delayTime(1.01),cc.callFunc(
                    // function(){
                    cc.director.loadScene("HallScene");
                    // }));
                    // bg.runAction(seq2);
                } else if (rv.Type === 10003) {
                    cc.log("5555");
                }
            }
        });
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();