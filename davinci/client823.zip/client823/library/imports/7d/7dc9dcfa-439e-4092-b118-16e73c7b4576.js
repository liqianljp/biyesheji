"use strict";
cc._RF.push(module, '7dc9dz6Q55AkrEYFuc8e0V2', 'FriendsList');
// Script/FriendsList.js

'use strict';

var userdata = require('UserData');
var friend = require('FriendActivity');
var http = require('HttpUtils');
var soket = require("SoketUtils");
var Item = cc.Class({
    name: "Item",
    properties: {
        id: 0,
        friendName: "",
        friendGrade: 0,
        friendIcon: cc.SpriteFrame
    }
});

cc.Class({
    extends: cc.Component,

    properties: {
        items: {
            default: [],
            type: Item
        },
        itemFriendPrefab: cc.Prefab,
        headAtlas: {
            default: null,
            type: cc.SpriteAtlas
        },
        friendListContent: { //好友列表内容
            default: null,
            type: cc.Node
        },
        friendList: { //现有的的玩家列表
            default: null,
            type: cc.Node
        },
        friendChatName1: { //聊天，显示正选择的好友
            default: null,
            type: cc.Label
        },
        chatEdit: { //聊天输入信息框
            default: null,
            type: cc.EditBox
        },
        chatContent: { //聊天输入信息高度
            default: null,
            type: cc.Node
        },
        chatLabel: { //聊天信息的item
            default: null,
            type: cc.Label
        },
        friendChatName2: { //邮件，显示正选择的好友
            default: null,
            type: cc.Label
        },
        mailEdit: { //聊天输入信息框
            default: null,
            type: cc.EditBox
        },
        doInitChatInfo: null
    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        self.doInitChatInfo = false;
        //此处给服务器发送请求
        self.AskFriend();
    },

    //请求好友列表
    AskFriend: function AskFriend() {
        var self = this;
        //此处给服务器发送请求
        var content = JSON.stringify({ Type: 10053
        });
        cc.log("向好友服务器发送请求好友列表消息：");
        cc.log(JSON.parse(content));
        soket.ws.send(content); //发送消息 
        soket.getChatMsg(); //监听获取信息                            
    },

    //初始化好友列表
    InitFriend: function InitFriend() {
        var self = this;
        if (userdata.friendInfo == null) {} else {
            //cc.log(userdata.friendInfo);
            self.ClearFriends();
            self.items.length = userdata.friendInfo.length;
            for (var i = 0; i < self.items.length; ++i) {
                var item = cc.instantiate(self.itemFriendPrefab);
                self.items[i] = userdata.friendInfo[i];
                var data = self.items[i];
                self.node.addChild(item);
                item.getComponent('ItemFriend').init({
                    id: data.ID,
                    itemName: data.FriendName,
                    itemGrade: "分数:" + data.FriendGrade,
                    iconSF: self.headAtlas.getSpriteFrame(data.FriendIcon)
                });
            }
            self.friendListContent.height = 200 + userdata.friendInfo.length * 60;
        }
    },

    //清空列表
    ClearFriends: function ClearFriends() {
        var self = this;
        for (var i = self.friendListContent.children.length - 1; i >= 0; i--) {
            self.friendListContent.removeChild(self.friendListContent.children[i]);
        }
    },

    //删除好友按钮函数
    AskDeleteFriend: function AskDeleteFriend() {
        var self = this;
        if (self.friendList.active == true) {
            if (userdata.selectedFriendID == null) {
                cc.log("请先选择想删除的好友.");
            } else {
                //此处给服务器发送请求
                var content = JSON.stringify({ Type: 10070,
                    P_id: parseInt(userdata.selectedFriendID)
                });
                cc.log("向好友服务器发送请求删除好友消息：");
                cc.log(JSON.parse(content));
                soket.ws.send(content); //发送消息 
                soket.getChatMsg(); //监听获取信息
            }
        } else {
            cc.log("请在好友列表选择删除的好友.");
        }
    },
    //响应删除好友函数
    AnswerDeleteFriend: function AnswerDeleteFriend() {
        var self = this;
        if (soket.isDeleteFriend == true) {
            cc.log(userdata.friendInfo);
            self.UpdateFriendList();
            cc.log("列表好友item数量:" + self.friendListContent.children.length);
            soket.isDeleteFriend = false;
            userdata.selectedFriendName = null;
            userdata.selectedFriendID = null;
        }
        if (soket.hasBeenDeleted == true) {
            soket.hasBeenDeleted = false;
            self.AskFriend();
        }
    },

    //更新好友列表
    UpdateFriendList: function UpdateFriendList() {
        var self = this;
        self.friendListContent.removeChild(self.GetRemovedItem(userdata.selectedFriendID));
    },

    //确定要移除的item
    GetRemovedItem: function GetRemovedItem(friendID) {
        var self = this;
        for (var i = 0; i < self.friendListContent.children.length; ++i) {
            var id = self.friendListContent.children[i].getChildByName("id").getComponent(cc.Label).string;
            if (id == friendID) {
                return self.friendListContent.children[i];
            }
        }
    },

    //标记当前点击的好友
    SignSelectedFriend: function SignSelectedFriend() {
        var self = this;
        for (var i = 0; i < self.friendListContent.children.length; ++i) {
            var id = self.friendListContent.children[i].getChildByName("id").getComponent(cc.Label).string;
            if (id == userdata.selectedFriendID) {
                self.friendListContent.children[i].getChildByName("selecting").active = true;
            } else {
                self.friendListContent.children[i].getChildByName("selecting").active = false;
            }
        }
    },

    //发送和好友的聊天信息
    sendChatString: function sendChatString() {
        var self = this;
        cc.log("想发送的消息：" + self.chatEdit.string);
        var chatContent = JSON.stringify({
            Type: 10075,
            P_id: parseInt(userdata.selectedFriendID),
            Text: self.chatEdit.string
        });
        soket.getChatMsg();
        if (self.chatEdit.string != "") {
            //发送消息不为空时
            cc.log("向聊天服务器发送聊天消息：");
            cc.log(JSON.parse(chatContent));
            soket.ws.send(chatContent); //发送消息

            soket.chatFriend[parseInt(userdata.selectedFriendID)].chatFriendHeightAdd += 1; //content增加一次高度
            soket.chatFriend[parseInt(userdata.selectedFriendID)].chatFriendString = soket.chatFriend[parseInt(userdata.selectedFriendID)].chatFriendString + "\n" + "我：" + self.mes.Text;
        } else {
            self.chatEdit.string = "输入消息不能为空！";
            setTimeout(function () {
                self.chatEdit.string = "";
            }, 500);
        }
        self.chatEdit.Placeholder = "在此输入聊天信息.......";
        self.chatEdit.string = "";
    },

    InitChatInfo: function InitChatInfo() {
        var self = this;
        for (var i = 0; i < userdata.friendInfo.length; i++) {
            var chat = new Map();
            chat.chatFriendString = "\n" + "聊天如下：";
            chat.chatFriendHeightAdd = 0;
            var j = parseInt(userdata.friendInfo[i].ID);
            soket.chatFriend[j] = chat;
        }
        self.doInitChatInfo = true;
    },

    //发送给好友邮件
    sendEmialString: function sendEmialString() {
        var self = this;
        cc.log("想发送的邮件：" + self.chatEdit.string);
        var mailContent = JSON.stringify({ Id: userdata.id,
            Type: 10045,
            Name: "666",
            Key: userdata.chatRoomKey,
            Text: self.mailEdit.string
        });
        //soket.getChatMsg();
        if (self.mailEdit.string != "") {
            //发送邮件信息不为空时
            cc.log("向邮件服务器发送邮件信息：");
            cc.log(JSON.parse(mailContent));
            //soket.ws.send(mailContent);//发送邮件信息
        } else {
            self.mailEdit.string = "输入邮件内容不能为空！";
            setTimeout(function () {
                self.mailEdit.string = "";
            }, 1000);
        }
        self.mailEdit.Placeholder = "在此输入邮件内容.......";
        self.mailEdit.string = "";
    },

    update: function update(dt) {
        var self = this;
        soket.getChatMsg(); //监听获取信息

        self.friendChatName1.string = "聊天好友：" + userdata.selectedFriendName + "  id:" + userdata.selectedFriendID;
        self.friendChatName2.string = "收件人：" + userdata.selectedFriendName + "  id:" + userdata.selectedFriendID;

        //soket.getChatMsg();//监听获取聊天信息
        if (self.doInitChatInfo == true) {
            self.chatLabel.string = soket.chatFriend[parseInt(userdata.selectedFriendID)].chatFriendString; //更新聊天记录
            self.chatContent.height = 250 + soket.chatFriend[parseInt(userdata.selectedFriendID)].chatFriendHeightAdd * 60; //更新聊天框高度
        }
        self.InitFriend();
        self.AnswerDeleteFriend();
        self.SignSelectedFriend();
        if (soket.isInitChat == true) {
            self.InitChatInfo();
            soket.isInitChat == false;
        }
    }
});

cc._RF.pop();