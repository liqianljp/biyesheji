"use strict";
cc._RF.push(module, '8440bnVTKhDYI49gJhcjDOw', 'UserData');
// Script/UserData.js

"use strict";

//储存用户ID，以及每局对战的牌信息
module.exports = {
    mname: null, //自己的名字
    id: null, //对战id
    mgrade: null, //自己的积分
    token: null, //
    oname: null, //对面玩家的名字
    ograde: null, //对面玩家的积分
    lname: null, //左边玩家的名字
    lgrade: null, //左边玩家的积分
    rname: null, //右边玩家的名字
    rgrade: null, //右边玩家的积分
    mseat: null, //自己的座位号
    oseat: null, //对面玩家座位号
    lseat: null, //左边玩家座位号
    rseat: null, //右边玩家座位号
    mcard: null, //储存自己牌的map
    ocard: null, //储存对面玩家牌的map
    lcard: null, //储存左边玩家牌的map
    rcard: null, //储存右边玩家牌的map
    ftplayer: null, //先手摸牌玩家
    tcard: null, //单摸的牌的信息
    guessedman: null, //被猜牌的玩家座位号
    guessedcard: null, //被猜牌的信息
    surplus: null, //剩余卡牌堆张数
    insert_count: null, //插牌次数
    restcard: null, //牌堆是否剩余牌
    cardsAreNull: null, //判断牌堆恰好为为空
    chatRoomKey: null, //聊天室编号
    restBlackCount: null, //开始游戏时牌池剩余的黑牌数
    restWhiteCount: null, //开始游戏时牌池剩余的白牌数
    round: null, //当前回合数
    friendInfo: null, //存储好友信息
    selectedFriendName: "", //选择的好友名
    selectedFriendID: null, //选择的好友id
    searchFriendInfo: null, //存储搜索的玩家信息
    askingFriendInfo: null, //存储请求玩家信息
    mailInfo: null, //存储邮件信息
    selectedMailID: null };

cc._RF.pop();