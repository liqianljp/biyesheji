require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"AskingFriendList":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'cfc66TG9XdPLZZb0AwBeA0Q', 'AskingFriendList');
// Script/AskingFriendList.js

'use strict';

var userdata = require('UserData');
var friend = require('FriendActivity');
var http = require('HttpUtils');
var soket = require("SoketUtils");
var Item4 = cc.Class({
    name: "Item4",
    properties: {
        id: 0,
        friendName: "",
        friendGrade: 0,
        friendIcon: cc.SpriteFrame
    }
});

cc.Class({
    extends: cc.Component,
    properties: {
        items: {
            default: [],
            type: Item4
        },
        itemFriendPrefab: cc.Prefab,
        headAtlas: {
            default: null,
            type: cc.SpriteAtlas
        },
        askingListContent: { //请求列表内容
            default: null,
            type: cc.Node
        },
        askingList: { //请求列表
            default: null,
            type: cc.Node
        },
        friendList: { //好友列表
            default: null,
            type: cc.Node
        },
        friendListContent: { //好友列表内容
            default: null,
            type: cc.Node
        }
    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        userdata.selectedFriendName = null;
        self.InitAskingList();
    },

    //初始化请求好友列表
    InitAskingList: function InitAskingList() {
        var self = this;
        userdata.selectedMailID = null;
        if (userdata.askingFriendInfo == null || userdata.askingFriendInfo.length == 0) {} else {
            self.ClearAskingFriends();
            self.items.length = userdata.askingFriendInfo.length;
            for (var i = 0; i < self.items.length; ++i) {
                var item = cc.instantiate(self.itemFriendPrefab);
                self.items[i] = userdata.askingFriendInfo[0];
                var data = self.items[i];
                self.node.addChild(item);
                item.color = new cc.Color(0, 191, 255);
                item.getComponent('ItemFriend').init({
                    id: data.ID,
                    itemName: data.FriendName,
                    itemGrade: "分数:" + data.FriendGrade,
                    iconSF: self.headAtlas.getSpriteFrame(data.FriendIcon)
                });
            }
        }
    },

    //拒绝添加好友函数
    Reject: function Reject() {
        var self = this;
        if (userdata.selectedFriendName == null) {
            cc.log("请先选择想拒绝的人.");
        } else {
            //此处给服务器发送请求
            var content = JSON.stringify({ Type: 10069,
                Answer: false,
                Name: userdata.selectedFriendName
            });
            cc.log("向好友服务器发送请求拒绝增加好友消息：");
            cc.log(JSON.parse(content));
            soket.ws.send(content); //发送消息 
            soket.getChatMsg(); //监听获取信息
            self.UpdateAskingList(false);
        }
    },

    //同意添加好友函数
    Agree: function Agree() {
        var self = this;
        if (userdata.selectedFriendName == null) {
            cc.log("请先选择想同意的人.");
        } else {
            //此处给服务器发送请求
            var content = JSON.stringify({ Type: 10069,
                Answer: true,
                Name: userdata.selectedFriendName
            });
            cc.log("向好友服务器发送请求同意增加好友消息：");
            cc.log(JSON.parse(content));
            soket.ws.send(content); //发送消息 
            soket.getChatMsg(); //监听获取信息
            self.UpdateAskingList(true);
        }
    },

    //被请求方更新好友请求列表
    UpdateAskingList: function UpdateAskingList(choice) {
        var self = this;
        //同意添加好友
        if (choice == true) {
            self.friendList.active = true;
            self.ClearAskingFriends();
            friend.Clear_list(userdata.askingFriendInfo);
            self.friendListContent.getComponent("FriendsList").AskFriend();
        }
        //拒绝添加好友
        if (choice == false) {
            self.friendList.active = true;
            self.ClearAskingFriends();
            friend.Clear_list(userdata.askingFriendInfo);
            self.friendListContent.getComponent("FriendsList").AskFriend();
        }
    },

    //关闭好友请求列表
    CloseList: function CloseList() {
        var self = this;
        self.askingList.active = false;
    },

    //确定要移除的item
    GetRemovedItem: function GetRemovedItem(mailID) {
        var self = this;
    },

    //清空好友请求列表
    ClearAskingFriends: function ClearAskingFriends() {
        var self = this;
        for (var i = self.askingListContent.children.length - 1; i >= 0; i--) {
            self.askingListContent.removeChild(self.askingListContent.children[i]);
        }
    },

    //标记当前点击的好友
    SignSelectedFriend: function SignSelectedFriend() {
        var self = this;
        for (var i = 0; i < self.askingListContent.children.length; ++i) {
            var name = self.askingListContent.children[i].getChildByName("name").getComponent(cc.Label).string;
            if (name == userdata.selectedFriendName) {
                self.askingListContent.children[i].getChildByName("selecting").active = true;
            } else {
                self.askingListContent.children[i].getChildByName("selecting").active = false;
            }
        }
    },
    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {
        var self = this;
        soket.getChatMsg();

        self.InitAskingList();
        self.SignSelectedFriend();
    }
});

cc._RF.pop();
},{"FriendActivity":"FriendActivity","HttpUtils":"HttpUtils","SoketUtils":"SoketUtils","UserData":"UserData"}],"CardActivity":[function(require,module,exports){
"use strict";
cc._RF.push(module, '02d70j7tbxH0IVRPqnflc8X', 'CardActivity');
// Script/CardActivity.js

"use strict";

//储存卡牌信息
var userdata = require('UserData');
module.exports = {
    //初始化函数模板，根据信息初始化卡牌信息，并储存在对应map里面，通用这一个函数初始化
    Init_card: function Init_card(cards, map) {
        for (var x in cards) {
            var card = new Map();
            card.point = cards[x].CardPoint;
            card.suit = cards[x].CardSuit;
            card.posi = cards[x].Position;
            card.state = cards[x].CardStatus;
            map.set(parseInt(x), card);
        }
    },

    Modify_card: function Modify_card(cards, maps) {
        for (var x = 0; x < cards.length; x++) {
            maps.get(x).point = cards[x].CardPoint;
            maps.get(x).suit = cards[x].CardSuit;
            maps.get(x).posi = cards[x].Position;
            maps.get(x).state = cards[x].CardStatus;
        }
    },

    //查找座位对应的OppPlayer下标
    GetSeat: function GetSeat(seats, e) {
        for (var x in e) {
            if (e[x].Seat === seats) {
                return x;
            }
        }
    },

    //两玩家对战时初始函数
    Init_two_players: function Init_two_players(mcards, ocards) {
        userdata.mcard = new Map();
        userdata.ocard = new Map();
        this.Init_card(mcards, userdata.mcard);
        this.Init_card(ocards, userdata.ocard);
    },
    //三玩家对战时初始函数
    Init_three_players: function Init_three_players(mcards, lcards, rcards) {
        userdata.mcard = new Map();
        userdata.lcard = new Map();
        userdata.rcard = new Map();
        this.Init_card(mcards, userdata.mcard);
        this.Init_card(lcards, userdata.lcard);
        this.Init_card(rcards, userdata.rcard);
    },

    //初始化四人对局时对手信息以及卡牌信息
    Init_four_opp: function Init_four_opp(e) {
        var r = this.GetSeat(userdata.rseat, e);
        this.Init_card(e[r].Card, userdata.rcard);
        userdata.rname = e[r].Uid;
        userdata.rgrade = e[r].Grade;
        var l = this.GetSeat(userdata.lseat, e);
        this.Init_card(e[l].Card, userdata.lcard);
        userdata.lname = e[l].Uid;
        userdata.lgrade = e[l].Grade;
        var o = this.GetSeat(userdata.oseat, e);
        this.Init_card(e[o].Card, userdata.ocard);
        userdata.oname = e[o].Uid;
        userdata.ograde = e[o].Grade;
    },
    //四玩家对战时初始函数
    Init_four_players: function Init_four_players(e) {
        userdata.mcard = new Map();
        userdata.ocard = new Map();
        userdata.lcard = new Map();
        userdata.rcard = new Map();
        userdata.tcard = new Map();
        userdata.mseat = parseInt(e.Mseat);
        this.Init_card(e.Mcard, userdata.mcard);

        //根据我的座位固定对手座位
        if (userdata.mseat === 1) {
            userdata.rseat = 2;
            userdata.oseat = 3;
            userdata.lseat = 4;
            this.Init_four_opp(e.OppPlayer);
        } else if (userdata.mseat === 2) {
            userdata.rseat = 3;
            userdata.oseat = 4;
            userdata.lseat = 1;
            this.Init_four_opp(e.OppPlayer);
        } else if (userdata.mseat === 3) {
            userdata.rseat = 4;
            userdata.oseat = 1;
            userdata.lseat = 2;
            this.Init_four_opp(e.OppPlayer);
        } else if (userdata.mseat === 4) {
            userdata.rseat = 1;
            userdata.oseat = 2;
            userdata.lseat = 3;
            this.Init_four_opp(e.OppPlayer);
        }
        userdata.ftplayer = e.Touchp;
        this.Tcard(e.Tcard);
    },

    //根据摸牌人存储单摸的一张卡牌,tcard.suit记录单摸牌颜色
    Tcard: function Tcard(tcard) {
        if (userdata.ftplayer === userdata.mseat) {
            this.Insert_tcard(tcard, userdata.mcard);
        } else {
            userdata.tcard.suit = tcard.CardSuit;
            if (userdata.ftplayer === userdata.oseat) {
                this.Insert_tcard(tcard, userdata.ocard);
            } else if (userdata.ftplayer === userdata.rseat) {
                this.Insert_tcard(tcard, userdata.rcard);
            } else if (userdata.ftplayer === userdata.lseat) {
                this.Insert_tcard(tcard, userdata.lcard);
            }
        }
    },

    //单摸牌插入到摸牌方的map
    Insert_tcard: function Insert_tcard(tcard, map) {
        if (tcard != null) {
            //如果牌堆有牌
            var map_length = map.size;
            var card = new Map();
            card.point = tcard.CardPoint;
            card.suit = tcard.CardSuit;
            card.posi = tcard.Position;
            card.state = tcard.CardStatus;
            map.set(parseInt(map_length), card);
        }
    },

    //接收猜牌结果信息
    GuessResult: function GuessResult(e) {
        userdata.guessedman = e.Seat;
        userdata.guessedcard.point = e.Card.CardPoint;
        userdata.guessedcard.suit = e.Card.CardSuit;
        userdata.guessedcard.posi = e.Card.Position;
        userdata.guessedcard.state = e.Card.CardStatus;
        if (e.Result === true) {
            if (userdata.guessedman === userdata.mseat) {
                userdata.mcard.get(e.Card.Position - 1).state = e.Card.CardStatus;
            } else if (userdata.guessedman === userdata.oseat) {
                userdata.ocard.get(e.Card.Position - 1).point = e.Card.CardPoint;
                userdata.ocard.get(e.Card.Position - 1).state = e.Card.CardStatus;
            } else if (userdata.guessedman === userdata.rseat) {
                userdata.rcard.get(e.Card.Position - 1).point = e.Card.CardPoint;
                userdata.rcard.get(e.Card.Position - 1).state = e.Card.CardStatus;
            } else if (userdata.guessedman === userdata.lseat) {
                userdata.lcard.get(e.Card.Position - 1).point = e.Card.CardPoint;
                userdata.lcard.get(e.Card.Position - 1).state = e.Card.CardStatus;
            }
        } else {
            userdata.tcard.point = e.Tcard.CardPoint;
            if (userdata.ftplayer === userdata.mseat) {
                var card_length = userdata.mcard.size;
                userdata.mcard.get(card_length - 1).state = e.Tcard.CardStatus;
            } else if (userdata.ftplayer === userdata.oseat) {
                var card_length = userdata.ocard.size;
                userdata.ocard.get(card_length - 1).point = e.Tcard.CardPoint;
                userdata.ocard.get(card_length - 1).state = e.Tcard.CardStatus;
            } else if (userdata.ftplayer === userdata.rseat) {
                var card_length = userdata.rcard.size;
                userdata.rcard.get(card_length - 1).point = e.Tcard.CardPoint;
                userdata.rcard.get(card_length - 1).state = e.Tcard.CardStatus;
            } else if (userdata.ftplayer === userdata.lseat) {
                var card_length = userdata.lcard.size;
                userdata.lcard.get(card_length - 1).point = e.Tcard.CardPoint;
                userdata.lcard.get(card_length - 1).state = e.Tcard.CardStatus;
            }
        }
    },

    //正确位置插入的通用模板
    Insert_template: function Insert_template(cards) {
        var card_length = cards.size;
        var posbuff = cards.get(card_length - 1).posi;
        cards.get(card_length - 1).posi = card_length;
        for (var i = card_length; i > posbuff; i--) {
            var _ref = [cards.get(i - 2).point, cards.get(i - 1).point];
            cards.get(i - 1).point = _ref[0];
            cards.get(i - 2).point = _ref[1];
            var _ref2 = [cards.get(i - 2).suit, cards.get(i - 1).suit];
            cards.get(i - 1).suit = _ref2[0];
            cards.get(i - 2).suit = _ref2[1];
            var _ref3 = [cards.get(i - 2).state, cards.get(i - 1).state];
            cards.get(i - 1).state = _ref3[0];
            cards.get(i - 2).state = _ref3[1];
        }
    },

    //更新储存卡牌的map的信息
    Insert_card: function Insert_card() {
        userdata.insert_count += 1;
        if (userdata.ftplayer === userdata.mseat) {
            if (userdata.insert_count === 1) {
                var card_length = userdata.mcard.size;
                for (var i = card_length - 2; i >= 0; i--) {
                    if (userdata.mcard.get(i).point > userdata.mcard.get(i + 1).point || userdata.mcard.get(i).point === userdata.mcard.get(i + 1).point && userdata.mcard.get(i).suit === "black") {
                        var _ref4 = [userdata.mcard.get(i + 1).point, userdata.mcard.get(i).point];
                        userdata.mcard.get(i).point = _ref4[0];
                        userdata.mcard.get(i + 1).point = _ref4[1];
                        var _ref5 = [userdata.mcard.get(i + 1).suit, userdata.mcard.get(i).suit];
                        userdata.mcard.get(i).suit = _ref5[0];
                        userdata.mcard.get(i + 1).suit = _ref5[1];
                        var _ref6 = [userdata.mcard.get(i + 1).state, userdata.mcard.get(i).state];
                        userdata.mcard.get(i).state = _ref6[0];
                        userdata.mcard.get(i + 1).state = _ref6[1];
                        var _ref7 = [userdata.mcard.get(i + 1).posi, userdata.mcard.get(i).posi];
                        userdata.mcard.get(i).posi = _ref7[0];
                        userdata.mcard.get(i + 1).posi = _ref7[1];
                    } else break;
                }
            } else {
                this.Insert_template(userdata.mcard);
            }
        } else if (userdata.ftplayer === userdata.oseat) {
            this.Insert_template(userdata.ocard);
        } else if (userdata.ftplayer === userdata.lseat) {
            this.Insert_template(userdata.lcard);
        } else if (userdata.ftplayer === userdata.rseat) {
            this.Insert_template(userdata.rcard);
        }
    },

    //结束数据接收
    Over: function Over(e) {
        userdata.winner_seat = e.SWinner;
        userdata.guessedman = e.Seat;
        userdata.guessedcard = e.Card;
        userdata.guessedcard.point = e.Card.CardPoint;
        userdata.guessedcard.suit = e.Card.CardSuit;
        userdata.guessedcard.posi = e.Card.Position;
        userdata.guessedcard.state = e.Card.CardStatus;
        if (userdata.winner_seat === userdata.oseat) {
            this.Modify_card(e.Hands, userdata.ocard);
        } else if (userdata.winner_seat === userdata.rseat) {
            this.Modify_card(e.Hands, userdata.rcard);
        } else if (userdata.winner_seat === userdata.lseat) {
            this.Modify_card(e.Hands, userdata.lcard);
        }
    }
};

cc._RF.pop();
},{"UserData":"UserData"}],"CardMgr":[function(require,module,exports){
"use strict";
cc._RF.push(module, '3f50fzXhZ9GqrfsDfSWh5QB', 'CardMgr');
// Script/CardMgr.js

"use strict";

//根据位置，牌的颜色，牌的点数获取相应牌的图片
var cardSprites = []; //卡牌精灵数组
cc.Class({
    extends: cc.Component,

    properties: {
        leftAtlas: { //左边玩家卡牌图片信息
            default: null,
            type: cc.SpriteAtlas
        },

        rightAtlas: { //右边玩家卡牌图片信息
            default: null,
            type: cc.SpriteAtlas
        },

        oppositeAtlas: { //对面玩家卡牌图片信息
            default: null,
            type: cc.SpriteAtlas
        },

        myselfAtlas: { //自己玩家卡牌图片信息
            default: null,
            type: cc.SpriteAtlas
        },

        unknownAtlas: { //未知卡牌图片信息
            default: null,
            type: cc.SpriteAtlas
        },

        _sides: null,
        _pres: null,
        cardSprites: null

    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        self._sides = ["myself", "right", "opposite", "left"];
        self._pres = ["M_", "R_", "O_", "L_"];

        //卡牌点数
        for (var i = 0; i < 14; ++i) {
            cardSprites.push(i); //0~11存储0~11点牌，12存万能牌，13存储未知牌
        }
    },

    //通过牌的点数获取对应图片的点数
    getCardSpriteByID: function getCardSpriteByID(id) {
        return cardSprites[id];
    },

    //通过牌的颜色获取牌的类型
    getCardType: function getCardType(color) {
        var str = "";
        if (color == "white") {
            str = "whitecard_";
            return str;
        }
        if (color == "black") {
            str = "blackcard_";
            return str;
        }
    },

    //通过前缀，颜色类型和点数得到卡牌图片的名字
    getSpriteFrameByCardID: function getSpriteFrameByCardID(pre, color, cardId) {
        var type = this.getCardType(color);
        var spriteFrameName = this.getCardSpriteByID(cardId);
        spriteFrameName = pre + type + spriteFrameName;
        if (pre == "M_") {
            if (cardId == 12) {
                spriteFrameName = pre + type + " random";
                return this.myselfAtlas.getSpriteFrame(spriteFrameName);
            } else if (cardId == 13) {
                //自己的手牌没有13点，即未知牌
                return null;
            } else {
                spriteFrameName = pre + type + cardId;
                return this.myselfAtlas.getSpriteFrame(spriteFrameName);
            }
        } else if (pre == "O_") {
            if (cardId == 12) {
                spriteFrameName = pre + type + " random";
                return this.oppositeAtlas.getSpriteFrame(spriteFrameName);
            } else if (cardId == 13) {
                spriteFrameName = pre + type + "unk";
                return this.oppositeAtlas.getSpriteFrame(spriteFrameName);
            } else {
                spriteFrameName = pre + type + cardId;
                return this.oppositeAtlas.getSpriteFrame(spriteFrameName);
            }
        } else if (pre == "L_") {
            if (cardId == 12) {
                spriteFrameName = pre + type + " random";
                return this.leftAtlas.getSpriteFrame(spriteFrameName);
            } else if (cardId == 13) {
                spriteFrameName = pre + type + "unk";
                return this.leftAtlas.getSpriteFrame(spriteFrameName);
            } else {
                spriteFrameName = pre + type + cardId;
                return this.leftAtlas.getSpriteFrame(spriteFrameName);
            }
        } else if (pre == "R_") {
            if (cardId == 12) {
                spriteFrameName = pre + type + " random";
                return this.rightAtlas.getSpriteFrame(spriteFrameName);
            } else if (cardId == 13) {
                spriteFrameName = pre + type + "unk";
                return this.rightAtlas.getSpriteFrame(spriteFrameName);
            } else {
                spriteFrameName = pre + type + cardId;
                return this.rightAtlas.getSpriteFrame(spriteFrameName);
            }
        }
    }

});

cc._RF.pop();
},{}],"FloatingBox":[function(require,module,exports){
"use strict";
cc._RF.push(module, '8aea24WP9tEPKtLftwa9wMu', 'FloatingBox');
// Script/FloatingBox.js

"use strict";

var soket = require("SoketUtils");
var userdata = require("UserData");
cc.Class({
    extends: cc.Component,
    properties: {
        floatingBox: { //浮框显示
            default: null,
            type: cc.Node
        },
        IsDisplay: null,
        askingButton: { //
            default: null,
            type: cc.Node
        }
    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        self.IsDisplay = false;
    },

    //弹出浮框
    ShowFloatingBox: function ShowFloatingBox() {
        var self = this;
        if (self.IsDisplay == false) {
            self.IsDisplay = true;
        } else if (self.IsDisplay == true) {
            self.IsDisplay = false;
        }

        if (self.IsDisplay == true) {
            self.floatingBox.active = true;
        } else if (self.IsDisplay == false) {
            self.floatingBox.active = false;
        }
    },

    //关闭浮框
    CloseFloatingBox: function CloseFloatingBox() {
        var self = this;
        self.floatingBox.active = false;
        self.IsDisplay = false;
        userdata.selectedMailID = null;
    },

    //
    update: function update(dt) {
        var self = this;
        //  if(userdata.askingFriendInfo!=null&&userdata.askingFriendInfo.length!=0){
        //     self.askingButton.color = new cc.Color(0,191,255);
        // }else{
        //     self.askingButton.color = new cc.Color(255,255,255,255); 
        // }
    }
});

cc._RF.pop();
},{"SoketUtils":"SoketUtils","UserData":"UserData"}],"FriendActivity":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'dca6cQ56PlB9oFQt0zW/flh', 'FriendActivity');
// Script/FriendActivity.js

"use strict";

//好友系统客户端和服务器的数据交互
var userdata = require('UserData');
module.exports = {
    friendNum: 0, //好友数量
    searchFriendNum: 0, //搜索好友数量
    //初始化用户好友信息或者搜索的玩家信息
    Init_friend_info: function Init_friend_info(friends, array) {
        //现在服务器还没有传数据过来，先本地测试一下
        //假设好友信息存有id,用户头像，用户昵称，用户等级
        for (var i = this.friendNum - 1; i >= 0; i--) {
            var friend = new Map();
            friend.ID = friends[i].P_id;
            friend.FriendIcon = friends[i].HeadImage;
            friend.FriendName = friends[i].Name;
            friend.FriendGrade = friends[i].Grade;
            friend.FriendStatus = friends[i].GameStatus;
            array[i] = friend;
        }
    },

    Init_searchedfriend_info: function Init_searchedfriend_info(friends, array) {
        //现在服务器还没有传数据过来，先本地测试一下
        //假设好友信息存有id,用户头像，用户昵称，用户等级
        for (var i = this.searchFriendNum - 1; i >= 0; i--) {
            var friend = new Map();
            friend.ID = friends[i].P_id;
            friend.FriendIcon = friends[i].HeadImage;
            friend.FriendName = friends[i].Name;
            friend.FriendGrade = friends[i].Grade;
            friend.FriendStatus = friends[i].GameStatus;
            array[i] = friend;
        }
    },

    Init_askingfriend_info: function Init_askingfriend_info(friend, array) {
        var f = new Map();
        f.ID = -1;
        f.FriendIcon = friend.HeadImage;
        f.FriendName = friend.Name;
        f.FriendGrade = friend.Grade;
        array.push(f);
    },

    //初始化邮箱中邮件列表的邮件信息
    Init_mail_info: function Init_mail_info(mails, array) {
        for (var i = 0; i < mails.length; ++i) {
            var mail = new Map();
            mail.ID = mails[i].ID;
            mail.FriendIcon = mails[i].FriendIcon;
            mail.FriendName = mails[i].FriendName;
            mail.Content = mails[i].Content;
            array[i] = mail;
        }
    },
    //初始化用户好友信息
    Init_friend: function Init_friend(e) {
        userdata.friendInfo = new Array();
        this.Init_friend_info(e, userdata.friendInfo);
    },

    //初始化搜索的玩家信息
    Init_search_friend: function Init_search_friend(e) {
        if (this.searchFriendNum == 0) {
            cc.log("搜索为空");
        } else {
            userdata.searchFriendInfo = new Array();
            this.Init_searchedfriend_info(e, userdata.searchFriendInfo);
        }
    },

    //初始化请求玩家信息
    Init_asking_friend: function Init_asking_friend(e) {
        userdata.askingFriendInfo = new Array();
        this.Init_askingfriend_info(e, userdata.askingFriendInfo);
    },

    //初始化邮件信息
    Init_mail: function Init_mail(e) {
        userdata.mailInfo = new Array();
        this.Init_mail_info(e.MailList, userdata.mailInfo);
    },

    //增加好友
    Add_friend: function Add_friend(friendID) {
        for (var i = 0; i < userdata.searchFriendInfo.length; i++) {
            var friend = userdata.searchFriendInfo[i];
            if (friend.ID == friendID) {
                userdata.friendInfo.push(friend);
                break;
            }
        }
    },

    //通过好友ID删除好友
    Delete_friend: function Delete_friend(friendID) {
        for (var i = 0; i < userdata.friendInfo.length; i++) {
            var friend = userdata.friendInfo[i];
            if (friend.ID == friendID) {
                userdata.friendInfo.splice(i, 1);
                break;
            }
        }
    },

    //通过邮件ID删除邮件
    Delete_mail: function Delete_mail(mailID) {
        for (var i = 0; i < userdata.mailInfo.length; i++) {
            var mail = userdata.mailInfo[i];
            if (mail.ID == mailID) {
                userdata.mailInfo.splice(i, 1);
                break;
            }
        }
    },

    //通过名称删除
    Delete_asking_friend: function Delete_asking_friend(friendName) {
        for (var i = 0; i < userdata.askingFriendInfo.length; i++) {
            var friend = userdata.askingFriendInfo[i];
            if (friend.FriendName == friendName) {
                userdata.askingFriendInfo.splice(i, 1);
                break;
            }
        }
    },

    //通过好友ID获得好友名字
    GetFriendName: function GetFriendName(friendID) {
        for (var i = 0; i < userdata.friendInfo.length; i++) {
            var friend = userdata.friendInfo[i];
            if (parseInt(friend.ID) == friendID) {
                return userdata.friendInfo[i].FriendName;
            }
        }
    },

    //清空列表信息
    Clear_list: function Clear_list(array) {
        array.splice(0, array.length);
    }

};

cc._RF.pop();
},{"UserData":"UserData"}],"FriendsList":[function(require,module,exports){
"use strict";
cc._RF.push(module, '7dc9dz6Q55AkrEYFuc8e0V2', 'FriendsList');
// Script/FriendsList.js

'use strict';

var userdata = require('UserData');
var friend = require('FriendActivity');
var http = require('HttpUtils');
var soket = require("SoketUtils");
var Item = cc.Class({
    name: "Item",
    properties: {
        id: 0,
        friendName: "",
        friendGrade: 0,
        friendIcon: cc.SpriteFrame
    }
});

cc.Class({
    extends: cc.Component,

    properties: {
        items: {
            default: [],
            type: Item
        },
        itemFriendPrefab: cc.Prefab,
        headAtlas: {
            default: null,
            type: cc.SpriteAtlas
        },
        friendListContent: { //好友列表内容
            default: null,
            type: cc.Node
        },
        friendList: { //现有的的玩家列表
            default: null,
            type: cc.Node
        },
        friendChatName1: { //聊天，显示正选择的好友
            default: null,
            type: cc.Label
        },
        chatEdit: { //聊天输入信息框
            default: null,
            type: cc.EditBox
        },
        chatContent: { //聊天输入信息高度
            default: null,
            type: cc.Node
        },
        chatLabel: { //聊天信息的item
            default: null,
            type: cc.Label
        },
        friendChatName2: { //邮件，显示正选择的好友
            default: null,
            type: cc.Label
        },
        mailEdit: { //聊天输入信息框
            default: null,
            type: cc.EditBox
        },
        doInitChatInfo: null
    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        self.doInitChatInfo = false;
        //此处给服务器发送请求
        self.AskFriend();
    },

    //请求好友列表
    AskFriend: function AskFriend() {
        var self = this;
        //此处给服务器发送请求
        var content = JSON.stringify({ Type: 10053
        });
        cc.log("向好友服务器发送请求好友列表消息：");
        cc.log(JSON.parse(content));
        soket.ws.send(content); //发送消息 
        soket.getChatMsg(); //监听获取信息                            
    },

    //初始化好友列表
    InitFriend: function InitFriend() {
        var self = this;
        if (userdata.friendInfo == null) {} else {
            //cc.log(userdata.friendInfo);
            self.ClearFriends();
            self.items.length = userdata.friendInfo.length;
            for (var i = 0; i < self.items.length; ++i) {
                var item = cc.instantiate(self.itemFriendPrefab);
                self.items[i] = userdata.friendInfo[i];
                var data = self.items[i];
                self.node.addChild(item);
                item.getComponent('ItemFriend').init({
                    id: data.ID,
                    itemName: data.FriendName,
                    itemGrade: "分数:" + data.FriendGrade,
                    iconSF: self.headAtlas.getSpriteFrame(data.FriendIcon)
                });
            }
            self.friendListContent.height = 200 + userdata.friendInfo.length * 60;
        }
    },

    //清空列表
    ClearFriends: function ClearFriends() {
        var self = this;
        for (var i = self.friendListContent.children.length - 1; i >= 0; i--) {
            self.friendListContent.removeChild(self.friendListContent.children[i]);
        }
    },

    //删除好友按钮函数
    AskDeleteFriend: function AskDeleteFriend() {
        var self = this;
        if (self.friendList.active == true) {
            if (userdata.selectedFriendID == null) {
                cc.log("请先选择想删除的好友.");
            } else {
                //此处给服务器发送请求
                var content = JSON.stringify({ Type: 10070,
                    P_id: parseInt(userdata.selectedFriendID)
                });
                cc.log("向好友服务器发送请求删除好友消息：");
                cc.log(JSON.parse(content));
                soket.ws.send(content); //发送消息 
                soket.getChatMsg(); //监听获取信息
            }
        } else {
            cc.log("请在好友列表选择删除的好友.");
        }
    },
    //响应删除好友函数
    AnswerDeleteFriend: function AnswerDeleteFriend() {
        var self = this;
        if (soket.isDeleteFriend == true) {
            cc.log(userdata.friendInfo);
            self.UpdateFriendList();
            cc.log("列表好友item数量:" + self.friendListContent.children.length);
            soket.isDeleteFriend = false;
            userdata.selectedFriendName = null;
            userdata.selectedFriendID = null;
        }
        if (soket.hasBeenDeleted == true) {
            soket.hasBeenDeleted = false;
            self.AskFriend();
        }
    },

    //更新好友列表
    UpdateFriendList: function UpdateFriendList() {
        var self = this;
        self.friendListContent.removeChild(self.GetRemovedItem(userdata.selectedFriendID));
    },

    //确定要移除的item
    GetRemovedItem: function GetRemovedItem(friendID) {
        var self = this;
        for (var i = 0; i < self.friendListContent.children.length; ++i) {
            var id = self.friendListContent.children[i].getChildByName("id").getComponent(cc.Label).string;
            if (id == friendID) {
                return self.friendListContent.children[i];
            }
        }
    },

    //标记当前点击的好友
    SignSelectedFriend: function SignSelectedFriend() {
        var self = this;
        for (var i = 0; i < self.friendListContent.children.length; ++i) {
            var id = self.friendListContent.children[i].getChildByName("id").getComponent(cc.Label).string;
            if (id == userdata.selectedFriendID) {
                self.friendListContent.children[i].getChildByName("selecting").active = true;
            } else {
                self.friendListContent.children[i].getChildByName("selecting").active = false;
            }
        }
    },

    //发送和好友的聊天信息
    sendChatString: function sendChatString() {
        var self = this;
        cc.log("想发送的消息：" + self.chatEdit.string);
        var chatContent = JSON.stringify({
            Type: 10075,
            P_id: parseInt(userdata.selectedFriendID),
            Text: self.chatEdit.string
        });
        soket.getChatMsg();
        if (self.chatEdit.string != "") {
            //发送消息不为空时
            cc.log("向聊天服务器发送聊天消息：");
            cc.log(JSON.parse(chatContent));
            soket.ws.send(chatContent); //发送消息

            soket.chatFriend[parseInt(userdata.selectedFriendID)].chatFriendHeightAdd += 1; //content增加一次高度
            soket.chatFriend[parseInt(userdata.selectedFriendID)].chatFriendString = soket.chatFriend[parseInt(userdata.selectedFriendID)].chatFriendString + "\n" + "我：" + self.mes.Text;
        } else {
            self.chatEdit.string = "输入消息不能为空！";
            setTimeout(function () {
                self.chatEdit.string = "";
            }, 500);
        }
        self.chatEdit.Placeholder = "在此输入聊天信息.......";
        self.chatEdit.string = "";
    },

    InitChatInfo: function InitChatInfo() {
        var self = this;
        for (var i = 0; i < userdata.friendInfo.length; i++) {
            var chat = new Map();
            chat.chatFriendString = "\n" + "聊天如下：";
            chat.chatFriendHeightAdd = 0;
            var j = parseInt(userdata.friendInfo[i].ID);
            soket.chatFriend[j] = chat;
        }
        self.doInitChatInfo = true;
    },

    //发送给好友邮件
    sendEmialString: function sendEmialString() {
        var self = this;
        cc.log("想发送的邮件：" + self.chatEdit.string);
        var mailContent = JSON.stringify({ Id: userdata.id,
            Type: 10045,
            Name: "666",
            Key: userdata.chatRoomKey,
            Text: self.mailEdit.string
        });
        //soket.getChatMsg();
        if (self.mailEdit.string != "") {
            //发送邮件信息不为空时
            cc.log("向邮件服务器发送邮件信息：");
            cc.log(JSON.parse(mailContent));
            //soket.ws.send(mailContent);//发送邮件信息
        } else {
            self.mailEdit.string = "输入邮件内容不能为空！";
            setTimeout(function () {
                self.mailEdit.string = "";
            }, 1000);
        }
        self.mailEdit.Placeholder = "在此输入邮件内容.......";
        self.mailEdit.string = "";
    },

    update: function update(dt) {
        var self = this;
        soket.getChatMsg(); //监听获取信息

        self.friendChatName1.string = "聊天好友：" + userdata.selectedFriendName + "  id:" + userdata.selectedFriendID;
        self.friendChatName2.string = "收件人：" + userdata.selectedFriendName + "  id:" + userdata.selectedFriendID;

        //soket.getChatMsg();//监听获取聊天信息
        if (self.doInitChatInfo == true) {
            self.chatLabel.string = soket.chatFriend[parseInt(userdata.selectedFriendID)].chatFriendString; //更新聊天记录
            self.chatContent.height = 250 + soket.chatFriend[parseInt(userdata.selectedFriendID)].chatFriendHeightAdd * 60; //更新聊天框高度
        }
        self.InitFriend();
        self.AnswerDeleteFriend();
        self.SignSelectedFriend();
        if (soket.isInitChat == true) {
            self.InitChatInfo();
            soket.isInitChat == false;
        }
    }
});

cc._RF.pop();
},{"FriendActivity":"FriendActivity","HttpUtils":"HttpUtils","SoketUtils":"SoketUtils","UserData":"UserData"}],"GameOver":[function(require,module,exports){
"use strict";
cc._RF.push(module, '828074ygEpJw6aLaCJOi1jA', 'GameOver');
// Script/GameOver.js

"use strict";

var http = require("HttpUtils");
var card = require("CardActivity");
var userdata = require("UserData");
var soket = require("SoketUtils");

cc.Class({
    extends: cc.Component,
    properties: {},

    // use this for initialization
    onLoad: function onLoad() {},

    //点击返回大厅按钮
    BackToHall: function BackToHall() {
        var self = this;
        http.isBackToHall = true;
        soket.close_ws();
        cc.director.loadScene("HallScene");
    },

    //点击再来一局按钮
    ReMatchGame: function ReMatchGame() {
        //关闭上一局游戏的http和socket,跳转到大厅
        var self = this;
        http.isBackToHall = true;
        soket.close_ws();
        cc.director.loadScene("HallScene");
        //马上执行快速匹配对手
        var hall = self.node.getComponent("HallScene");
        hall.FindPlayer();
    }
});

cc._RF.pop();
},{"CardActivity":"CardActivity","HttpUtils":"HttpUtils","SoketUtils":"SoketUtils","UserData":"UserData"}],"GameScene":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'b8756yG6h1NYIdsL6CQoEPA', 'GameScene');
// Script/GameScene.js

'use strict';

var http = require('HttpUtils');
var userdata = require('UserData');
var cardactivity = require('CardActivity');
var soket = require("SoketUtils");
cc.Class({
    extends: cc.Component,

    properties: {

        holdCards_4: { //4人游戏卡牌
            default: null,
            type: cc.Node
        },
        guess: { //猜牌弹出框
            default: null,
            type: cc.Node
        },
        guessbg: { //猜牌弹出框的背景
            default: null,
            type: cc.Node
        },
        continue: {
            default: null,
            type: cc.Node
        },
        continuebg: { //是否继续猜牌牌弹出框的背景
            default: null,
            type: cc.Node
        },
        guessPointDisplay: { //猜牌弹出框上的显示的猜牌点数
            default: null,
            type: cc.EditBox
        },
        insert_random: { //万能牌插入位置弹出框
            default: null,
            type: cc.Node
        },
        insert_randombg: { //万能牌插入位置弹出框的背景
            default: null,
            type: cc.Node
        },
        insert_randomDisplay: { //万能牌插入位置弹出框显示的位置
            default: null,
            type: cc.EditBox
        },
        gameover: { //游戏结束弹出框
            default: null,
            type: cc.Node
        },
        gameoverbg: { //游戏结束弹出框背景
            default: null,
            type: cc.Node
        },
        gameResultDisplay: { //游戏结束弹出框结果显示
            default: null,
            type: cc.Label
        },
        chatEdit: { //聊天输入信息框
            default: null,
            type: cc.EditBox
        },
        chatContent: { //聊天输入信息高度
            default: null,
            type: cc.Node
        },
        chatLabel: { //聊天信息的item
            default: null,
            type: cc.Label
        },
        newsContent: { //游戏历史消息高度
            default: null,
            type: cc.Node
        },
        newsLabel: { //游戏历史消息的item
            default: null,
            type: cc.Label
        },
        blackCountLabel: { //牌池剩余黑牌数显示
            default: null,
            type: cc.Label
        },
        whiteCountLabel: { //牌池剩余白牌数显示
            default: null,
            type: cc.Label
        },
        stepCountLabel: { //步时显示
            default: null,
            type: cc.Label
        },
        roundCountLabel: { //回合数显示
            default: null,
            type: cc.Label
        },
        myTurn: { //当前猜牌人是本方箭头
            default: null,
            type: cc.Node
        },
        rightTurn: { //当前猜牌人右方箭头
            default: null,
            type: cc.Node
        },
        oppositeTurn: { //当前猜牌人是对面箭头
            default: null,
            type: cc.Node
        },
        leftTurn: { //当前猜牌人是左方箭头
            default: null,
            type: cc.Node
        },
        rightInfo: { //右方玩家信息
            default: null,
            type: cc.Node
        },
        oppositeInfo: { //对面玩家信息
            default: null,
            type: cc.Node
        },
        leftInfo: { //左方玩家信息
            default: null,
            type: cc.Node
        },
        newsDisplay: { //飘过的提示信息
            default: null,
            type: cc.Label
        },
        isTimeOut: null, //步时是否为0
        stepCount: 20, //步时计数                        
        playersNum: null, //玩家数量
        myCards: null, //存储本方手牌数组
        rightCards: null, //存储右方手牌数组
        oppositeCards: null, //存储对方手牌数组
        leftCards: null, //存储左方手牌数组
        url: null, //服务器ip地址
        guess_suit: null, //所猜牌的颜色
        guess_posi: null, //所猜牌的位置
        guess_point: null, //所猜的点数
        isepoll: null, //用来决定是否轮询
        myHolds: null, //自己手牌节点
        rightHolds: null, //右方手牌节点
        oppositeHolds: null, //对面手牌节点
        leftHolds: null, //左方手牌节点
        random_point: null, //假定的万能牌点数
        random_suit: null, //万能牌颜色
        newsHistoryAdd: 0, //消息历史增加
        newsHistory: "消息历史如下："
    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        self.url = "http://192.168.0.229:8080/test";
        self.OnlineEpoll();
        self.myCards = [];
        self.rightCards = [];
        self.oppositeCards = [];
        self.leftCards = [];
        self.bool1 = false;
        self.bool2 = false;
        self.newsDisplay.getComponent(cc.Animation).play('newsFlow'); //提示信息飘过...
        userdata.guessedcard = new Map();
        // self.holdCards_2.active = false;
        // self.holdCards_3.active = false;
        self.holdCards_4.active = false;
        self.playersNum = 4; //默认4人游戏
        if (self.playersNum == 4) {
            self.holdCards_4.active = true; //4人手牌出现
            self.rightInfo.active = true;
            self.oppositeInfo.active = true;
            self.leftInfo.active = true;
            self.insert_random.active = false;
            userdata.round = 1;
            self.OnlineChat();
            this.InitView(); //初始化场景
            this.InitCards(); //4人游戏开始，发牌
            this.DealCards(); //4人游戏开始，摸牌
            userdata.restcard = true; //默认牌堆有牌
            userdata.cardsAreNull = 0;
            self.blackCountLabel.string = userdata.restBlackCount + "张"; //初始化牌池剩余牌数量
            self.whiteCountLabel.string = userdata.restWhiteCount + "张";
            //步时倒计时
            self.UpdateLeftTime();
            http.isBackToHall = false;
        }
        self.isepoll = false;
        if (userdata.ftplayer === userdata.mseat) {
            //初始结果轮询，如果本方是摸牌方跳过轮询
            self.isepoll = false;
        } else {
            self.isepoll = true;
        }
        self.ResultEpoll(self.isepoll);
    },
    //在线聊天请求
    OnlineChat: function OnlineChat() {
        var askChat = JSON.stringify({ Id: userdata.id,
            Type: 10040,
            Mseat: userdata.mseat, //加一个自己的座位号
            Name: "666",
            Key: userdata.chatRoomKey });
        cc.log("向聊天服务器发送请求");
        cc.log(JSON.parse(askChat));
        soket.connect(); //建立websoket对象ws
        soket.ws.onopen = function () {
            soket.getChatMsg();
            soket.ws.send(askChat); //发送消息
        };
    },
    //点击发送聊天按钮
    sendChatString: function sendChatString() {
        var self = this;
        cc.log("想发送的消息：" + self.chatEdit.string);
        var chatContent = JSON.stringify({ Id: userdata.id,
            Type: 10045,
            Name: "666",
            Key: userdata.chatRoomKey,
            Text: self.chatEdit.string
        });
        soket.getChatMsg();
        if (self.chatEdit.string != "") {
            //发送消息不为空时
            cc.log("向聊天服务器发送聊天消息：");
            cc.log(JSON.parse(chatContent));
            soket.ws.send(chatContent); //发送消息
        } else {
            self.chatEdit.string = "输入消息不能为空！";
            setTimeout(function () {
                self.chatEdit.string = "";
            }, 1000);
        }
        self.chatEdit.Placeholder = "在此输入聊天信息.......";
    },
    //在线轮询
    OnlineEpoll: function OnlineEpoll() {
        var self = this;
        var online_sdmes = JSON.stringify({ Id: userdata.id,
            "Content": { "Type": 10018 } });
        var content = "msg=" + online_sdmes;
        http.HttpPost(self.url, content, function (online_rvmes) {
            if (online_rvmes === -1) {
                //console.log("请检查网络");
            } else {
                var rv = JSON.parse(online_rvmes);
                if (rv.Type === 10020) {
                    cc.log("online");
                    setTimeout(function () {
                        self.OnlineEpoll();
                    }, 15000);
                }
            }
        });
    },

    //非猜牌方执行轮询结果
    ResultEpoll: function ResultEpoll(e) {
        var self = this;
        if (e) {
            var content = JSON.stringify({ Type: 10025,
                Round: userdata.round
            });
            content = JSON.parse(content);
            var result_sdmes = JSON.stringify({ Id: userdata.id,
                Content: content
            });
            var content = "msg=" + result_sdmes;
            http.HttpPost(self.url, content, function (result_mes) {
                var result_rvmes = JSON.parse(result_mes);
                //cc.log(result_rvmes);
                if (result_rvmes.Type === 10024) {
                    //未返回猜牌信息
                    setTimeout(function () {
                        cc.log("未返回猜牌信息");
                        self.ResultEpoll(e);
                    }, 2000);
                } else if (result_rvmes.Type === 10023) {
                    //返回猜牌信息
                    cc.log("收到10023");
                    cc.log(result_rvmes);
                    userdata.round += 1;
                    self.roundCountLabel.string = userdata.round;
                    cardactivity.GuessResult(result_rvmes);
                    self.ChangeRandomPosi(result_rvmes);
                    if (userdata.ftplayer === result_rvmes.GuessSeat) {
                        if (result_rvmes.Result == true) {
                            //返回猜牌信息,且猜对
                            cc.log("返回猜牌信息,且猜对");
                            if (result_rvmes.GuessCard.CardPoint == 12) {
                                //上方飘过的提示消息
                                self.newsDisplay.string = "玩家" + self.getNameBySeat(userdata.mseat) + "猜玩家" + self.getNameBySeat(userdata.guessedman) + "的第" + userdata.guessedcard.posi + "张牌为万能牌，猜错了";
                            } else {
                                self.newsDisplay.string = "玩家" + self.getNameBySeat(userdata.mseat) + "猜玩家" + self.getNameBySeat(userdata.guessedman) + "的第" + userdata.guessedcard.posi + "张牌为" + result_rvmes.GuessCard.CardPoint + "点，猜对了";
                            }

                            self.newsHistory = self.newsHistory + "\n" + "第" + (userdata.round - 1) + "回合：" + self.newsDisplay.string;
                            self.newsHistoryAdd += 1;
                            self.newsDisplay.getComponent(cc.Animation).play('newsFlow'); //提示信息飘过...        
                            self.MingBrang(userdata.guessedman, userdata.guessedcard, userdata.guessedcard.posi);
                            self.RoundChange();
                        } else if (result_rvmes.Result == false) {
                            //返回猜牌信息,且猜错 
                            if (result_rvmes.TimeOut == false) {
                                //未超时猜错
                                cc.log("返回猜牌信息,且猜错");
                                if (result_rvmes.GuessCard.CardPoint == 12) {
                                    //上方飘过的提示消息
                                    self.newsDisplay.string = "玩家" + self.getNameBySeat(userdata.mseat) + "猜玩家" + self.getNameBySeat(userdata.guessedman) + "的第" + userdata.guessedcard.posi + "张牌为万能牌，猜错了";
                                } else {
                                    self.newsDisplay.string = "玩家" + self.getNameBySeat(userdata.mseat) + "猜玩家" + self.getNameBySeat(userdata.guessedman) + "的第" + userdata.guessedcard.posi + "张牌为" + result_rvmes.GuessCard.CardPoint + "点，猜错了";
                                }
                                self.newsHistory = self.newsHistory + "\n" + "第" + (userdata.round - 1) + "回合：" + self.newsDisplay.string;
                                self.newsHistoryAdd += 1;
                                self.newsDisplay.getComponent(cc.Animation).play('newsFlow'); //提示信息飘过...   
                                if (userdata.restcard) {
                                    //如果牌堆有牌
                                    cc.log(userdata.tcard);
                                    self.MingBrang(userdata.ftplayer, userdata.tcard, self.myHolds.children.length);
                                }
                                self.RoundChange();
                            } else if (result_rvmes.TimeOut == true) {
                                //超时
                                cc.log("猜牌人超时！！！");
                                self.newsDisplay.string = "玩家" + self.getNameBySeat(userdata.ftplayer) + "猜牌超时";
                                self.newsHistory = self.newsHistory + "\n" + "第" + (userdata.round - 1) + "回合：" + self.newsDisplay.string;
                                self.newsHistoryAdd += 1;
                                self.newsDisplay.getComponent(cc.Animation).play('newsFlow'); //提示信息飘过...
                                if (userdata.restcard) {
                                    //如果牌堆有牌
                                    self.MingBrang(userdata.ftplayer, userdata.tcard, self.myHolds.children.length);
                                }
                                self.RoundChange();
                            }
                        }
                    } else {
                        cc.log(1112223334444);
                        setTimeout(function () {
                            self.ResultEpoll(e);
                        }, 2000);
                    }
                } else if (result_rvmes.Type === 10035) {
                    cc.log("出现胜利者");
                    if (userdata.restcard != false && userdata.cardsAreNull != 1) {
                        cardactivity.Over(result_rvmes);
                        self.InsertCards();
                        setTimeout(function () {
                            cardactivity.Insert_card();
                        }, 500);
                        setTimeout(function () {
                            self.UpdateCardsInfo();
                            self.GameOver(result_rvmes);
                        }, 2001);
                    } else {
                        cardactivity.Over(result_rvmes);
                        self.GameOver(result_rvmes); //牌堆里的牌发完了时出现胜利者 
                    }
                }
            });
        }
    },

    //回合切换
    RoundChange: function RoundChange() {
        cc.log("RoundChange执行");
        var self = this;

        var round_sdmes = JSON.stringify({ Id: userdata.id,
            "Content": { "Type": 10028 } });
        var content = "msg=" + round_sdmes;
        http.HttpPost(self.url, content, function (round_mes) {
            if (round_mes == -1) {} else {
                var round_rvmes = JSON.parse(round_mes);
                cc.log("回合切换轮询接受信息如下：");
                cc.log(round_rvmes);
                switch (round_rvmes.Type) {
                    case 10029:
                        setTimeout(function () {
                            cc.log("猜牌方继续猜牌继续轮询结果");
                            self.stepCount = 21;
                            self.ResultEpoll(self.isepoll); //猜牌方继续猜牌继续轮询结果
                        }, 1000);
                        break;

                    case 10030:
                        cc.log(222222);
                        if (round_rvmes.Tcard != null) {
                            //如果牌堆不为空
                            self.InsertCards();
                            setTimeout(function () {
                                cardactivity.Insert_card();
                            }, 500);
                        } else {
                            userdata.restcard = false;
                            userdata.cardsAreNull += 1;
                        }
                        if (round_rvmes.Tcard == null && userdata.cardsAreNull == 1) {
                            //如果牌堆为空且刚好为空（用来将最后一张摸的牌插入手牌）
                            self.InsertCards();
                            setTimeout(function () {
                                cardactivity.Insert_card();
                            }, 500);
                        }

                        setTimeout(function () {
                            self.UpdateCardsInfo();
                            if (userdata.mseat === userdata.ftplayer) {
                                for (var i = 0; i < userdata.mcard.size; ++i) {
                                    cc.log(i + 1 + ".position=" + self.myCards[i].posi + "," + (i + 1) + ".point=" + self.myCards[i].point + "," + (i + 1) + ".color=" + self.myCards[i].suit);
                                }
                            } else if (userdata.rseat === userdata.ftplayer) {
                                for (var i = 0; i < userdata.rcard.size; ++i) {
                                    cc.log(i + 1 + ".position=" + self.rightCards[i].posi + "," + (i + 1) + ".point=" + self.rightCards[i].point + "," + (i + 1) + ".color=" + self.rightCards[i].suit);
                                }
                            } else if (userdata.oseat === userdata.ftplayer) {
                                for (var i = 0; i < userdata.ocard.size; ++i) {
                                    cc.log(i + 1 + ".position=" + self.oppositeCards[i].posi + "," + (i + 1) + ".point=" + self.oppositeCards[i].point + "," + (i + 1) + ".color=" + self.oppositeCards[i].suit);
                                }
                            } else if (userdata.lseat === userdata.ftplayer) {
                                for (var i = 0; i < userdata.lcard.size; ++i) {
                                    cc.log(i + 1 + ".position=" + self.leftCards[i].posi + "," + (i + 1) + ".point=" + self.leftCards[i].point + "," + (i + 1) + ".color=" + self.leftCards[i].suit);
                                }
                            }
                            userdata.ftplayer = round_rvmes.Touchp;
                            if (round_rvmes.Tcard != null) {
                                cardactivity.Tcard(round_rvmes.Tcard);
                                self.DealCards();
                                self.blackCountLabel.string = round_rvmes.RestCard.black + "张";
                                self.whiteCountLabel.string = round_rvmes.RestCard.white + "张";
                            }
                            self.stepCount = 21;
                            if (userdata.ftplayer === userdata.mseat) {
                                self.isepoll = false;
                            } else {
                                self.isepoll = true;
                            }
                            setTimeout(function () {
                                cc.log("不是猜牌方将继续轮询结果；是猜牌方时将失效");
                                self.ResultEpoll(self.isepoll); //不是猜牌方将继续轮询结果；是猜牌方时将失效
                            }, 3000);
                        }, 2000);
                        break;

                    case 10031:
                        setTimeout(function () {
                            self.RoundChange(); //不是猜牌方将继续轮询结果；是猜牌方时将失效
                        }, 500);
                        break;
                }
            }
        });
    },

    //初始化场景
    InitView: function InitView() {
        var self = this;
        //搜索需要的子节点
        var holdCardsChild = self.node.getChildByName("num_4");
        self.myHolds = holdCardsChild.getChildByName("player1_cards"); //自己的手牌
        self.rightHolds = holdCardsChild.getChildByName("player2_cards"); //右边的手牌
        self.oppositeHolds = holdCardsChild.getChildByName("player3_cards"); //对面的手牌
        self.leftHolds = holdCardsChild.getChildByName("player4_cards"); //左边的手牌

        for (var i = 0; i < self.myHolds.children.length; ++i) {
            self.myHolds.children[i].active = false;
        }
        for (var i = 0; i < self.rightHolds.children.length; ++i) {
            self.rightHolds.children[i].active = false;
        }
        for (var i = 0; i < self.oppositeHolds.children.length; ++i) {
            self.oppositeHolds.children[i].active = false;
        }
        for (var i = 0; i < self.leftHolds.children.length; ++i) {
            self.leftHolds.children[i].active = false;
        }

        setTimeout(function () {
            self.ShowPlayerInfo(); //显示玩家信息 
        }, 2000);
    },

    //4人游戏开始，发牌
    InitCards: function InitCards() {
        var self = this;
        //确定猜牌人位置
        self.GuessTurn();
        //发自己的牌，开始只有3张牌
        for (var i = 0; i < 3; i++) {
            self.myHolds.children[i].active = true;
            var sprite = self.myHolds.children[i].getComponent(cc.Sprite);
            self.SetSpriteFrameByCardID("M_", userdata.mcard.get(i).suit, userdata.mcard.get(i).point, sprite); //我方的牌如实显示
            self.SetCardsInfo(self.myCards, i, userdata.mcard.get(i));
        }

        //发右边的牌，开始只有3张牌
        for (var i = 0; i < 3; i++) {
            self.rightHolds.children[i].active = true;
            var sprite = self.rightHolds.children[i].getComponent(cc.Sprite);
            self.SetSpriteFrameByCardID("R_", userdata.rcard.get(i).suit, 13, sprite); //右边的牌显示为未知的
            self.SetCardsInfo(self.rightCards, i, userdata.rcard.get(i)); //存储右边卡牌信息
            self.GuessCards(sprite.node); //猜右边的牌
        }
        //发对面的牌，开始只有3张牌
        for (var i = 0; i < 3; i++) {
            self.oppositeHolds.children[i].active = true;
            var sprite = self.oppositeHolds.children[i].getComponent(cc.Sprite);
            self.SetSpriteFrameByCardID("O_", userdata.ocard.get(i).suit, 13, sprite); //对面的牌显示为未知的
            self.SetCardsInfo(self.oppositeCards, i, userdata.ocard.get(i)); //存储对面卡牌信息
            self.GuessCards(sprite.node); //猜对面的牌
        }
        //发左边的牌，开始只有3张牌
        for (var i = 0; i < 3; i++) {
            self.leftHolds.children[i].active = true;
            var sprite = self.leftHolds.children[i].getComponent(cc.Sprite);
            self.SetSpriteFrameByCardID("L_", userdata.lcard.get(i).suit, 13, sprite); //左边的牌显示为未知的
            self.SetCardsInfo(self.leftCards, i, userdata.lcard.get(i)); //存储左边卡牌信息
            self.GuessCards(sprite.node); //猜左边的牌
        }
    },

    //4人游戏开始，摸牌
    DealCards: function DealCards() {
        var self = this;
        //确定猜牌人位置
        self.GuessTurn();
        var tcardLocation = self.myHolds.children.length - 1;
        if (userdata.mseat === userdata.ftplayer) {
            //如果当前客户端玩家是摸牌方
            self.myHolds.children[8].active = true;
            var sprite = self.myHolds.children[8].getComponent(cc.Sprite);
            self.SetSpriteFrameByCardID("M_", userdata.mcard.get(userdata.mcard.size - 1).suit, userdata.mcard.get(userdata.mcard.size - 1).point, sprite);
            //如果摸到的牌是万能牌
            if (userdata.mcard.get(userdata.mcard.size - 1).point == 12) {
                cc.log("摸到的牌是万能牌");
                self.random_suit = userdata.mcard.get(userdata.mcard.size - 1).suit;
                self.RandomAppear();
            }
            self.SetCardsInfo(self.myCards, userdata.mcard.size - 1, userdata.mcard.get(userdata.mcard.size - 1)); //存储摸的牌的信息
        } else if (userdata.rseat === userdata.ftplayer) {
            //如果当前客户端玩家的右边是摸牌方
            self.rightHolds.children[8].active = true;
            var sprite = self.rightHolds.children[8].getComponent(cc.Sprite);
            self.SetSpriteFrameByCardID("R_", userdata.tcard.suit, 13, sprite);
            self.SetCardsInfo(self.rightCards, userdata.rcard.size - 1, userdata.rcard.get(userdata.rcard.size - 1)); //存储摸的牌的信息                
        } else if (userdata.oseat === userdata.ftplayer) {
            //如果当前客户端玩家的对面是摸牌方
            self.oppositeHolds.children[8].active = true;
            var sprite = self.oppositeHolds.children[8].getComponent(cc.Sprite);
            self.SetSpriteFrameByCardID("O_", userdata.tcard.suit, 13, sprite);
            self.SetCardsInfo(self.oppositeCards, userdata.ocard.size - 1, userdata.ocard.get(userdata.ocard.size - 1)); //存储摸的牌的信息                
        } else if (userdata.lseat === userdata.ftplayer) {
            //如果当前客户端玩家的左边是摸牌方
            self.leftHolds.children[8].active = true;
            var sprite = self.leftHolds.children[8].getComponent(cc.Sprite);
            self.SetSpriteFrameByCardID("L_", userdata.tcard.suit, 13, sprite);
            self.SetCardsInfo(self.leftCards, userdata.lcard.size - 1, userdata.lcard.get(userdata.lcard.size - 1)); //存储摸的牌的信息                
        }
    },

    //4人游戏开始，猜牌
    GuessCards: function GuessCards(node) {
        var self = this;
        node.on(cc.Node.EventType.TOUCH_START, function (event) {
            console.log("点击开始cc.Node.EventType.TOUCH_START");
            if (node.parent === self.myHolds) {
                //自己的牌不能点
                cc.log("自己的牌不能点");
                return;
            }

            if (userdata.ftplayer != userdata.mseat) {
                cc.log('不是自己的回合，不能猜牌');
                return;
            }
            var mingtag = node.getChildByName("MingTag");
            if (mingtag.active === true) {
                cc.log('已经明牌的牌，不能再猜');
                return;
            }
            node.interactable = node.getComponent(cc.Button).interactable;
            if (!node.interactable) {
                cc.log("3232323232");
                return;
            }
            self.guess.active = true; //让猜牌框出现
            self.guessbg.on('touchstart', self.EatTouch, self); //触摸吞噬

            self.guessPointDisplay.string = "7"; //猜牌点数初始显示为7；
            self.guess_point = 7;

            self.GetGuessedman(node); //获取点击的牌的对手座位

            cc.log("点击的卡片的点数，颜色，位置：" + self.GetCardsInfo(node).point + "," + self.GetCardsInfo(node).suit + "," + self.GetCardsInfo(node).posi);

            self.guess_suit = self.GetCardsInfo(node).suit;
            self.guess_posi = self.GetCardsInfo(node).posi;

            if (userdata.ftplayer == userdata.mseat && mingtag.active != true) {
                self.GuessCardPop(node);
            }
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_Move, function (event) {
            console.log("cc.Node.EventType.TOUCH_MOVE");
            if (node.parent === self.myHolds) {
                return;
            }
            if (!node.interactable) {
                return;
            }
            var mingtag = node.getChildByName("MingTag");
            if (mingtag.active === true) {
                return;
            }
            if (Math.abs(event.getDeltaX()) + Math.abs(event.getDeltaY()) < 0.5) {
                return;
            }
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_END, function (event) {
            var mingtag = node.getChildByName("MingTag");
            if (node.parent === self.myHolds) {
                return;
            }
            if (!node.interactable) {
                return;
            }

            if (userdata.ftplayer == userdata.mseat && mingtag.active != true) {
                self.GuessCardPush(node);
            }

            console.log("\n点击结束cc.Node.EventType.TOUCH_END");
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_CANCEL, function (event) {
            if (node.parent === self.myHolds) {
                cc.log("不能点");
                return;
            }
            if (!node.interactable) {
                cc.log("不能点");
                return;
            }
            console.log("cc.Node.EventType.TOUCH_CANCEL");
        }.bind(this));
    },

    //猜牌时，让点击的牌突出手牌
    GuessCardPop: function GuessCardPop(node) {
        var self = this;
        var ox = node.getPositionX();
        var oy = node.getPositionY();
        if (node.parent === self.rightHolds) {
            var move1 = cc.moveTo(0.0001, cc.p(ox - 40, oy));
            node.runAction(move1);
        } else if (node.parent === self.oppositeHolds) {
            var move1 = cc.moveTo(0.0001, cc.p(ox, oy - 30));
            node.runAction(move1);
        } else if (node.parent === self.leftHolds) {
            var move1 = cc.moveTo(0.0001, cc.p(ox + 40, oy));
            node.runAction(move1);
        }
    },

    //猜牌时，让点击的牌缩回手牌
    GuessCardPush: function GuessCardPush(node) {
        var self = this;
        var ox = node.getPositionX();
        var oy = node.getPositionY();
        if (node.parent === self.rightHolds) {
            var move1 = cc.moveTo(0.005, cc.p(ox + 40, oy));
            node.runAction(move1);
        } else if (node.parent === self.oppositeHolds) {
            var move1 = cc.moveTo(0.005, cc.p(ox, oy + 30));
            node.runAction(move1);
        } else if (node.parent === self.leftHolds) {
            var move1 = cc.moveTo(0.005, cc.p(ox - 40, oy));
            node.runAction(move1);
        }
    },
    //插牌动作模板
    Template_insert: function Template_insert(map, seatHolds, cardlength) {
        var self = this;
        var cardPositionX = 0;
        var cardPositionY = 0;
        seatHolds.children[cardlength - 1].active = true;
        cardPositionX = seatHolds.children[map.get(cardlength - 1).posi - 1].getPositionX();
        cardPositionY = seatHolds.children[map.get(cardlength - 1).posi - 1].getPositionY();
        var m = cardlength;
        var n = map.get(cardlength - 1).posi;
        // self.ExchangeCard1(seatHolds.children[cardlength-1], seatHolds.children[map.get(cardlength-1).posi-1]);
        for (var i = map.get(cardlength - 1).posi; i < cardlength; i++) {
            self.ExchangeCard1(seatHolds.children[i - 1], seatHolds.children[i]);
        }
        setTimeout(function () {
            seatHolds.children[cardlength - 1].setPosition(cardPositionX, cardPositionY);
            self.ExchangeIndex(seatHolds, cardlength, map.get(cardlength - 1).posi);
            self.ExchangeCard2(seatHolds.children[seatHolds.children.length - 1], seatHolds.children[map.get(cardlength - 1).posi - 1]);
            var _ref = [seatHolds.children[map.get(cardlength - 1).posi - 1], seatHolds.children[seatHolds.children.length - 1]];
            seatHolds.children[seatHolds.children.length - 1] = _ref[0];
            seatHolds.children[map.get(cardlength - 1).posi - 1] = _ref[1];
        }, 300);
    },
    //4人游戏开始，在猜牌后，插牌
    InsertCards: function InsertCards() {
        var self = this;
        if (userdata.ftplayer === userdata.mseat) {
            //如果当前客户端玩家是摸牌方
            self.Template_insert(userdata.mcard, self.myHolds, userdata.mcard.size);
        } else if (userdata.ftplayer === userdata.rseat) {
            //如果当前客户端右边玩家是摸牌方
            self.Template_insert(userdata.rcard, self.rightHolds, userdata.rcard.size);
        } else if (userdata.ftplayer === userdata.oseat) {
            //如果当前客户端对面玩家是摸牌方
            self.Template_insert(userdata.ocard, self.oppositeHolds, userdata.ocard.size);
        } else if (userdata.ftplayer === userdata.lseat) {
            //如果当前客户端左边玩家是摸牌方
            self.Template_insert(userdata.lcard, self.leftHolds, userdata.lcard.size);
        }
    },
    //设置卡牌图片函数
    SetSpriteFrameByCardID: function SetSpriteFrameByCardID(pre, color, cardId, sprite) {
        var cardmgr = this.node.getComponent("CardMgr");
        sprite.spriteFrame = cardmgr.getSpriteFrameByCardID(pre, color, cardId);
    },

    //存储卡牌信息
    SetCardsInfo: function SetCardsInfo(myCards, //存储卡牌信息的数组
    index, //卡牌对应node在手牌中的位置
    oneCard) //从服务器接受到的卡牌信息
    {
        var self = this;
        myCards[index] = oneCard;
    },

    //提取卡牌信息
    GetCardsInfo: function GetCardsInfo(node) {
        var self = this;
        for (var i = 0; i < self.myHolds.children.length; i++) {
            if (node == self.myHolds.children[i]) {
                if (i == self.myHolds.children.length - 1) {
                    //如果想获取摸得牌的信息
                    return self.myCards[userdata.mcard.size - 1]; //那么返回数组的最后一个
                }
                return self.myCards[i];
            }
        }
        for (var i = 0; i < self.rightHolds.children.length; i++) {
            if (node == self.rightHolds.children[i]) {
                if (i == self.rightHolds.children.length - 1) {
                    //如果想获取摸得牌的信息
                    return self.rightCards[userdata.rcard.size - 1]; //那么返回数组的最后一个
                }
                return self.rightCards[i];
            }
        }
        for (var i = 0; i < self.oppositeHolds.children.length; i++) {
            if (node == self.oppositeHolds.children[i]) {
                if (i == self.oppositeHolds.children.length - 1) {
                    //如果想获取摸得牌的信息
                    return self.oppositeCards[userdata.ocard.size - 1]; //那么返回数组的最后一个
                }
                return self.oppositeCards[i];
            }
        }
        for (var i = 0; i < self.leftHolds.children.length; i++) {
            if (node == self.leftHolds.children[i]) {
                if (i == self.leftHolds.children.length - 1) {
                    //如果想获取摸得牌的信息
                    return self.leftCards[userdata.lcard.size - 1]; //那么返回数组的最后一个
                }
                return self.leftCards[i];
            }
        }
    },

    //点击猜牌浮框上的确定键，发送所猜的牌
    GuessConfirm: function GuessConfirm() {
        var self = this;
        cc.log("Round:" + userdata.round);
        //所猜的卡牌信息
        var card = JSON.stringify({ CardPoint: self.guess_point,
            CardSuit: self.guess_suit,
            Position: self.guess_posi
        });
        card = JSON.parse(card);
        //加上猜的命令10022和所猜人位置seat       
        var content = JSON.stringify({ Type: 10022,
            Seat: userdata.guessedman,
            Card: card
        });
        content = JSON.parse(content);
        //加上客户端session号id
        var guess_sdmes = JSON.stringify({ Id: userdata.id,
            Content: content
        });
        guess_sdmes = "msg=" + guess_sdmes;
        cc.log("发送猜牌信息：" + guess_sdmes);
        if (self.stepCount <= 0) {
            cc.log('已经超时了，不能再发送猜牌信息');
        } else {
            self.stepCount = 21;
            http.HttpPost(self.url, guess_sdmes, function (guess_rvmes) {
                if (guess_rvmes === -1) {} else {
                    guess_rvmes = JSON.parse(guess_rvmes);
                    cc.log(guess_rvmes);
                    if (guess_rvmes.Type === 10035) {
                        //出现胜利者
                        cc.log("出现胜利者");
                        if (userdata.restcard != false && userdata.cardsAreNull != 1) {
                            cardactivity.Over(guess_rvmes);
                            self.MingBrang(userdata.ftplayer, userdata.tcard, self.myHolds.children.length);
                            self.GameOver(guess_rvmes);
                            self.InsertCards();
                            setTimeout(function () {
                                cardactivity.Insert_card();
                            }, 500);
                        } else {
                            cardactivity.Over(guess_rvmes);
                            self.GameOver(guess_rvmes); //牌堆里的牌发完了时出现胜利者
                        }
                    } else {
                        cardactivity.GuessResult(guess_rvmes);
                        if (guess_rvmes.Type === 10023) {
                            //返回猜牌结果信息
                            userdata.round += 1;
                            self.roundCountLabel.string = userdata.round;
                            if (guess_rvmes.Tcard.CardPoint == 12) {
                                //如果摸得牌是万能牌，则改变其posi
                                self.ChangeRandomPosi(guess_rvmes);
                            }
                            switch (guess_rvmes.Result) {
                                case true:
                                    //猜对
                                    cc.log("66666666猜对了");
                                    if (guess_rvmes.GuessCard.CardPoint == 12) {
                                        //上方飘过的提示消息
                                        self.newsDisplay.string = "玩家" + self.getNameBySeat(userdata.mseat) + "猜玩家" + self.getNameBySeat(userdata.guessedman) + "的第" + userdata.guessedcard.posi + "张牌为万能牌，猜对了";
                                    } else {
                                        self.newsDisplay.string = "玩家" + self.getNameBySeat(userdata.mseat) + "猜玩家" + self.getNameBySeat(userdata.guessedman) + "的第" + userdata.guessedcard.posi + "张牌为" + guess_rvmes.GuessCard.CardPoint + "点，猜对了";
                                    }
                                    self.newsHistory = self.newsHistory + "\n" + "第" + (userdata.round - 1) + "回合：" + self.newsDisplay.string;
                                    self.newsHistoryAdd += 1;
                                    self.newsDisplay.getComponent(cc.Animation).play('newsFlow'); //提示信息飘过...
                                    self.MingBrang(userdata.guessedman, userdata.guessedcard, userdata.guessedcard.posi);
                                    self.ContinuePlay();
                                    break;
                                case false:
                                    //猜错
                                    if (guess_rvmes.TimeOut == false) {
                                        //未超时猜错
                                        cc.log("23333333猜错了");
                                        if (guess_rvmes.GuessCard.CardPoint == 12) {
                                            //上方飘过的提示消息
                                            self.newsDisplay.string = "玩家" + self.getNameBySeat(userdata.mseat) + "猜玩家" + self.getNameBySeat(userdata.guessedman) + "的第" + userdata.guessedcard.posi + "张牌为万能牌，猜错了";
                                        } else {
                                            self.newsDisplay.string = "玩家" + self.getNameBySeat(userdata.mseat) + "猜玩家" + self.getNameBySeat(userdata.guessedman) + "的第" + userdata.guessedcard.posi + "张牌为" + guess_rvmes.GuessCard.CardPoint + "点，猜错了";
                                        }
                                        self.newsHistory = self.newsHistory + "\n" + "第" + (userdata.round - 1) + "回合：" + self.newsDisplay.string;
                                        self.newsHistoryAdd += 1;
                                        self.newsDisplay.getComponent(cc.Animation).play('newsFlow'); //提示信息飘过...
                                        if (userdata.restcard) {
                                            //如果牌堆有牌
                                            self.MingBrang(userdata.mseat, userdata.mcard.get(userdata.mcard.size - 1), self.myHolds.children.length);
                                        }
                                        self.stepCount = 21;
                                        self.RoundChange();
                                    } else if (guess_rvmes.TimeOut == true) {
                                        //猜牌时恰好超时，就直接按超时处理
                                        if (userdata.ftplayer == userdata.mseat) {
                                            cc.log("本方超时1");
                                            if (userdata.restcard == false) {
                                                //如果牌堆无牌
                                                cc.log("3333333333333牌堆无牌超时");
                                            } else {//如果牌堆有牌
                                            }
                                            self.ResultEpoll(true);
                                        }
                                    }
                            }
                        }
                    }
                }
            });
        }
        self.guess.active = false;
    },

    //点击猜牌浮框上的叉键，取消猜牌，关闭猜牌浮框
    GuessCancel: function GuessCancel() {
        var self = this;
        self.guess.active = false;
    },
    //点击插随机牌框上的叉键，取消插牌，关闭插牌浮框
    InsertRandomCancel: function InsertRandomCancel() {
        var self = this;
        self.insert_random.active = false;
    },

    //触摸吞噬
    EatTouch: function EatTouch(event) {
        cc.log('EatTouch');
        event.stopPropagation();
    },

    //点击猜牌浮框上的加号键，增加猜牌点数
    AddGuessPoint: function AddGuessPoint() {
        var self = this;
        var a = 0;
        if (self.guessPointDisplay.string == "万能") {
            a = 12;
        } else {
            a = parseInt(self.guessPointDisplay.string);
        }
        a++;
        if (a <= 0) {
            a = 0;
        }
        if (a >= 12) {
            a = 12;
        }
        self.guess_point = a;
        if (a == 12) {
            self.guessPointDisplay.string = "万能";
        } else {
            self.guessPointDisplay.string = a.toString();
        }
    },

    //点击插牌浮框上的加号键，增加插牌位置
    AddInsertNum: function AddInsertNum() {
        var self = this;
        var a = 7;
        a = parseInt(self.insert_randomDisplay.string);
        a++;
        if (a <= 1) {
            a = 1;
        }
        if (a >= 11) {
            a = 11;
        }
        self.random_point = a;
        self.insert_randomDisplay.string = a.toString();
    },
    //点击猜牌浮框上的减号键，减少猜牌点数
    ReduceGuessPoint: function ReduceGuessPoint() {
        var self = this;
        var a = 0;
        if (self.guessPointDisplay.string == "万能") {
            a = 12;
        } else {
            a = parseInt(self.guessPointDisplay.string);
        }
        a--;
        if (a <= 0) {
            a = 0;
        }
        if (a >= 12) {
            a = 12;
        }
        self.guess_point = a;
        if (a == 12) {
            self.guessPointDisplay.string = "万能";
        } else {
            self.guessPointDisplay.string = a.toString();
        }
    },

    //点击插牌浮框上的减号键，减少插牌位置
    ReduceInsertNum: function ReduceInsertNum() {
        var self = this;
        var a = 7;
        a = parseInt(self.insert_randomDisplay.string);
        a--;
        if (a <= 1) {
            a = 1;
        }
        if (a >= 11) {
            a = 11;
        }
        self.random_point = a;
        self.insert_randomDisplay.string = a.toString();
    },

    //明牌效果
    MingBrang: function MingBrang(seat, carddata, pos) {
        var self = this;
        if (seat === userdata.mseat) {
            // var ss=cc.loader.removeItem(carddata.point);
            // self.myHolds.children[pos-1].runAction(ss);
            var tag = self.myHolds.children[pos - 1].getChildByName("MingTag");
            tag.active = true;
        } else if (seat === userdata.rseat) {
            var sprite = self.rightHolds.children[pos - 1].getComponent(cc.Sprite);
            cc.log("R_" + carddata.suit + "_" + carddata.point);
            self.SetSpriteFrameByCardID("R_", carddata.suit, carddata.point, sprite);
            var tag = self.rightHolds.children[pos - 1].getChildByName("MingTag");
            tag.active = true;
        } else if (seat === userdata.oseat) {
            var sprite = self.oppositeHolds.children[pos - 1].getComponent(cc.Sprite);
            cc.log("O_" + carddata.suit + "_" + carddata.point);
            self.SetSpriteFrameByCardID("O_", carddata.suit, carddata.point, sprite);
            var tag = self.oppositeHolds.children[pos - 1].getChildByName("MingTag");
            tag.active = true;
        } else if (seat === userdata.lseat) {
            var sprite = self.leftHolds.children[pos - 1].getComponent(cc.Sprite);
            cc.log("L_" + carddata.suit + "_" + carddata.point);
            self.SetSpriteFrameByCardID("L_", carddata.suit, carddata.point, sprite);
            var tag = self.leftHolds.children[pos - 1].getChildByName("MingTag");
            tag.active = true;
        }
    },

    //获取被猜牌人的座位
    GetGuessedman: function GetGuessedman(node) {
        var self = this;
        if (node.parent === self.rightHolds) {
            userdata.guessedman = userdata.rseat;
        } else if (node.parent === self.oppositeHolds) {
            userdata.guessedman = userdata.oseat;
        } else if (node.parent === self.leftHolds) {
            userdata.guessedman = userdata.lseat;
        }
    },

    //交换牌的位置和信息
    ExchangeCard1: function ExchangeCard1(node1, node2) {
        var move2 = cc.moveTo(0.2, cc.p(node2.getPositionX(), node2.getPositionY()));
        node1.runAction(move2);
    },
    ExchangeCard2: function ExchangeCard2(node1, node2) {
        var move1 = cc.moveTo(0.2, cc.p(node2.getPositionX(), node2.getPositionY()));
        var move2 = cc.moveTo(0.2, cc.p(node1.getPositionX(), node1.getPositionY()));
        node1.runAction(move1);
        node2.runAction(move2);
    },
    ExchangeIndex: function ExchangeIndex(holds, cardsLength, posi) {
        for (var i = cardsLength; i > posi; i--) {
            var _ref2 = [holds.children[i - 2], holds.children[i - 1]];
            holds.children[i - 1] = _ref2[0];
            holds.children[i - 2] = _ref2[1];
        }
    },

    UpdateCardsInfo: function UpdateCardsInfo() {
        var self = this;
        //如果当前客户端玩家是摸牌方
        if (userdata.mseat === userdata.ftplayer) {
            for (var i = 0; i < userdata.mcard.size; ++i) {
                self.myCards[i] = userdata.mcard.get(i);
                var sprite = self.myHolds.children[i].getComponent(cc.Sprite);
                self.GuessCards(sprite.node); //
            }
        } else if (userdata.rseat === userdata.ftplayer) {
            for (var i = 0; i < userdata.rcard.size; ++i) {
                self.rightCards[i] = userdata.rcard.get(i);
                var sprite = self.rightHolds.children[i].getComponent(cc.Sprite);
                self.GuessCards(sprite.node); //
            }
        } else if (userdata.oseat === userdata.ftplayer) {
            for (var i = 0; i < userdata.ocard.size; ++i) {
                self.oppositeCards[i] = userdata.ocard.get(i);
                var sprite = self.oppositeHolds.children[i].getComponent(cc.Sprite);
                self.GuessCards(sprite.node); //                
            }
        } else if (userdata.lseat === userdata.ftplayer) {
            for (var i = 0; i < userdata.lcard.size; ++i) {
                self.leftCards[i] = userdata.lcard.get(i);
                var sprite = self.leftHolds.children[i].getComponent(cc.Sprite);
                self.GuessCards(sprite.node); // 
            }
        }
    },

    //猜牌成功后，延迟2秒弹出是否继续猜牌的弹框
    ContinuePlay: function ContinuePlay() {
        var self = this;
        self.continue.active = true; //让否继续猜牌的弹出现
        self.continuebg.on('touchstart', self.EatTouch, self); //触摸吞噬  
    },
    ContinueConfirm: function ContinueConfirm() {
        var self = this;
        cc.log("继续猜牌");
        //是否继续猜牌      
        var content = JSON.stringify({ Type: 10026,
            ToContinue: true
        });
        content = JSON.parse(content);
        //加上客户端session号id
        var continue_sdmes = JSON.stringify({ Id: userdata.id,
            Content: content
        });
        continue_sdmes = "msg=" + continue_sdmes;
        cc.log("发送继续猜牌请求信息：" + continue_sdmes);
        http.HttpPost(self.url, continue_sdmes, function (continue_rvmes) {
            if (continue_rvmes === -1) {
                //console.log("请检查网络");
            } else {
                var rv = JSON.parse(continue_rvmes);
                if (rv.Type === 10029) {
                    cc.log(rv);
                    self.stepCount = 21;
                    self.continue.active = false;
                }
            }
        });
    },

    ContinueConcel: function ContinueConcel() {
        var self = this;
        cc.log("不继续猜牌");
        //是否继续猜牌      
        var content = JSON.stringify({ Type: 10026,
            ToContinue: false
        });
        content = JSON.parse(content);
        //加上客户端session号id
        var nocontinue_sdmes = JSON.stringify({ Id: userdata.id,
            Content: content
        });
        nocontinue_sdmes = "msg=" + nocontinue_sdmes;
        cc.log("发送不继续猜牌请求信息：" + nocontinue_sdmes);
        http.HttpPost(self.url, nocontinue_sdmes, function (nocontinue_rvmes) {
            if (nocontinue_rvmes === -1) {
                //console.log("请检查网络");
            } else {
                self.continue.active = false; //让否继续猜牌的弹框消失
                var rv = JSON.parse(nocontinue_rvmes);
                cc.log(rv);
                if (rv.Type === 10030) {
                    cc.log("玩家放弃继续猜牌");
                    self.RoundChange();
                }
            }
        });
    },

    //轮询猜牌时收到服务器发送的10035，则一个玩家胜利，其余玩家手牌被猜完，游戏结束
    GameOver: function GameOver(rvmes) {
        var self = this;
        self.gameover.active = true;
        cc.log(userdata.guessedcard);
        self.MingBrang(userdata.guessedman, userdata.guessedcard, userdata.guessedcard.posi); //将最后一张猜的牌明牌

        for (var i = 0; i < rvmes.Hands.length; i++) {
            if (userdata.winner_seat === userdata.mseat) {
                self.MingBrang(userdata.winner_seat, userdata.mcard.get(i), userdata.mcard.get(i).posi); //将胜利者的牌明牌
            } else if (userdata.winner_seat === userdata.rseat) {
                self.MingBrang(userdata.winner_seat, userdata.rcard.get(i), userdata.rcard.get(i).posi); //将胜利者的牌明牌
            } else if (userdata.winner_seat === userdata.oseat) {
                self.MingBrang(userdata.winner_seat, userdata.ocard.get(i), userdata.ocard.get(i).posi); //将胜利者的牌明牌
            } else if (userdata.winner_seat === userdata.lseat) {
                self.MingBrang(userdata.winner_seat, userdata.lcard.get(i), userdata.lcard.get(i).posi); //将胜利者的牌明牌
            }
        }

        if (userdata.winner_seat === userdata.mseat) {
            cc.log(userdata.mcard);
        } else if (userdata.winner_seat === userdata.rseat) {
            cc.log(userdata.rcard);
        } else if (userdata.winner_seat === userdata.oseat) {
            cc.log(userdata.ocard);
        } else if (userdata.winner_seat === userdata.lseat) {
            cc.log(userdata.lcard);
        }

        self.gameoverbg.on('touchstart', self.EatTouch, self); //触摸吞噬
        if (rvmes.SWinner == userdata.mseat) {
            self.gameResultDisplay.string = "本方胜利！再接再厉！";
        } else {
            self.gameResultDisplay.string = "游戏失败！胜利者是：" + rvmes.PWinner;
        }
    },

    //步时倒计时
    UpdateLeftTime: function UpdateLeftTime() {
        var self = this;
        self.stepCountLabel.string = "20";
        self.schedule(function () {
            self.stepCount--;
            if (self.stepCount <= 0) {
                //self.GuessTimeOut();
                self.stepCountLabel.string = "0";
                if (self.stepCount == 0) {
                    self.GuessTimeOut();
                }
            } else {
                self.stepCountLabel.string = self.stepCount;
            }
        }, 1);
    },

    //猜牌超时
    GuessTimeOut: function GuessTimeOut() {
        var self = this;
        if (self.stepCount <= 0) {
            if (userdata.ftplayer == userdata.mseat) {
                cc.log("本方超时2");
                self.insert_random.active = false;
                if (userdata.restcard == false) {
                    //如果牌堆无牌
                    cc.log("3333333333333牌堆无牌超时");
                }
                self.ResultEpoll(true);
            }
        }
    },

    //确定当前猜牌方箭头指向谁
    GuessTurn: function GuessTurn() {
        var self = this;
        if (userdata.ftplayer == userdata.mseat) {
            self.myTurn.active = true;
            self.rightTurn.active = false;
            self.oppositeTurn.active = false;
            self.leftTurn.active = false;
        } else if (userdata.ftplayer == userdata.rseat) {
            self.myTurn.active = false;
            self.rightTurn.active = true;
            self.oppositeTurn.active = false;
            self.leftTurn.active = false;
        } else if (userdata.ftplayer == userdata.oseat) {
            self.myTurn.active = false;
            self.rightTurn.active = false;
            self.oppositeTurn.active = true;
            self.leftTurn.active = false;
        } else if (userdata.ftplayer == userdata.lseat) {
            self.myTurn.active = false;
            self.rightTurn.active = false;
            self.oppositeTurn.active = false;
            self.leftTurn.active = true;
        }
    },

    //万能牌出现
    RandomAppear: function RandomAppear() {
        var self = this;
        self.insert_random.active = true;
        if (self.insert_random.active == true) {
            self.insert_randomDisplay.string = "7";
            self.random_point = 7;
            self.insert_randombg.on('touchstart', self.EatTouch, self); //触摸吞噬
        }
    },

    //确定假定的万能牌点数
    RandomConfirm: function RandomConfirm() {
        var self = this;
        cc.log("确定万能牌假定点数");
        var content = JSON.stringify({ Type: 10041,
            SimPoint: self.random_point,
            Suit: self.random_suit
        });
        content = JSON.parse(content);
        //加上客户端session号id
        var random_sdmes = JSON.stringify({ Id: userdata.id,
            Content: content
        });
        random_sdmes = "msg=" + random_sdmes;
        cc.log("发送万能牌假定点数信息：" + random_sdmes);
        http.HttpPost(self.url, random_sdmes, function (random_rvmes) {
            if (random_rvmes === -1) {
                //console.log("请检查网络");
            } else {
                var rv = JSON.parse(random_rvmes);
                cc.log("收到万能牌返回信息:" + random_rvmes);
            }
        });
        self.insert_random.active = false;
    },

    //如果摸得牌是万能牌，要在map中改变其posi
    ChangeRandomPosi: function ChangeRandomPosi(rv) {
        //如果摸牌人是本方
        if (rv.GuessSeat == userdata.mseat) {
            var cardlength = userdata.mcard.size;
            cc.log("cardlength:" + cardlength);
            cc.log("改变posi前：" + userdata.mcard.get(cardlength - 1).posi);
            cc.log("改变posi后：" + rv.Tcard.Position);
            userdata.mcard.get(cardlength - 1).posi = rv.Tcard.Position;
        } else if (rv.GuessSeat == userdata.rseat) {
            var cardlength = userdata.rcard.size;
            cc.log("cardlength:" + cardlength);
            cc.log("改变posi前：" + userdata.rcard.get(cardlength - 1).posi);
            cc.log("改变posi后：" + rv.Tcard.Position);
            userdata.rcard.get(cardlength - 1).posi = rv.Tcard.Position;
        } else if (rv.GuessSeat == userdata.oseat) {
            var cardlength = userdata.ocard.size;
            cc.log("cardlength:" + cardlength);
            cc.log("改变posi前：" + userdata.ocard.get(cardlength - 1).posi);
            cc.log("改变posi后：" + rv.Tcard.Position);
            userdata.ocard.get(cardlength - 1).posi = rv.Tcard.Position;
        } else if (rv.GuessSeat == userdata.lseat) {
            var cardlength = userdata.lcard.size;
            cc.log("cardlength:" + cardlength);
            cc.log("改变posi前：" + userdata.lcard.get(cardlength - 1).posi);
            cc.log("改变posi后：" + rv.Tcard.Position);
            userdata.lcard.get(cardlength - 1).posi = rv.Tcard.Position;
        }
    },

    //显示玩家信息
    ShowPlayerInfo: function ShowPlayerInfo() {
        var self = this;
        //显示右方玩家信息,按顺序是头像，等级，姓名，金币（现在只有姓名）
        var rightHeadImage = self.rightInfo.getChildByName("player_head"); //头像
        var rightLevel = self.rightInfo.getChildByName("level"); //等级
        var rightName = self.rightInfo.getChildByName("name"); //姓名
        rightName = rightName.getComponent(cc.Label);
        var rightScore = self.rightInfo.getChildByName("score"); //金币数


        //显示对面玩家信息,按顺序是头像，等级，姓名，金币（现在只有姓名）
        var oppositeHeadImage = self.oppositeInfo.getChildByName("player_head"); //头像
        var oppositeLevel = self.oppositeInfo.getChildByName("level"); //等级
        var oppositeName = self.oppositeInfo.getChildByName("name"); //姓名
        oppositeName = oppositeName.getComponent(cc.Label);
        var oppositeScore = self.oppositeInfo.getChildByName("score"); //金币数


        //显示左方玩家信息,按顺序是头像，等级，姓名，金币（现在只有姓名）
        var leftHeadImage = self.leftInfo.getChildByName("player_head"); //头像
        var leftLevel = self.leftInfo.getChildByName("level"); //等级
        var leftName = self.leftInfo.getChildByName("name"); //姓名
        leftName = leftName.getComponent(cc.Label);
        var leftScore = self.leftInfo.getChildByName("score"); //金币数

        for (var i = 0; i < soket.seat.length; i++) {
            if (soket.seat[i] == userdata.rseat) {
                rightName.string = soket.name[i];
            }
            if (soket.seat[i] == userdata.oseat) {
                oppositeName.string = soket.name[i];
            }
            if (soket.seat[i] == userdata.lseat) {
                leftName.string = soket.name[i];
            }
        }
    },

    //由玩家座位号得到相应用户名
    getNameBySeat: function getNameBySeat(seat) {
        var self = this;
        for (var i = 0; i < soket.seat.length; i++) {
            if (soket.seat[i] == seat) {
                return soket.name[i];
            }
        }
    },

    update: function update(dt) {
        var self = this;
        soket.getChatMsg(); //监听获取聊天信息
        self.chatLabel.string = soket.chatString; //更新聊天记录
        self.chatContent.height = 400 + soket.chatHeightAdd * 60; //更新聊天框高度
        self.newsLabel.string = self.newsHistory; //更新游戏消息历史
        self.newsContent.height = 400 + self.newsHistoryAdd * 60; //更新游戏消息历史框高度
        self.GuessTurn(); //更新摸牌玩家方    
    }
});

cc._RF.pop();
},{"CardActivity":"CardActivity","HttpUtils":"HttpUtils","SoketUtils":"SoketUtils","UserData":"UserData"}],"HallScene":[function(require,module,exports){
"use strict";
cc._RF.push(module, '3a3fe/stWRACbHbbuevAvAZ', 'HallScene');
// Script/HallScene.js

"use strict";

var http = require("HttpUtils");
var card = require("CardActivity");
var userdata = require("UserData");
var soket = require("SoketUtils");
cc.Class({
    extends: cc.Component,

    properties: {
        help_ui: cc.Prefab,
        game_num: {
            default: null,
            type: cc.Node
        },
        playerID: null

    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        //刚进入游戏大厅就要申请登陆好友系统
        self.LoginFriendSystem();
    },

    //申请登陆好友系统
    LoginFriendSystem: function LoginFriendSystem() {
        var self = this;
        var content = JSON.stringify({ Id: userdata.id,
            Type: 10041,
            Name: userdata.mname
        });

        cc.log("向好友服务器发送申请登陆消息：");
        cc.log(JSON.parse(content));
        soket.connect(); //建立websoket对象ws
        soket.ws.onopen = function () {
            soket.getChatMsg();
            soket.ws.send(content); //发送消息
        };
    },

    //点击back_to_login按钮，返回到登陆界面
    ToWelcomeScene: function ToWelcomeScene() {
        cc.director.loadScene('WelcomeScene');
    },

    //点击match按钮，向服务器发送命令，快速匹配对手
    FindPlayer: function FindPlayer() {
        var self = this;
        http.isBackToHall = false;
        var url = "http://192.168.0.229:8080/test";
        var params1 = JSON.stringify({ Id: userdata.id,
            "Content": { "Type": 10008, "Uid": "666" } });
        var msg = "msg=" + params1;
        cc.log("点击快速匹配按钮发送消息：" + msg);
        http.HttpPost(url, msg, function (rv_mes) {
            if (rv_mes === -1) {
                cc.log('请检查网络');
            } else {
                cc.log("返回信息：" + rv_mes);
                rv_mes = JSON.parse(rv_mes);
                if (rv_mes.Type === 10010) {
                    cc.log('服务器拒绝开始请求，匹配队列已满 ：' + rv_mes.Type);
                } else if (rv_mes.Type === 10009) {
                    cc.log('服务器收到开始请求，进入匹配队列 ：' + rv_mes.Type);
                    self.Polling();
                }
            }
        });
    },

    //点击帮助按钮弹，出帮助浮框
    HelpTips: function HelpTips() {
        var self = this;
        var helptips_ui = cc.instantiate(self.help_ui);
        helptips_ui.parent = self.node;
        helptips_ui.setPosition(0, 0);
    },

    //点击快速需找对手按钮，弹出游戏模式选择框（可选）
    GameModelSelect: function GameModelSelect() {
        var self = this;
    },

    //下面实现，客户端在接受到允许进入匹配队列后，开始轮询请求
    //请求匹配玩家时，轮询请求函数.
    //当返回的值等于10014(找到对手)时，不反复执行此函数
    //当返回的值等于10015(未找到对手)时，在一定时间内反复执行此函数
    Polling: function Polling() {
        var self = this;
        var url = "http://192.168.0.229:8080/test";
        var params = JSON.stringify({ Id: userdata.id,
            "Content": { "Type": 10013 } });
        var msg = "msg=" + params;
        cc.log("匹配轮询时发送消息：" + msg);
        http.HttpPost(url, msg, function (rv_mes) {
            if (rv_mes === -1) {
                cc.log('请检查网络！');
            } else {
                rv_mes = JSON.parse(rv_mes);
                cc.log(rv_mes);
                if (rv_mes.Type === 10015) {
                    setTimeout(function () {
                        self.Polling();
                    }, 1000);
                    cc.log("未找到对手");
                } else if (rv_mes.Type === 10014) {
                    userdata.restBlackCount = rv_mes.RestCard.black;
                    userdata.restWhiteCount = rv_mes.RestCard.white;
                    card.Init_four_players(rv_mes);
                    cc.log("找到对手");
                    //向聊天服务器发送请求连接聊天室
                    userdata.chatRoomKey = rv_mes.Key;
                    setTimeout(function () {
                        cc.director.loadScene("WaitingGameScene");
                    }, 1000);
                }
            }
        });
    },

    update: function update(dt) {
        var self = this;
        soket.getChatMsg();
    }
});

cc._RF.pop();
},{"CardActivity":"CardActivity","HttpUtils":"HttpUtils","SoketUtils":"SoketUtils","UserData":"UserData"}],"HelpTips":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'cdabbzxdQ1DoLhZ/EccETbj', 'HelpTips');
// Script/HelpTips.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        helpbg: { //help弹出框的背景
            default: null,
            type: cc.Node
        }
    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        self.helpbg.on('touchstart', self.eatTouch, self);
    },

    eatTouch: function eatTouch(event) {
        cc.log('eatTouch');
        event.stopPropagation();
    },
    close: function close() {
        this.node.destroy();
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{}],"HttpUtils":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'b44f7DHIJ5Pq4P6vu5Fg3U/', 'HttpUtils');
// Script/HttpUtils.js

"use strict";

//httpUtils.js脚本用作模板module，提供向服务器发送消息，接收消息等功能
module.exports = {
    isBackToHall: false,
    //向服务端发送post命令,要求改变信息
    HttpPost: function HttpPost(url, params, callback) {
        if (this.isBackToHall == true) {
            cc.log("返回大厅了");
        } else {
            var xhr = cc.loader.getXMLHttpRequest();
            xhr.open("POST", url, true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status >= 200 && xhr.status < 300) {
                    var response = xhr.responseText;
                    callback(response);
                } else {
                    callback(-1);
                }
            };
            xhr.send(params);
        }
    }

};

cc._RF.pop();
},{}],"ItemFriend":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'd1511NbBrtC4ahFp22gPpBi', 'ItemFriend');
// Script/ItemFriend.js

"use strict";

var userdata = require('UserData');
cc.Class({
    extends: cc.Component,
    properties: {
        id: cc.Label,
        icon: cc.Sprite,
        friendName: cc.Label,
        friendGrade: cc.Label
    },

    init: function init(data) {
        this.id.string = data.id;
        this.icon.spriteFrame = data.iconSF;
        this.friendName.string = data.itemName;
        this.friendGrade.string = data.itemGrade;
    },

    //好友列表item的点击响应函数
    SelectFriend: function SelectFriend(node) {
        var self = this;
        var id = node.getChildByName("id").getComponent(cc.Label).string;
        var name = node.getChildByName("name").getComponent(cc.Label).string;
        node.on(cc.Node.EventType.TOUCH_START, function (event) {
            node.interactable = node.getComponent(cc.Button).interactable;
            if (!node.interactable) {
                return;
            }
            userdata.selectedFriendName = self.friendName.string;
            userdata.selectedFriendID = self.id.string;
            if (id == userdata.selectedFriendID) {
                node.getChildByName("selecting").active = true;
            }
            if (name == userdata.selectedFriendName) {
                node.getChildByName("selecting").active = true;
            }
            cc.log(userdata.selectedFriendName);
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_Move, function (event) {
            if (!node.interactable) {
                return;
            }
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_END, function (event) {
            if (!node.interactable) {
                return;
            }
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_CANCEL, function (event) {
            if (!node.interactable) {
                return;
            }
        }.bind(this));
    },

    onLoad: function onLoad() {
        var self = this;
        self.SelectFriend(this.node);
    }
});

cc._RF.pop();
},{"UserData":"UserData"}],"ItemMail":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'b0452xIE6lOHIDhM8VbtqpG', 'ItemMail');
// Script/ItemMail.js

"use strict";

var userdata = require('UserData');
cc.Class({
    extends: cc.Component,
    properties: {
        id: cc.Label,
        icon: cc.Sprite,
        title: cc.Label
    },

    init: function init(data) {
        this.id.string = data.id;
        this.icon.spriteFrame = data.iconSF;
        this.title.string = data.title;
    },

    //好友列表item的点击响应函数
    SelectFriend: function SelectFriend(node) {
        var self = this;
        var id = node.getChildByName("id").getComponent(cc.Label).string;
        node.on(cc.Node.EventType.TOUCH_START, function (event) {
            node.interactable = node.getComponent(cc.Button).interactable;
            if (!node.interactable) {
                return;
            }
            cc.log("点击查看邮件");
            userdata.selectedMailID = self.id.string;
            if (id == userdata.selectedMailID) {
                node.getChildByName("selecting").active = true;
            }
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_Move, function (event) {
            if (!node.interactable) {
                return;
            }
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_END, function (event) {
            if (!node.interactable) {
                return;
            }
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_CANCEL, function (event) {
            if (!node.interactable) {
                return;
            }
        }.bind(this));
    },

    onLoad: function onLoad() {
        var self = this;
        self.SelectFriend(this.node);
    }
});

cc._RF.pop();
},{"UserData":"UserData"}],"LoginScene":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'dcf79OXlbFMlLqJkzYaiZGQ', 'LoginScene');
// Script/LoginScene.js

"use strict";

var http = require('HttpUtils');
var userdata = require("UserData");
cc.Class({
    extends: cc.Component,
    properties: {
        idEditBox: {
            default: null,
            type: cc.EditBox
        },
        padEditBox: {
            default: null,
            type: cc.EditBox
        }
    },

    // use this for initialization
    onLoad: function onLoad() {},

    ToHall: function ToHall() {
        var self = this;
        var url = "http://192.168.0.229:8080/test";
        userdata.mname = self.idEditBox.string;
        var content = JSON.stringify({
            Type: 10001,
            Uid: self.idEditBox.string,
            Psd: self.padEditBox.string
        });
        content = JSON.parse(content);
        var id_mes = JSON.stringify({
            Content: content
        });
        content = "msg=" + id_mes;
        cc.log(content);
        http.HttpPost(url, content, function (rv_mes) {
            if (rv_mes === -1) {
                //console.log("请检查网络");
            } else {
                cc.log(rv_mes);
                var rv = JSON.parse(rv_mes);
                if (rv.Type === 10002) {
                    cc.log("6666");
                    userdata.id = rv.ID;
                    userdata.grade = rv.Grade;
                    var bg = cc.find("Canvas/bg");
                    // var seq2=cc.sequence(cc.fadeOut(1),cc.delayTime(1.01),cc.callFunc(
                    // function(){
                    cc.director.loadScene("HallScene");
                    // }));
                    // bg.runAction(seq2);
                } else if (rv.Type === 10003) {
                    cc.log("5555");
                }
            }
        });
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{"HttpUtils":"HttpUtils","UserData":"UserData"}],"MailList":[function(require,module,exports){
"use strict";
cc._RF.push(module, '41e59w43LdLMY4AYqDfIl7v', 'MailList');
// Script/MailList.js

'use strict';

var userdata = require('UserData');
var friend = require('FriendActivity');
var http = require('HttpUtils');
var soket = require("SoketUtils");
var Item3 = cc.Class({
    name: "Item3",
    properties: {
        id: 0,
        friendName: "",
        friendIcon: cc.SpriteFrame
    }
});

cc.Class({
    extends: cc.Component,
    properties: {
        items: {
            default: [],
            type: Item3
        },
        itemMailPrefab: cc.Prefab,
        headAtlas: {
            default: null,
            type: cc.SpriteAtlas
        },
        mailListContent: { //邮件列表内容
            default: null,
            type: cc.Node
        },
        mailBox: { //邮箱
            default: null,
            type: cc.Node
        },
        mailDetail: { //邮件具体信息浮框
            default: null,
            type: cc.Node
        },
        mailAddresser: { //邮件发件人
            default: null,
            type: cc.Label
        },
        mailDetailContent: { //邮件具体信息内容
            default: null,
            type: cc.Node
        },
        mailDetailLabel: { //邮件具体信息文本
            default: null,
            type: cc.Label
        }
    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        userdata.selectedMailID = null;
        var e4 = JSON.stringify({ Type: 300000,
            "MailList": [{ "ID": 1, "FriendIcon": "head1", "FriendName": "aa撒旦", "Content": "唐太宗李世民（公元598年1月28日【一说599年1月23日】－公元649年7月10日），生于武功之别馆（今陕西武功），是唐高祖李渊和窦皇后的次子，唐朝第二位皇帝，杰出的政治家、战略家、军事家、诗人。李世民少年从军，曾去雁门关营救隋炀帝。唐朝建立后，李世民官居尚书令、右武候大将军，受封为秦国公，后晋封为秦王，先后率部平定了薛仁杲、刘武周、窦建德、王世充等军阀，在唐朝的建立与统一过程中立下赫赫战功。公元626年7月2日（武德九年六月初四），李世民发动“玄武门之变”，杀死自己的兄长太子李建成、四弟齐王李元吉及二人诸子，被立为太子，唐高祖李渊不久退位，李世民即位，改元贞观。[1] 李世民为帝之后，积极听取群臣的意见，对内以文治天下，虚心纳谏，厉行节约，劝课农桑，使百姓能够休养生息，国泰民安，开创了中国历史上著名的贞观之治。对外开疆拓土，攻灭东突厥与薛延陀，征服高昌、龟兹、吐谷浑，重创高句丽，设立安西四镇，各民族融洽相处，被各族人民尊称为天可汗，为后来唐朝一百多年的盛世奠定重要基础。公元649年7月10日（贞观二十三年五月己巳日），李世民因病驾崩于含风殿，享年五十二岁，在位二十三年，庙号太宗，葬于昭陵。李世民爱好文学与书法，有墨宝传世。" }, { "ID": 2, "FriendIcon": "head2", "FriendName": "bbb撒旦", "Content": "22222222222222222222" }, { "ID": 3, "FriendIcon": "head3", "FriendName": "钟宇翔", "Content": "33333333333333333333" }, { "ID": 4, "FriendIcon": "head4", "FriendName": "ddd", "Content": "444444444444444" }, { "ID": 5, "FriendIcon": "head5", "FriendName": "Jack black", "Content": "555555555555555555555" }, { "ID": 6, "FriendIcon": "head6", "FriendName": "fff", "Content": "666666666666666666666" }, { "ID": 8, "FriendIcon": "head8", "FriendName": "hhh", "Content": "77777777777777777777777" }, { "ID": 9, "FriendIcon": "head9", "FriendName": "iii", "Content": "你好你好你ssss好你好" }, { "ID": 10, "FriendIcon": "head10", "FriendName": "jjj", "Content": "你好你好qq你好" }, { "ID": 11, "FriendIcon": "head11", "FriendName": "kkk", "Content": "你好你好dd你好你好你好你好" }]
        });

        e4 = JSON.parse(e4);
        friend.Init_mail(e4);
        cc.log(userdata.mailInfo);
        self.items.length = userdata.mailInfo.length;
        for (var i = 0; i < self.items.length; ++i) {
            var item = cc.instantiate(self.itemMailPrefab);
            self.items[i] = userdata.mailInfo[i];
            var data = self.items[i];
            self.node.addChild(item);
            item.getComponent('ItemMail').init({
                id: data.ID,
                title: "标题：来自" + self.IgnoreLongName(data.FriendName) + "..的邮件",
                iconSF: self.headAtlas.getSpriteFrame(data.FriendIcon)
            });
        }
    },

    //如果邮件标题中玩家姓名过长，自动省略从第4位开始的字符
    IgnoreLongName: function IgnoreLongName(longName) {
        var self = this;
        var ignoreedName = longName.slice(0, 3);;
        return ignoreedName;
    },

    //删除邮件按钮响应函数
    DeleteMail: function DeleteMail() {
        var self = this;
        //此处给服务器发送请求
        if (userdata.selectedMailID == null) {
            cc.log("请先选择想删除的邮件.");
        } else {
            friend.Delete_mail(userdata.selectedMailID);
            cc.log(userdata.mailInfo);
            self.UpdateMailList();
            cc.log("列表邮件item数量:" + self.mailListContent.children.length);
        }

        userdata.selectedMailID = null;
    },

    //更新邮件列表
    UpdateMailList: function UpdateMailList() {
        var self = this;
        self.mailListContent.removeChild(self.GetRemovedItem(userdata.selectedMailID));
    },

    //查看邮件具体内容按钮响应函数
    ReadMail: function ReadMail() {
        var self = this;
        if (userdata.selectedMailID == null) {
            cc.log("请先选择想查看的邮件.");
        } else {
            self.mailDetail.active = true;
            cc.log("mailID" + userdata.selectedMailID);
            for (var i = 0; i < userdata.mailInfo.length; ++i) {
                var id = userdata.mailInfo[i].ID;
                if (id == userdata.selectedMailID) {
                    self.mailAddresser.string = "发件人：" + userdata.mailInfo[i].FriendName;
                    self.mailDetailLabel.string = "\n" + "\n" + "邮件信息如下:" + "\n" + userdata.mailInfo[i].Content;
                }
            }
        }
        cc.log(self.mailDetailLabel.string.length);
    },

    CloseMail: function CloseMail() {
        var self = this;
        self.mailDetail.active = false;
        userdata.selectedMailID = null;
    },

    //确定要移除的item
    GetRemovedItem: function GetRemovedItem(mailID) {
        var self = this;
        for (var i = 0; i < self.mailListContent.children.length; ++i) {
            var id = self.mailListContent.children[i].getChildByName("id").getComponent(cc.Label).string;
            if (id == mailID) {
                return self.mailListContent.children[i];
            }
        }
    },

    //标记当前点击的邮件
    SignSelectedFriend: function SignSelectedFriend() {
        var self = this;
        for (var i = 0; i < self.mailListContent.children.length; ++i) {
            var id = self.mailListContent.children[i].getChildByName("id").getComponent(cc.Label).string;
            if (id == userdata.selectedMailID) {
                self.mailListContent.children[i].getChildByName("selecting").active = true;
            } else {
                self.mailListContent.children[i].getChildByName("selecting").active = false;
            }
        }
    },

    //更新邮件内容的高度
    UpdateMailHeight: function UpdateMailHeight() {
        var self = this;
        var count = Math.round(self.mailDetailLabel.string.length / 22);
        self.mailDetailContent.height = 200 + count * 35;
    },

    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {
        var self = this;
        self.mailListContent.height = 230 + userdata.mailInfo.length * 60;
        self.SignSelectedFriend();
        self.UpdateMailHeight();
    }
});

cc._RF.pop();
},{"FriendActivity":"FriendActivity","HttpUtils":"HttpUtils","SoketUtils":"SoketUtils","UserData":"UserData"}],"SearchedFriendsList":[function(require,module,exports){
"use strict";
cc._RF.push(module, '7621eGxyIFBNZeS/EIIfBmf', 'SearchedFriendsList');
// Script/SearchedFriendsList.js

'use strict';

var userdata = require('UserData');
var friend = require('FriendActivity');
var http = require('HttpUtils');
var soket = require("SoketUtils");
var Item2 = cc.Class({
    name: "Item2",
    properties: {
        id: 0,
        friendName: "",
        friendGrade: 0,
        friendIcon: cc.SpriteFrame
    }
});

cc.Class({
    extends: cc.Component,

    properties: {
        items: {
            default: [],
            type: Item2
        },
        itemFriendPrefab: cc.Prefab,
        headAtlas: {
            default: null,
            type: cc.SpriteAtlas
        },
        friendListContent: { //好友列表内容
            default: null,
            type: cc.Node
        },
        searchedFriendName: { //输入的搜索的好友姓名
            default: null,
            type: cc.EditBox
        },
        searchedFriendListContent: { //搜索的好友列表内容
            default: null,
            type: cc.Node
        },
        friendList: { //现有的的玩家列表
            default: null,
            type: cc.Node
        },
        searchedfriendList: { //搜索的玩家列表
            default: null,
            type: cc.Node
        },
        friendChatName1: { //聊天，显示正选择的好友
            default: null,
            type: cc.Label
        },
        friendChatName2: { //邮件，显示正选择的好友
            default: null,
            type: cc.Label
        },
        searchCount: 0
    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
    },

    //搜索根据昵称搜索玩家按钮响应函数
    SearchFriend: function SearchFriend() {
        var self = this;
        self.searchCount += 1;
        userdata.selectedFriendID = null;
        self.friendList.active = false;
        self.searchedfriendList.active = true;
        //此处给服务器发送请求
        var content = JSON.stringify({ Type: 10057,
            Words: self.searchedFriendName.string
        });

        if (self.searchedFriendName.string != "") {
            //发送搜索姓名不为空时
            cc.log("向好友服务器发送请求搜索好友消息：");
            cc.log(JSON.parse(content));
            cc.log(2);
            soket.ws.send(content); //发送消息 
            soket.getChatMsg(); //监听获取信息 
        } else {
            self.friendList.active = true;
            self.searchedfriendList.active = false;
        }
        self.searchedFriendName.Placeholder = "在此输入搜索姓名.......";
    },

    //初始化搜索玩家列表
    InitSearchedFriend: function InitSearchedFriend() {
        var self = this;
        if (userdata.searchFriendInfo == null) {} else {
            //  cc.log(self.searchCount);
            //  if(self.searchCount>1){
            //     self.ClearSearched();
            // }
            for (var i = self.searchedFriendListContent.children.length - 1; i >= 0; i--) {
                self.searchedFriendListContent.removeChild(self.searchedFriendListContent.children[i]);
            }
            self.items.length = userdata.searchFriendInfo.length;
            for (var i = 0; i < self.items.length; ++i) {
                var item = cc.instantiate(self.itemFriendPrefab);
                item.color = new cc.Color(0, 191, 255);
                self.items[i] = userdata.searchFriendInfo[i];
                var data = self.items[i];
                self.node.addChild(item);
                item.getComponent('ItemFriend').init({
                    id: data.ID,
                    itemName: data.FriendName,
                    itemGrade: "分数:" + data.FriendGrade,
                    iconSF: self.headAtlas.getSpriteFrame(data.FriendIcon)
                });
            }
            self.searchedFriendListContent.height = 200 + userdata.searchFriendInfo.length * 60;
        }
    },

    //增加好友按钮响应函数
    AddFriend: function AddFriend() {
        var self = this;
        //此处给服务器发送请求

        if (self.friendList.active == false && self.searchedfriendList.active == true) {
            if (userdata.selectedFriendID == null) {
                cc.log("请先选择想添加的好友.");
            } else if (self.Contains(userdata.friendInfo, userdata.selectedFriendID)) {
                cc.log("现有好友中已存在想增加的好友");
                self.friendList.active = true;
                self.searchedfriendList.active = false;
            } else {
                var content = JSON.stringify({ Type: 10061,
                    Name: self.GetAddItem(userdata.selectedFriendID).FriendName
                });
                cc.log("向好友服务器发送请求增加好友消息：");
                cc.log(JSON.parse(content));
                soket.ws.send(content); //发送消息 
                soket.getChatMsg(); //监听获取信息
            }
        } else {
            cc.log("请先搜索想添加的好友.");
        }
    },

    //响应增加好友函数
    AnswerAddFriend: function AnswerAddFriend() {
        var self = this;
        if (soket.isSendAddFriend == true) {
            soket.isSendAddFriend = false;
            // self.friendList.active = true;
            // self.searchedfriendList.active = false;
        }

        if (soket.isAddFriend == true) {
            cc.log("已经增加好友成功");
            self.UpdateFriendList();
            soket.isAddFriend = false;
            self.friendList.active = true;
            self.searchedfriendList.active = false;
            userdata.selectedFriendName = null;
            userdata.selectedFriendID = null;
        }

        if (soket.isRejectAddFriend == true) {
            cc.log("该玩家已经拒绝添加好友");
            soket.isRejectAddFriend = false;
            self.friendList.active = true;
            self.searchedfriendList.active = false;
            userdata.selectedFriendName = null;
            userdata.selectedFriendID = null;
        }
    },

    //请求方更新好友列表
    UpdateFriendList: function UpdateFriendList() {
        var self = this;
        self.friendList.active = true;
        var item = cc.instantiate(self.itemFriendPrefab);
        var data = self.GetAddItem(userdata.selectedFriendID);
        item.getComponent('ItemFriend').init({
            id: data.ID,
            itemName: data.FriendName,
            itemGrade: "分数:" + data.FriendGrade,
            iconSF: self.headAtlas.getSpriteFrame(data.FriendIcon)
        });
        self.friendListContent.addChild(item);
        self.ClearSearched();
    },

    //清空搜索列表
    ClearSearched: function ClearSearched() {
        var self = this;
        for (var i = self.searchedFriendListContent.children.length - 1; i >= 0; i--) {
            self.searchedFriendListContent.removeChild(self.searchedFriendListContent.children[i]);
        }
        friend.Clear_list(userdata.searchFriendInfo);
    },
    //确定要增加的item
    GetAddItem: function GetAddItem(friendID) {
        var self = this;
        for (var i = 0; i < userdata.searchFriendInfo.length; ++i) {
            var id = userdata.searchFriendInfo[i].ID;
            if (id == friendID) {
                return userdata.searchFriendInfo[i];
            }
        }
    },

    //标记当前点击的好友
    SignSelectedFriend: function SignSelectedFriend() {
        var self = this;
        for (var i = 0; i < self.searchedFriendListContent.children.length; ++i) {
            var id = self.searchedFriendListContent.children[i].getChildByName("id").getComponent(cc.Label).string;
            if (id == userdata.selectedFriendID) {
                self.searchedFriendListContent.children[i].getChildByName("selecting").active = true;
            } else {
                self.searchedFriendListContent.children[i].getChildByName("selecting").active = false;
            }
        }
    },

    //判断现有好友中是否已存在想增加的好友
    Contains: function Contains(array, friendID) {
        var self = this;
        for (var i = 0; i < array.length; ++i) {
            var id = array[i].ID;
            if (id == friendID) {
                return true; //存在
            }
        }
        return false;
    },
    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {
        var self = this;
        soket.getChatMsg(); //监听获取信息 
        self.friendChatName1.string = "聊天好友：" + userdata.selectedFriendName + "  " + userdata.selectedFriendID;
        self.friendChatName2.string = "收件人：" + userdata.selectedFriendName + "  " + userdata.selectedFriendID;
        self.InitSearchedFriend();
        self.AnswerAddFriend();
        self.SignSelectedFriend();
    }
});

cc._RF.pop();
},{"FriendActivity":"FriendActivity","HttpUtils":"HttpUtils","SoketUtils":"SoketUtils","UserData":"UserData"}],"SoketUtils":[function(require,module,exports){
"use strict";
cc._RF.push(module, '0231aRLgjlBq46TN4eRgbnC', 'SoketUtils');
// Script/SoketUtils.js

'use strict';

var friend = require('FriendActivity');
var userdata = require('UserData');
//soket工具模板
module.exports = {
    ws: null,
    mes: null,
    //游戏内聊天
    chatString: "玩家发言如下：", //游戏内聊天信息
    chatHeightAdd: 0, //游戏内聊天信息框高度增加
    seat: Array(), //收到的用户的座位号
    name: Array(), //收到的用户的姓名

    //好友系统（增删好友）
    isAddFriend: false, //是否增加好友
    isSendAddFriend: false, //是否已发送增加好友
    isRejectAddFriend: false, //是否拒绝增加好友
    isDeleteFriend: false, //是否删除好友
    hasBeenDeleted: false, //是否已被删除好友

    //好友系统（好友间聊天）
    chatFriend: Array(), //和好友聊天信息
    isInitChat: false, //是否初始化和好友的聊天信息

    connect: function connect() {
        var self = this;
        self.ws = new WebSocket("ws://192.168.0.229:1080/ws", []);
    },
    close_ws: function close_ws() {
        var self = this;
        self.ws.close();
    },
    //收到聊天服务器的返回值
    getChatMsg: function getChatMsg() {
        var self = this;
        self.ws.onmessage = function (e) {
            self.mes = e.data;
            cc.log("连接服务器成功......");
            cc.log("收到服务器消息");
            self.mes = JSON.parse(self.mes);
            cc.log(self.mes);
            switch (self.mes.Type) {
                case 10042:
                    cc.log("本用户进入聊天室成功ID为：" + self.mes.Name);
                    self.seat.push(self.mes.Mseat);
                    self.name.push(self.mes.Name);
                    break;
                case 10046:
                    self.chatHeightAdd += 1; //content增加一次高度
                    self.chatString = self.chatString + "\n" + self.mes.Name + " 发言：" + self.mes.Text;
                    cc.log(self.chatString);
                    break;
                case 10050:
                    cc.log("本用户进入聊天室失败");
                    break;
                case 10055:
                    cc.log("本用户收到好友信息");
                    friend.friendNum = self.mes.Fnum;
                    if (userdata.friendInfo != null && userdata.friendInfo.length != 0) {
                        friend.Clear_list(userdata.friendInfo);
                    }
                    friend.Init_friend(self.mes.Friends);
                    self.isInitChat = true;
                    break;
                case 10058:
                    cc.log("本用户收到搜索好友信息");
                    friend.searchFriendNum = self.mes.Fnum;
                    if (userdata.searchFriendInfo != null && userdata.searchFriendInfo.length != 0) {
                        friend.Clear_list(userdata.searchFriendInfo);
                    }
                    friend.Init_search_friend(self.mes.Friends);
                    break;
                case 10071:
                    self.isDeleteFriend = true;
                    cc.log("删除好友成功");
                    friend.Delete_friend(userdata.selectedFriendID);
                    break;
                case 10072:
                    cc.log("你被删除好友了");
                    self.hasBeenDeleted = true;
                    break;
                case 10063:
                    self.isAddFriend = true;
                    cc.log("增加好友成功");
                    friend.Add_friend(userdata.selectedFriendID);
                    break;
                case 10064:
                    cc.log("该玩家离线或不存在");
                    break;
                case 10065:
                    cc.log("该玩家拒绝好友请求");
                    self.isRejectAddFriend = true;
                    break;
                case 10066:
                    cc.log("好友请求已发送");
                    self.isSendAddFriend = true;
                    break;
                case 10068:
                    cc.log("出现好友请求");
                    friend.Init_asking_friend(self.mes);
                    break;
                case 10076:
                    cc.log("聊天信息已发送");
                    break;
                case 10078:
                    cc.log("聊天信息已转发成功");
                    self.chatFriend[self.mes.P_id].chatFriendHeightAdd += 1; //content增加一次高度
                    self.chatFriend[self.mes.P_id].chatFriendString = self.chatFriend[self.mes.P_id].chatFriendString + "\n" + friend.GetFriendName(self.mes.P_id) + "：" + self.mes.Text;
                    break;
                default:
                    break;
            }
        };
    }
};

cc._RF.pop();
},{"FriendActivity":"FriendActivity","UserData":"UserData"}],"UserData":[function(require,module,exports){
"use strict";
cc._RF.push(module, '8440bnVTKhDYI49gJhcjDOw', 'UserData');
// Script/UserData.js

"use strict";

//储存用户ID，以及每局对战的牌信息
module.exports = {
    mname: null, //自己的名字
    id: null, //对战id
    mgrade: null, //自己的积分
    token: null, //
    oname: null, //对面玩家的名字
    ograde: null, //对面玩家的积分
    lname: null, //左边玩家的名字
    lgrade: null, //左边玩家的积分
    rname: null, //右边玩家的名字
    rgrade: null, //右边玩家的积分
    mseat: null, //自己的座位号
    oseat: null, //对面玩家座位号
    lseat: null, //左边玩家座位号
    rseat: null, //右边玩家座位号
    mcard: null, //储存自己牌的map
    ocard: null, //储存对面玩家牌的map
    lcard: null, //储存左边玩家牌的map
    rcard: null, //储存右边玩家牌的map
    ftplayer: null, //先手摸牌玩家
    tcard: null, //单摸的牌的信息
    guessedman: null, //被猜牌的玩家座位号
    guessedcard: null, //被猜牌的信息
    surplus: null, //剩余卡牌堆张数
    insert_count: null, //插牌次数
    restcard: null, //牌堆是否剩余牌
    cardsAreNull: null, //判断牌堆恰好为为空
    chatRoomKey: null, //聊天室编号
    restBlackCount: null, //开始游戏时牌池剩余的黑牌数
    restWhiteCount: null, //开始游戏时牌池剩余的白牌数
    round: null, //当前回合数
    friendInfo: null, //存储好友信息
    selectedFriendName: "", //选择的好友名
    selectedFriendID: null, //选择的好友id
    searchFriendInfo: null, //存储搜索的玩家信息
    askingFriendInfo: null, //存储请求玩家信息
    mailInfo: null, //存储邮件信息
    selectedMailID: null };

cc._RF.pop();
},{}],"WaitingGameScene":[function(require,module,exports){
"use strict";
cc._RF.push(module, '605e7wll1NNj7FSdvmKkiJt', 'WaitingGameScene');
// Script/WaitingGameScene.js

'use strict';

var http = require('HttpUtils');
cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {
        var waitingTime = 2000;
        setTimeout(function () {
            cc.director.loadScene('GameScene');
        }, waitingTime);
    }

});

cc._RF.pop();
},{"HttpUtils":"HttpUtils"}],"WelcomeScene":[function(require,module,exports){
"use strict";
cc._RF.push(module, '0f8b4EzTo5GlrK13FIwTw23', 'WelcomeScene');
// Script/WelcomeScene.js

'use strict';

var http = require('HttpUtils');
var userdata = require("UserData");
cc.Class({
    extends: cc.Component,

    properties: {
        label1: {
            default: null,
            type: cc.Node
        },
        label2: {
            default: null,
            type: cc.Node
        },
        startGame: {
            default: null,
            type: cc.Node
        }

    },

    // use this for initialization
    onLoad: function onLoad() {
        this.label1.getComponent(cc.Animation).play('label1_moveright');
        this.label2.getComponent(cc.Animation).play('label2_moveright');
        this.startGame.getComponent(cc.Animation).play('startGame_moveright');
    },
    //点击开始游戏，跳转到登陆界面 
    ToLogin: function ToLogin() {
        var bg = cc.find("Canvas/bg1");
        var seq2 = cc.sequence(cc.fadeOut(1), cc.delayTime(1.01), cc.callFunc(function () {
            cc.director.loadScene("LoginScene");
        }));
        bg.runAction(seq2);
    }
});

cc._RF.pop();
},{"HttpUtils":"HttpUtils","UserData":"UserData"}]},{},["AskingFriendList","CardActivity","CardMgr","FloatingBox","FriendActivity","FriendsList","GameOver","GameScene","HallScene","HelpTips","HttpUtils","ItemFriend","ItemMail","LoginScene","MailList","SearchedFriendsList","SoketUtils","UserData","WaitingGameScene","WelcomeScene"])

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHQvQXNraW5nRnJpZW5kTGlzdC5qcyIsImFzc2V0cy9TY3JpcHQvQ2FyZEFjdGl2aXR5LmpzIiwiYXNzZXRzL1NjcmlwdC9DYXJkTWdyLmpzIiwiYXNzZXRzL1NjcmlwdC9GbG9hdGluZ0JveC5qcyIsImFzc2V0cy9TY3JpcHQvRnJpZW5kQWN0aXZpdHkuanMiLCJhc3NldHMvU2NyaXB0L0ZyaWVuZHNMaXN0LmpzIiwiYXNzZXRzL1NjcmlwdC9HYW1lT3Zlci5qcyIsImFzc2V0cy9TY3JpcHQvR2FtZVNjZW5lLmpzIiwiYXNzZXRzL1NjcmlwdC9IYWxsU2NlbmUuanMiLCJhc3NldHMvU2NyaXB0L0hlbHBUaXBzLmpzIiwiYXNzZXRzL1NjcmlwdC9IdHRwVXRpbHMuanMiLCJhc3NldHMvU2NyaXB0L0l0ZW1GcmllbmQuanMiLCJhc3NldHMvU2NyaXB0L0l0ZW1NYWlsLmpzIiwiYXNzZXRzL1NjcmlwdC9Mb2dpblNjZW5lLmpzIiwiYXNzZXRzL1NjcmlwdC9NYWlsTGlzdC5qcyIsImFzc2V0cy9TY3JpcHQvU2VhcmNoZWRGcmllbmRzTGlzdC5qcyIsImFzc2V0cy9TY3JpcHQvU29rZXRVdGlscy5qcyIsImFzc2V0cy9TY3JpcHQvVXNlckRhdGEuanMiLCJhc3NldHMvU2NyaXB0L1dhaXRpbmdHYW1lU2NlbmUuanMiLCJhc3NldHMvU2NyaXB0L1dlbGNvbWVTY2VuZS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUpPO0FBRk07O0FBVXJCO0FBQ0k7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUZFO0FBSU47QUFDQTtBQUNJO0FBQ0E7QUFGTTtBQUlWO0FBQ0k7QUFDQTtBQUZjO0FBSWxCO0FBQ0k7QUFDQTtBQUZPO0FBSVg7QUFDSTtBQUNBO0FBRk87QUFJWDtBQUNJO0FBQ0E7QUFGYztBQXRCVjs7QUE0Qlo7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNQOztBQUVHO0FBQ0E7QUFDSTtBQUNBO0FBQ0Q7QUFHSztBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDUTtBQUNBO0FBQ0E7QUFDQTtBQUo2QjtBQU14QztBQUNKO0FBQ0o7O0FBR0Q7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNIO0FBQ087QUFDQTtBQUM4QjtBQUNBO0FBRkE7QUFJOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVIO0FBQ1I7O0FBR0Q7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNIO0FBQ087QUFDQTtBQUM4QjtBQUNBO0FBRkE7QUFJOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ1I7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDRDtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNKOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBQ0g7O0FBRUQ7QUFDQTtBQUNJO0FBQ0g7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNIO0FBQ0o7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDSDtBQUNHO0FBQ0g7QUFDSjtBQUNKO0FBQ0Q7QUFDQTtBQUNJO0FBQ0E7O0FBRUE7QUFDQTtBQUNIO0FBaEtJOzs7Ozs7Ozs7O0FDZFQ7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDSjs7QUFFRDtBQUNJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNKOztBQUVEO0FBQ0E7QUFDSTtBQUNJO0FBQ0k7QUFDSDtBQUNKO0FBQ0o7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBRUg7QUFDRDtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUg7O0FBRUQ7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUNBO0FBQ0o7QUFDSTtBQUNBO0FBQ0E7QUFDSjtBQUNJO0FBQ0E7QUFDQTtBQUNQO0FBQ0Q7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ0c7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNHO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDRztBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ0Q7QUFDQTtBQUNIOztBQUdEO0FBQ0E7QUFDSTtBQUNJO0FBQ0g7QUFDRztBQUNBO0FBQ0k7QUFDSDtBQUNHO0FBQ0g7QUFDRztBQUNIO0FBQ0o7QUFDSjs7QUFFRDtBQUNBO0FBQ0k7QUFBZ0I7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQztBQUNKOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBQ0g7QUFFRztBQUNBO0FBQ0g7QUFFRztBQUNBO0FBQ0g7QUFFRztBQUNBO0FBQ0g7QUFDSjtBQUNHO0FBQ0E7QUFDSTtBQUNBO0FBQ0g7QUFDRztBQUNBO0FBQ0E7QUFDSDtBQUVHO0FBQ0E7QUFDQTtBQUNIO0FBRUc7QUFDQTtBQUNBO0FBQ0g7QUFDSjtBQUNKOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUFvQztBQUMvQjtBQUFxQjtBQURVO0FBRS9CO0FBQW9CO0FBRlc7QUFHL0I7QUFBcUI7QUFDekI7QUFDSjs7QUFFRDtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUNJO0FBQzhHO0FBQ3pHO0FBQTRCO0FBRDZFO0FBRXpHO0FBQTJCO0FBRjhFO0FBR3pHO0FBQTRCO0FBSDZFO0FBSXpHO0FBQTJCO0FBQy9CO0FBRUo7QUFDSjtBQUNHO0FBQ0g7QUFDSjtBQUNHO0FBQ0g7QUFDRztBQUNIO0FBQ0c7QUFDSDtBQUNKOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSDtBQUNHO0FBQ0g7QUFDRztBQUNIO0FBQ0o7QUF6T1U7Ozs7Ozs7Ozs7QUNGZjtBQUNBO0FBQ0E7QUFDSTs7QUFFQTtBQUNFO0FBQ007QUFDQTtBQUZJOztBQUtSO0FBQ0k7QUFDQTtBQUZPOztBQUtYO0FBQ0k7QUFDQTtBQUZVOztBQUtkO0FBQ0k7QUFDQTtBQUZROztBQUtaO0FBQ0k7QUFDQTtBQUZTOztBQUtiO0FBQ0E7QUFDQTs7QUE1QlE7O0FBZ0NaO0FBQ0E7QUFDRTtBQUNBO0FBQ0E7O0FBR0E7QUFDQTtBQUNJO0FBQ0w7QUFDQTs7QUFFRDtBQUNBO0FBQ0k7QUFDSDs7QUFFRDtBQUNBO0FBQ0k7QUFDQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNDO0FBQ0w7O0FBRUY7QUFDQztBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0g7QUFBb0I7QUFDakI7QUFDSDtBQUNHO0FBQ0o7QUFDQztBQUNKO0FBRUc7QUFDSTtBQUNBO0FBQ0g7QUFDRztBQUNBO0FBQ0g7QUFDRztBQUNBO0FBQ0g7QUFDSjtBQUVHO0FBQ0k7QUFDQTtBQUNIO0FBQ0c7QUFDQTtBQUNIO0FBQ0c7QUFDRjtBQUNEO0FBQ0o7QUFFRztBQUNJO0FBQ0E7QUFDSDtBQUNHO0FBQ0E7QUFDSDtBQUNHO0FBQ0Y7QUFDRDtBQUNKO0FBQ0o7O0FBdEhJOzs7Ozs7Ozs7O0FDRlQ7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUZRO0FBSVo7QUFDQTtBQUNJO0FBQ0E7QUFGUztBQU5MOztBQVlaO0FBQ0E7QUFDSTtBQUNBO0FBQ0g7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDRztBQUNGO0FBQ1E7QUFDUjs7QUFFRDtBQUNHO0FBQ0Y7QUFDRTtBQUNGO0FBQ0o7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7O0FBRUQ7QUFDQztBQUNJO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNGO0FBcERHOzs7Ozs7Ozs7O0FDRlQ7QUFDQTtBQUNBO0FBQ1E7QUFDQTtBQUNSO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDUTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ1I7O0FBRUQ7QUFDSTtBQUNBO0FBQ0E7QUFDUTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ1I7O0FBRUQ7QUFDWTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDWDs7QUFFRDtBQUNBO0FBQ0k7QUFDUTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNSO0FBQ0Q7QUFDQTtBQUNJO0FBQ0E7QUFDSDs7QUFFRDtBQUNBO0FBQ0k7QUFDSTtBQUNIO0FBQ0Q7QUFDQTtBQUNDO0FBQ0o7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDSDs7QUFFRDtBQUNBO0FBQ0k7QUFDQTtBQUNIOztBQUVEO0FBQ0E7QUFDSTtBQUNRO0FBQ0E7QUFDRztBQUNBO0FBQ0Y7QUFDSjtBQUNSOztBQUVEO0FBQ0E7QUFDSTtBQUNRO0FBQ0E7QUFDRztBQUNBO0FBQ0Y7QUFDSjtBQUNSOztBQUdEO0FBQ0E7QUFDSTtBQUNRO0FBQ0E7QUFDRztBQUNBO0FBQ0Y7QUFDSjtBQUNSOztBQUVEO0FBQ0E7QUFDSTtBQUNRO0FBQ0E7QUFDRztBQUNBO0FBQ0Y7QUFDSjtBQUNSOztBQUVEO0FBQ0E7QUFDSTtBQUNRO0FBQ0E7QUFDRztBQUNGO0FBQ0o7QUFDUjs7QUFFRDtBQUNBO0FBQ0k7QUFDSDs7QUExSWM7Ozs7Ozs7Ozs7QUNGZjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBSk87QUFGSzs7QUFVcEI7QUFDSTs7QUFFQTtBQUNJO0FBQ0k7QUFDQTtBQUZFO0FBSU47QUFDQTtBQUNJO0FBQ0E7QUFGTTtBQUlWO0FBQ0k7QUFDQTtBQUZjO0FBSWxCO0FBQ0k7QUFDQTtBQUZPO0FBSVg7QUFDSTtBQUNBO0FBRlk7QUFJaEI7QUFDSTtBQUNBO0FBRks7QUFJVDtBQUNJO0FBQ0E7QUFGUTtBQUlaO0FBQ0k7QUFDQTtBQUZNO0FBSVY7QUFDSTtBQUNBO0FBRlk7QUFJaEI7QUFDSTtBQUNBO0FBRks7QUFJVDtBQTFDUTs7QUE2Q1o7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBRUg7O0FBR0Q7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUE4QjtBQUU5QjtBQUNBO0FBQ0E7QUFDQTtBQUNIOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBR0k7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFKaUM7QUFNeEM7QUFDRDtBQUNIO0FBQ0o7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNIO0FBQ0o7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0g7QUFDTztBQUNBO0FBQzRCO0FBREU7QUFHOUI7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNKO0FBQ0c7QUFDSDtBQUNKO0FBQ0Q7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNEO0FBQ0k7QUFDQTtBQUNIO0FBQ0o7O0FBRUQ7QUFDQTtBQUNJO0FBQ0k7QUFDUDs7QUFFRDtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNIO0FBQ0o7QUFDSjs7QUFFRDtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNIO0FBQ0c7QUFDSDtBQUNKO0FBQ0o7O0FBRUQ7QUFDQztBQUNHO0FBQ0E7QUFDQTtBQUNtQztBQUNBO0FBQ0E7QUFIRDtBQUtsQztBQUNBO0FBQTZCO0FBQzdCO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBR0M7QUFDRztBQUNBO0FBQ0k7QUFDSDtBQUNKO0FBQ0Q7QUFDQTtBQUNIOztBQUVEO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNEO0FBQ0g7O0FBRUQ7QUFDQztBQUNHO0FBQ0E7QUFDQTtBQUNtQztBQUNBO0FBQ0E7QUFDQTtBQUpEO0FBTWxDO0FBQ0E7QUFBNkI7QUFDN0I7QUFDQTtBQUNBO0FBQ0M7QUFDRztBQUNBO0FBQ0k7QUFDSDtBQUNKO0FBQ0Q7QUFDQTtBQUNIOztBQUdEO0FBQ0k7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDSTtBQUNBO0FBQ0g7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0Q7QUFDRjtBQUNIO0FBaFFHOzs7Ozs7Ozs7O0FDZFQ7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDSTtBQUNBOztBQUlBO0FBQ0E7O0FBSUE7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQTdCSTs7Ozs7Ozs7OztBQ0xUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTs7QUFFQTs7QUFFSTtBQUNJO0FBQ0E7QUFGUTtBQUlaO0FBQ0k7QUFDQTtBQUZFO0FBSU47QUFDSTtBQUNBO0FBRkk7QUFJUjtBQUNJO0FBQ0E7QUFGSztBQUlUO0FBQ0k7QUFDQTtBQUZPO0FBSVg7QUFDSTtBQUNBO0FBRmM7QUFJbEI7QUFDSTtBQUNBO0FBRlU7QUFJZDtBQUNJO0FBQ0E7QUFGWTtBQUloQjtBQUNJO0FBQ0E7QUFGaUI7QUFJckI7QUFDSTtBQUNBO0FBRks7QUFJVDtBQUNJO0FBQ0E7QUFGTztBQUlYO0FBQ0k7QUFDQTtBQUZjO0FBSWxCO0FBQ0k7QUFDQTtBQUZLO0FBSVQ7QUFDSTtBQUNBO0FBRlE7QUFJWjtBQUNJO0FBQ0E7QUFGTTtBQUlWO0FBQ0k7QUFDQTtBQUZRO0FBSVo7QUFDSTtBQUNBO0FBRk07QUFJVjtBQUNJO0FBQ0E7QUFGWTtBQUloQjtBQUNJO0FBQ0E7QUFGWTtBQUloQjtBQUNJO0FBQ0E7QUFGVztBQUlmO0FBQ0k7QUFDQTtBQUZZO0FBSWhCO0FBQ0k7QUFDQTtBQUZHO0FBSVA7QUFDSTtBQUNBO0FBRk07QUFJVjtBQUNJO0FBQ0E7QUFGUztBQUliO0FBQ0k7QUFDQTtBQUZLO0FBSVQ7QUFDSTtBQUNBO0FBRk07QUFJVjtBQUNJO0FBQ0E7QUFGUztBQUliO0FBQ0k7QUFDQTtBQUZLO0FBSVQ7QUFDSTtBQUNBO0FBRlE7QUFJWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBeklROztBQTRJWjtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDRDtBQUNBO0FBQXVDO0FBQzNCO0FBQ0g7QUFDRztBQUNIO0FBQ1Q7QUFDSDtBQUNEO0FBQ0E7QUFDSTtBQUM4QjtBQUNBO0FBQ0E7QUFDQTtBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQztBQUNoQjtBQUNEO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDbUM7QUFDQTtBQUNBO0FBQ0E7QUFKRDtBQU1sQztBQUNBO0FBQTZCO0FBQzdCO0FBQ0E7QUFDQTtBQUNDO0FBQ0c7QUFDQTtBQUNJO0FBQ0g7QUFDSjtBQUNEO0FBQ0g7QUFDRDtBQUNBO0FBQ0k7QUFDQTtBQUNZO0FBQ1o7QUFDQTtBQUNJO0FBQ0k7QUFDSDtBQUNHO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDSDtBQUNKO0FBQ0o7QUFDSjtBQUNKOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDOEI7QUFERDtBQUc3QjtBQUNBO0FBQ2lDO0FBREQ7QUFHaEM7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUFnQztBQUM1QjtBQUNJO0FBQ0E7QUFDSDtBQUNKO0FBQXFDO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0c7QUFBOEI7QUFDM0I7QUFDQTtBQUF5QztBQUM1QjtBQUdIO0FBQ0c7QUFHSDs7QUFFVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Y7QUFDTztBQUNBO0FBQWtDO0FBQ2xDO0FBQ0M7QUFBeUM7QUFDbEM7QUFHSDtBQUNHO0FBR0g7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUFzQjtBQUNsQjtBQUNBO0FBQ0g7QUFDRztBQUNIO0FBQXNDO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFzQjtBQUNsQjtBQUNIO0FBQ0Q7QUFDSDtBQUNQO0FBQ0o7QUFDRztBQUNEO0FBQ0k7QUFDSDtBQUNIO0FBQ1Q7QUFDUTtBQUNBO0FBQ0c7QUFDQTtBQUNBO0FBQ0E7QUFDUztBQUNUO0FBQ0E7QUFDQTtBQUNTO0FBQ1g7QUFDRTtBQUNBO0FBQ0Y7QUFDVDtBQUNKO0FBQ0o7QUFDSjs7QUFFRDtBQUNBO0FBQ0k7QUFDQzs7QUFFRDtBQUNZO0FBQ1o7QUFDQTtBQUNJO0FBRUk7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBQ0k7QUFDQTtBQUNBO0FBQ0g7QUFDRDs7QUFFSjtBQUNJO0FBQ0E7QUFBNEI7QUFDekI7QUFDQTtBQUNJO0FBQ0g7QUFFSDtBQUNHO0FBQ0E7QUFDSDtBQUNEO0FBQXNEO0FBQ2xEO0FBQ0Q7QUFDSTtBQUNIO0FBQ0g7O0FBRUQ7QUFDSTtBQUM1QjtBQUNZO0FBQ0k7QUFDSDtBQUNKO0FBQ0c7QUFDSztBQUNKO0FBQ0o7QUFDRztBQUNLO0FBQ0o7QUFDSjtBQUNHO0FBQ0s7QUFDSjtBQUNKO0FBQ2tCO0FBQ0E7QUFDRztBQUNBO0FBQ0E7QUFDQTtBQUNGO0FBQ0E7QUFDQTtBQUNJO0FBQ0g7QUFDRztBQUNIO0FBQ0Q7QUFDSTtBQUNBO0FBQ0g7QUFDSjtBQUNEOztBQUVKO0FBQ0k7QUFDSTtBQUNIO0FBQ0Q7QUF2RVI7QUF5RUg7QUFDSjtBQUNKOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNJO0FBQ0g7QUFDRDtBQUNJO0FBQ0g7QUFDRDtBQUNJO0FBQ0g7QUFDRDtBQUNJO0FBQ0g7O0FBRUQ7QUFDRztBQUNGO0FBQ0o7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSztBQUNBO0FBQ0E7QUFDQTtBQUNKOztBQUVEO0FBQ0E7QUFDSztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0o7QUFDRDtBQUNBO0FBQ0s7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNKO0FBQ0Q7QUFDQTtBQUNLO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSjtBQUNKOztBQUVBO0FBQ0Q7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQXlDO0FBQ3JDO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSDtBQUNEO0FBQ0g7QUFBOEM7QUFDdkM7QUFDQTtBQUNBO0FBQ0o7QUFDSDtBQUE4QztBQUN2QztBQUNBO0FBQ0E7QUFDSjtBQUNIO0FBQThDO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNKO0FBQ0g7QUFDSjs7QUFFRDtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFBbUM7QUFDL0I7QUFDQTtBQUNIOztBQUVEO0FBQ0k7QUFDQTtBQUNIO0FBQ0Q7QUFDQTtBQUNJO0FBQ0E7QUFDSDtBQUNEO0FBQ0E7QUFDSTtBQUNBO0FBQ0g7QUFDRDtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7O0FBRUE7O0FBR0E7QUFDQTs7QUFFQTtBQUNJO0FBQ0g7QUFDSjs7QUFFRDtBQUNJO0FBQ0E7QUFDSTtBQUNIO0FBQ0Q7QUFDSTtBQUNIO0FBQ0Q7QUFDQTtBQUNJO0FBQ0g7QUFDRDtBQUNJO0FBQ0g7QUFDSjs7QUFFRDtBQUNJO0FBQ0E7QUFDSTtBQUNIO0FBQ0Q7QUFDSTtBQUNIOztBQUVGO0FBQ0c7QUFDRDs7QUFFRDtBQUNIOztBQUVEO0FBQ0k7QUFDSTtBQUNBO0FBQ0g7QUFDRDtBQUNJO0FBQ0E7QUFDSDtBQUNEO0FBQ0g7QUFDSjs7QUFFRDtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0g7QUFDRztBQUNBO0FBQ0g7QUFDRztBQUNBO0FBQ0g7QUFDSjs7QUFFRDtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0g7QUFDRztBQUNBO0FBQ0g7QUFDRztBQUNBO0FBQ0g7QUFDSjtBQUNEO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNRO0FBQ1A7QUFDRDtBQUNJO0FBQ0E7QUFDQTtBQUhrQjtBQUlqQjtBQUFnRDtBQUVoRDtBQUNSO0FBQ0Q7QUFDQTtBQUNJO0FBQ0E7QUFBdUM7QUFDbkM7QUFDSDtBQUE0QztBQUN6QztBQUNIO0FBQTRDO0FBQ3pDO0FBQ0g7QUFBNEM7QUFDekM7QUFDSDtBQUNKO0FBQ0E7QUFDRDtBQUNJO0FBQ0E7QUFDSDs7QUFFRDtBQUNBO0FBQ3NCO0FBQ0E7QUFDakI7QUFBRztBQUNKO0FBQ0g7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNJO0FBQXdDO0FBQ3BDO0FBQ0g7QUFDRjtBQUNGO0FBQ0g7QUFDRjtBQUNJO0FBQ0c7QUFBMkM7QUFDdEM7QUFDSDtBQUNGO0FBQ0Y7QUFDSDtBQUNGO0FBQ0k7QUFDRztBQUE4QztBQUN6QztBQUNIO0FBQ0Y7QUFDRjtBQUNIO0FBQ0Y7QUFDSTtBQUNHO0FBQTBDO0FBQ3JDO0FBQ0g7QUFDRjtBQUNGO0FBQ0g7QUFDTDs7QUFFRDtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDMkI7QUFDQTtBQUZEO0FBSTFCO0FBQ0E7QUFDQTtBQUM4QjtBQUNBO0FBRkQ7QUFJN0I7QUFDQTtBQUNBO0FBQzhCO0FBREc7QUFHakM7QUFDQTtBQUNBO0FBQ0k7QUFDSDtBQUNHO0FBQ0E7QUFDSTtBQUVJO0FBQ0E7QUFDQTtBQUErQjtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ1M7QUFDUjtBQUNHO0FBQ0E7QUFDSDtBQUNKO0FBQ0c7QUFDQTtBQUE2QjtBQUN6QjtBQUNBO0FBQ0E7QUFBc0M7QUFDbEM7QUFDSDtBQUNEO0FBQ1E7QUFBVTtBQUNOO0FBQ0E7QUFBd0M7QUFDcEM7QUFHSDtBQUNHO0FBR0g7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSjtBQUFXO0FBQ1A7QUFBaUM7QUFDakM7QUFDQTtBQUF3QztBQUNwQztBQUdIO0FBQ0c7QUFHSDtBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQXNCO0FBQ3RCO0FBQ0M7QUFDRDtBQUNBO0FBQ0g7QUFBcUM7QUFDOUI7QUFDSTtBQUNBO0FBQStCO0FBQzNCO0FBQ0g7QUFDQTtBQUNHO0FBQ0g7QUFDUjtBQS9DYjtBQWlESDtBQUNKO0FBQ0o7QUFDSjtBQUNKO0FBQ0Q7QUFDSDs7QUFFRDtBQUNBO0FBQ0k7QUFDQTtBQUNIO0FBQ0Q7QUFDQTtBQUNJO0FBQ0E7QUFDSDs7QUFFRDtBQUNBO0FBQ0k7QUFDSDtBQUNBOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNIO0FBQ0c7QUFDSDtBQUNEO0FBQ0E7QUFDRztBQUNGO0FBQ0Q7QUFDRztBQUNGO0FBQ0Q7QUFDQTtBQUVFO0FBQ0Q7QUFDQztBQUNEO0FBQ0o7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDRztBQUNGO0FBQ0Q7QUFDRztBQUNGO0FBQ0Q7QUFDQTtBQUNIO0FBQ0Q7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBQ0g7QUFDRztBQUNIO0FBQ0Q7QUFDQTtBQUNHO0FBQ0Y7QUFDRDtBQUNHO0FBQ0Y7QUFDRDtBQUNBO0FBRUU7QUFDRDtBQUNDO0FBQ0Q7QUFDSjs7QUFFRDtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNHO0FBQ0Y7QUFDRDtBQUNHO0FBQ0Y7QUFDRDtBQUNBO0FBQ0g7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ087QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNQO0FBQ087QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNQO0FBQ087QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNQO0FBRUo7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNIO0FBQ087QUFDUDtBQUNPO0FBQ1A7QUFDSjs7QUFFRDtBQUNBO0FBQ0k7QUFDQTtBQUNIO0FBQ0Q7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ0Q7QUFDUTtBQUFzQztBQUNqQztBQUFvQjtBQUV4QjtBQUNSOztBQUVEO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFDSDtBQUNKO0FBQ0c7QUFDSTtBQUNBO0FBQ0E7QUFDSDtBQUNKO0FBQ0c7QUFDSTtBQUNBO0FBQ0E7QUFDSDtBQUNKO0FBQ0c7QUFDSTtBQUNBO0FBQ0E7QUFDSDtBQUNKO0FBQ0o7O0FBRUQ7QUFDQTtBQUNJO0FBQ1E7QUFDQTtBQUVYO0FBQ0Q7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUM4QjtBQUREO0FBRzdCO0FBQ0E7QUFDQTtBQUM4QjtBQURNO0FBR3BDO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFDSDtBQUNHO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSDtBQUNKO0FBQ0o7QUFDSjs7QUFFRDtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQzhCO0FBREQ7QUFHN0I7QUFDQTtBQUNBO0FBQzhCO0FBRFE7QUFHckM7QUFDRDtBQUNBO0FBQ0k7QUFDSTtBQUNIO0FBQ0c7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBQ047QUFDSDtBQUNOO0FBQ0o7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0k7QUFDQztBQUNBO0FBQ0Q7QUFDQztBQUNEO0FBQ0M7QUFDRDtBQUNIO0FBRUk7O0FBRUw7QUFDSTtBQUNIO0FBQ0c7QUFDSDtBQUNHO0FBQ0g7QUFDRztBQUNIOztBQUVEO0FBQ0E7QUFDSTtBQUNIO0FBQ0c7QUFDSDtBQUVKOztBQUdEO0FBQ0E7QUFDSTtBQUNDO0FBQ0Q7QUFDUTtBQUNBO0FBQ0c7QUFDQTtBQUNBO0FBQ0k7QUFDSDtBQUNIO0FBQ0c7QUFDSDtBQUNKO0FBQ1I7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUErQjtBQUMzQjtBQUNIO0FBQ0Q7QUFDSDtBQUNKO0FBQ0o7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ0c7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNHO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDRztBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ0o7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNDO0FBQ1I7O0FBR0Q7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUM4QjtBQUNBO0FBRkQ7QUFJN0I7QUFDQTtBQUNBO0FBQ21DO0FBREQ7QUFHakM7QUFDRDtBQUNBO0FBQ0k7QUFDSTtBQUNIO0FBQ0c7QUFDQTtBQUNEO0FBQ047QUFDRDtBQUVIOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ0c7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ0c7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ0c7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ0o7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNJO0FBQ0k7QUFDSDtBQUNEO0FBQ0k7QUFFSDtBQUNEO0FBQ0k7QUFFSDtBQUNKO0FBQ0o7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNJO0FBQ0g7QUFDSjtBQUNKOztBQUdEO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQWgwQ0k7Ozs7Ozs7Ozs7QUNKVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUZLO0FBSVQ7O0FBTlE7O0FBVVo7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNIOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBQ21DO0FBQ0E7QUFGTDs7QUFLOUI7QUFDQTtBQUNBO0FBQ0E7QUFDUztBQUNBO0FBQ1A7QUFDTDs7QUFFRDtBQUNBO0FBQ0k7QUFDSDs7QUFFRDtBQUNBO0FBQ0U7QUFDQTtBQUNBO0FBQ0E7QUFDMEI7QUFDMUI7QUFDQTtBQUNBO0FBQ007QUFDSTtBQUNIO0FBQ0c7QUFDQTtBQUNBO0FBQ0k7QUFDSDtBQUNHO0FBQ0E7QUFDSDtBQUNKO0FBQ0o7QUFDSjs7QUFFRDtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSDs7QUFFRDtBQUNBO0FBQ0k7QUFDSDs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQzRCO0FBQzVCO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFDSDtBQUNHO0FBQ0E7QUFDQTtBQUNRO0FBQ0E7QUFDSDtBQUNEO0FBQ0g7QUFDRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0g7QUFDSjtBQUNKO0FBQ0o7QUFDSjs7QUFHQTtBQUNHO0FBQ0E7QUFDRjtBQXpIRzs7Ozs7Ozs7OztBQ0pUO0FBQ0k7O0FBRUE7QUFDSztBQUNBO0FBQ0E7QUFGTztBQURBOztBQU9aO0FBQ0E7QUFDSTtBQUNBO0FBQ0g7O0FBRUQ7QUFDQztBQUNBO0FBQ0E7QUFDRDtBQUNJO0FBQ0g7QUFDRDtBQUNBOztBQUVBO0FBMUJLOzs7Ozs7Ozs7O0FDQVQ7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFDQztBQUNBO0FBQ0E7QUFDQTtBQUNEO0FBQ0k7QUFDSTtBQUNBO0FBQ0g7QUFDRztBQUNIO0FBQ0o7QUFDRDtBQUNIO0FBQ0o7O0FBcEJVOzs7Ozs7Ozs7O0FDRGY7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUpROztBQVFaO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSDs7QUFFRDtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDSDtBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0U7QUFDRDtBQUNEO0FBQ0U7QUFDRDtBQUNKOztBQUVEO0FBQ0k7QUFDSTtBQUNIO0FBQ0o7O0FBRUQ7QUFDSTtBQUNJO0FBQ0g7QUFDSjs7QUFFRDtBQUNJO0FBQ0k7QUFDSDtBQUNKO0FBQ0o7O0FBR0Q7QUFDSTtBQUNBO0FBQ0g7QUE3REk7Ozs7Ozs7Ozs7QUNEVDtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUhROztBQU9aO0FBQ0k7QUFDQTtBQUNBO0FBQ0g7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNIO0FBQ0Q7QUFDQTtBQUNBO0FBQ0k7QUFDSDtBQUNKOztBQUVEO0FBQ0k7QUFDSTtBQUNIO0FBQ0o7O0FBRUQ7QUFDSTtBQUNJO0FBQ0g7QUFDSjs7QUFFRDtBQUNJO0FBQ0k7QUFDSDtBQUNKO0FBQ0o7O0FBR0Q7QUFDSTtBQUNBO0FBQ0g7QUF0REk7Ozs7Ozs7Ozs7QUNEVDtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBRk07QUFJVjtBQUNJO0FBQ0E7QUFGTztBQUxIOztBQVdaO0FBQ0E7O0FBSUE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUM0QjtBQUNBO0FBQ0E7QUFIQztBQUs3QjtBQUNBO0FBQzRCO0FBREE7QUFHNUI7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNIO0FBQ0c7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDRDtBQUNBO0FBQ0s7QUFDTDtBQUNBO0FBQ0Y7QUFDRztBQUNIO0FBQ0o7QUFDSjtBQUNKOztBQUVEO0FBQ0E7O0FBRUE7QUEzREs7Ozs7Ozs7Ozs7QUNGVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUhPO0FBRk07O0FBU3JCO0FBQ0k7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUZFO0FBSU47QUFDQTtBQUNJO0FBQ0E7QUFGTTtBQUlWO0FBQ0k7QUFDQTtBQUZZO0FBSWhCO0FBQ0k7QUFDQTtBQUZJO0FBSVI7QUFDSTtBQUNBO0FBRk87QUFJWDtBQUNJO0FBQ0E7QUFGVTtBQUlkO0FBQ0k7QUFDQTtBQUZjO0FBSWxCO0FBQ0k7QUFDQTtBQUZZO0FBOUJSOztBQW9DWjtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQytCO0FBRFA7O0FBZXhCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0c7QUFDQTtBQUNBO0FBSGdDO0FBTXZDO0FBQ0o7O0FBRUQ7QUFDQTtBQUNHO0FBQ0E7QUFDQTtBQUVGOztBQUVEO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNDO0FBQ0c7QUFDQTtBQUNBO0FBQ0E7QUFDSDs7QUFFTDtBQUNIOztBQUVEO0FBQ0E7QUFDSTtBQUNHO0FBQ047O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNDO0FBQ0c7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDSDtBQUNKO0FBQ0o7QUFDRDtBQUNQOztBQUVEO0FBQ0k7QUFDQTtBQUNBO0FBQ0g7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDSDtBQUNKO0FBQ0o7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDSDtBQUNHO0FBQ0g7QUFDSjtBQUNKOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSDs7QUFFRDtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQXZLSTs7Ozs7Ozs7OztBQ2JUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFKTztBQUZNOztBQVVyQjtBQUNJOztBQUVBO0FBQ0k7QUFDSTtBQUNBO0FBRkU7QUFJTjtBQUNBO0FBQ0k7QUFDQTtBQUZNO0FBSVY7QUFDSTtBQUNBO0FBRmM7QUFJbEI7QUFDSTtBQUNBO0FBRmU7QUFJbkI7QUFDSTtBQUNBO0FBRnNCO0FBSTFCO0FBQ0k7QUFDQTtBQUZPO0FBSVg7QUFDSTtBQUNBO0FBRmU7QUFJbkI7QUFDSTtBQUNBO0FBRlk7QUFJaEI7QUFDSTtBQUNBO0FBRlk7QUFJaEI7QUF0Q1E7O0FBeUNaO0FBQ0E7QUFDSTtBQUNIOztBQUVEO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0o7QUFDQTtBQUMrQjtBQUREOztBQUk5QjtBQUF3QztBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0M7QUFDQztBQUNBO0FBQ0Q7QUFDRDtBQUNIOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBR0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0g7QUFDRDtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFKaUM7QUFNeEM7QUFDRDtBQUNIO0FBQ0o7O0FBR0Q7QUFDQTtBQUNJO0FBQ0E7O0FBRUE7QUFDSTtBQUNJO0FBQ0g7QUFDUTtBQUNBO0FBQ0E7QUFDUjtBQUNHO0FBQytCO0FBREQ7QUFHOUI7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNKO0FBQ0E7QUFDQTtBQUNKOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0g7O0FBRUQ7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNIOztBQUVEO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDSjs7QUFFRDtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQztBQUNPO0FBQ0E7QUFDQTtBQUNBO0FBSjhCO0FBTXRDO0FBQ0E7QUFDSDs7QUFFRDtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0g7QUFDRDtBQUNIO0FBQ0Q7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDSDtBQUNKO0FBQ0o7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDSDtBQUNHO0FBQ0g7QUFDSjtBQUNKOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0g7QUFDSjtBQUNEO0FBQ0g7QUFDRDtBQUNBO0FBQ0k7QUFDQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQXJPSTs7Ozs7Ozs7OztBQ2RUO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNJO0FBQ0E7QUFDSDtBQUNEO0FBQ0k7QUFDQTtBQUNIO0FBQ0Q7QUFDQztBQUNHO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0o7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNKO0FBQ0k7QUFDQTtBQUNKO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFDSDtBQUNEO0FBQ0E7QUFDQTtBQUNKO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFDSDtBQUNEO0FBQ0E7QUFDSjtBQUNJO0FBQ0E7QUFDQTtBQUNDO0FBQ0w7QUFDSTtBQUNBO0FBQ0M7QUFDTDtBQUNJO0FBQ0E7QUFDQTtBQUNDO0FBQ0w7QUFDSTtBQUNDO0FBQ0w7QUFDSTtBQUNBO0FBQ0M7QUFDTDtBQUNJO0FBQ0E7QUFDQztBQUNMO0FBQ0k7QUFDQTtBQUNDO0FBQ0w7QUFDSTtBQUNDO0FBQ0w7QUFDSTtBQUNBO0FBQ0E7QUFFQztBQUNMO0FBQ0k7QUF0RVI7QUF3RUg7QUFDSDtBQTlHVzs7Ozs7Ozs7OztBQ0hqQjtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7QUN0Q0o7QUFDQTtBQUNJOztBQUVBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFWUTs7QUFhWjtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0g7QUFDSjs7QUF0Qkk7Ozs7Ozs7Ozs7QUNEVDtBQUNBO0FBQ0E7QUFDSTs7QUFFQTtBQUNJO0FBQ0k7QUFDQTtBQUZJO0FBSVI7QUFDSTtBQUNBO0FBRkk7QUFJUDtBQUNHO0FBQ0E7QUFGUTs7QUFUSjs7QUFrQlo7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUVIO0FBQ0Q7QUFDQTtBQUNJO0FBQ0E7QUFFUztBQUNDO0FBQ047QUFFUDtBQXJDSSIsInNvdXJjZXNDb250ZW50IjpbInZhciB1c2VyZGF0YSA9IHJlcXVpcmUoJ1VzZXJEYXRhJyk7XHJcbnZhciBmcmllbmQgPSByZXF1aXJlKCdGcmllbmRBY3Rpdml0eScpO1xyXG52YXIgaHR0cCA9IHJlcXVpcmUoJ0h0dHBVdGlscycpO1xyXG52YXIgc29rZXQgPSByZXF1aXJlKFwiU29rZXRVdGlsc1wiKTtcclxudmFyIEl0ZW00ID0gY2MuQ2xhc3Moe1xyXG4gICAgbmFtZTpcIkl0ZW00XCIsXHJcbiAgICBwcm9wZXJ0aWVzOntcclxuICAgICAgICBpZDowLFxyXG4gICAgICAgIGZyaWVuZE5hbWU6XCJcIixcclxuICAgICAgICBmcmllbmRHcmFkZTowLFxyXG4gICAgICAgIGZyaWVuZEljb246Y2MuU3ByaXRlRnJhbWUsXHJcbiAgICB9LFxyXG59KTtcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBpdGVtczp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6W10sXHJcbiAgICAgICAgICAgIHR5cGU6SXRlbTQsXHJcbiAgICAgICAgfSwgIFxyXG4gICAgICAgIGl0ZW1GcmllbmRQcmVmYWI6Y2MuUHJlZmFiLFxyXG4gICAgICAgIGhlYWRBdGxhczp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5TcHJpdGVBdGxhc1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXNraW5nTGlzdENvbnRlbnQ6ey8v6K+35rGC5YiX6KGo5YaF5a65XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5Ob2RlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXNraW5nTGlzdDp7Ly/or7fmsYLliJfooahcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLk5vZGUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBmcmllbmRMaXN0OnsvL+WlveWPi+WIl+ihqFxyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIGZyaWVuZExpc3RDb250ZW50OnsvL+WlveWPi+WIl+ihqOWGheWuuVxyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZSxcclxuICAgICAgICB9LCAgICAgIFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHVzZXJkYXRhLnNlbGVjdGVkRnJpZW5kTmFtZSA9IG51bGw7XHJcbiAgICAgICAgc2VsZi5Jbml0QXNraW5nTGlzdCgpO1xyXG59LFxyXG5cclxuICAgIC8v5Yid5aeL5YyW6K+35rGC5aW95Y+L5YiX6KGoXHJcbiAgICBJbml0QXNraW5nTGlzdDpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICB1c2VyZGF0YS5zZWxlY3RlZE1haWxJRCA9IG51bGw7XHJcbiAgICAgICBpZih1c2VyZGF0YS5hc2tpbmdGcmllbmRJbmZvPT1udWxsfHx1c2VyZGF0YS5hc2tpbmdGcmllbmRJbmZvLmxlbmd0aD09MCl7XHJcblxyXG4gICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgIHNlbGYuQ2xlYXJBc2tpbmdGcmllbmRzKCk7ICAgICAgICAgXHJcbiAgICAgICAgICAgIHNlbGYuaXRlbXMubGVuZ3RoID0gdXNlcmRhdGEuYXNraW5nRnJpZW5kSW5mby5sZW5ndGg7XHJcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgc2VsZi5pdGVtcy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgdmFyIGl0ZW0gPSBjYy5pbnN0YW50aWF0ZShzZWxmLml0ZW1GcmllbmRQcmVmYWIpO1xyXG4gICAgICAgICAgICAgICAgc2VsZi5pdGVtc1tpXSA9IHVzZXJkYXRhLmFza2luZ0ZyaWVuZEluZm9bMF07XHJcbiAgICAgICAgICAgICAgICB2YXIgZGF0YSA9IHNlbGYuaXRlbXNbaV07XHJcbiAgICAgICAgICAgICAgICBzZWxmLm5vZGUuYWRkQ2hpbGQoaXRlbSk7XHJcbiAgICAgICAgICAgICAgICBpdGVtLmNvbG9yID0gbmV3IGNjLkNvbG9yKDAsMTkxLDI1NSk7XHJcbiAgICAgICAgICAgICAgICBpdGVtLmdldENvbXBvbmVudCgnSXRlbUZyaWVuZCcpLmluaXQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZDogZGF0YS5JRCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgaXRlbU5hbWU6IGRhdGEuRnJpZW5kTmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgaXRlbUdyYWRlOiBcIuWIhuaVsDpcIitkYXRhLkZyaWVuZEdyYWRlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpY29uU0Y6IHNlbGYuaGVhZEF0bGFzLmdldFNwcml0ZUZyYW1lKGRhdGEuRnJpZW5kSWNvbiksXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICAvL+aLkue7nea3u+WKoOWlveWPi+WHveaVsFxyXG4gICAgUmVqZWN0OmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIGlmKHVzZXJkYXRhLnNlbGVjdGVkRnJpZW5kTmFtZSA9PSBudWxsKXtcclxuICAgICAgICAgICAgY2MubG9nKFwi6K+35YWI6YCJ5oup5oOz5ouS57ud55qE5Lq6LlwiKTtcclxuICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICAgIC8v5q2k5aSE57uZ5pyN5Yqh5Zmo5Y+R6YCB6K+35rGCXHJcbiAgICAgICAgICAgICAgICB2YXIgIGNvbnRlbnQgPSBKU09OLnN0cmluZ2lmeSh7VHlwZToxMDA2OSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFuc3dlcjpmYWxzZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5hbWU6dXNlcmRhdGEuc2VsZWN0ZWRGcmllbmROYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pOyAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgY2MubG9nKFwi5ZCR5aW95Y+L5pyN5Yqh5Zmo5Y+R6YCB6K+35rGC5ouS57ud5aKe5Yqg5aW95Y+L5raI5oGv77yaXCIpO1xyXG4gICAgICAgICAgICAgICAgY2MubG9nKEpTT04ucGFyc2UoY29udGVudCkpO1xyXG4gICAgICAgICAgICAgICAgc29rZXQud3Muc2VuZChjb250ZW50KTsvL+WPkemAgea2iOaBryBcclxuICAgICAgICAgICAgICAgIHNva2V0LmdldENoYXRNc2coKTsvL+ebkeWQrOiOt+WPluS/oeaBr1xyXG4gICAgICAgICAgICAgICAgc2VsZi5VcGRhdGVBc2tpbmdMaXN0KGZhbHNlKTtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICAvL+WQjOaEj+a3u+WKoOWlveWPi+WHveaVsFxyXG4gICAgQWdyZWU6ZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgaWYodXNlcmRhdGEuc2VsZWN0ZWRGcmllbmROYW1lID09IG51bGwpe1xyXG4gICAgICAgICAgICBjYy5sb2coXCLor7flhYjpgInmi6nmg7PlkIzmhI/nmoTkurouXCIpO1xyXG4gICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgLy/mraTlpITnu5nmnI3liqHlmajlj5HpgIHor7fmsYJcclxuICAgICAgICAgICAgICAgIHZhciAgY29udGVudCA9IEpTT04uc3RyaW5naWZ5KHtUeXBlOjEwMDY5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQW5zd2VyOnRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOYW1lOnVzZXJkYXRhLnNlbGVjdGVkRnJpZW5kTmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTsgICAgICAgICBcclxuICAgICAgICAgICAgICAgIGNjLmxvZyhcIuWQkeWlveWPi+acjeWKoeWZqOWPkemAgeivt+axguWQjOaEj+WinuWKoOWlveWPi+a2iOaBr++8mlwiKTtcclxuICAgICAgICAgICAgICAgIGNjLmxvZyhKU09OLnBhcnNlKGNvbnRlbnQpKTtcclxuICAgICAgICAgICAgICAgIHNva2V0LndzLnNlbmQoY29udGVudCk7Ly/lj5HpgIHmtojmga8gXHJcbiAgICAgICAgICAgICAgICBzb2tldC5nZXRDaGF0TXNnKCk7Ly/nm5HlkKzojrflj5bkv6Hmga9cclxuICAgICAgICAgICAgICAgIHNlbGYuVXBkYXRlQXNraW5nTGlzdCh0cnVlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvL+iiq+ivt+axguaWueabtOaWsOWlveWPi+ivt+axguWIl+ihqFxyXG4gICAgVXBkYXRlQXNraW5nTGlzdDpmdW5jdGlvbihjaG9pY2Upe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICAvL+WQjOaEj+a3u+WKoOWlveWPi1xyXG4gICAgICAgIGlmKGNob2ljZSA9PSB0cnVlKXtcclxuICAgICAgICAgICAgc2VsZi5mcmllbmRMaXN0LmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgIHNlbGYuQ2xlYXJBc2tpbmdGcmllbmRzKCk7XHJcbiAgICAgICAgICAgIGZyaWVuZC5DbGVhcl9saXN0KHVzZXJkYXRhLmFza2luZ0ZyaWVuZEluZm8pO1xyXG4gICAgICAgICAgICBzZWxmLmZyaWVuZExpc3RDb250ZW50LmdldENvbXBvbmVudChcIkZyaWVuZHNMaXN0XCIpLkFza0ZyaWVuZCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvL+aLkue7nea3u+WKoOWlveWPi1xyXG4gICAgICAgIGlmKGNob2ljZSA9PSBmYWxzZSl7XHJcbiAgICAgICAgICAgIHNlbGYuZnJpZW5kTGlzdC5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICBzZWxmLkNsZWFyQXNraW5nRnJpZW5kcygpO1xyXG4gICAgICAgICAgICBmcmllbmQuQ2xlYXJfbGlzdCh1c2VyZGF0YS5hc2tpbmdGcmllbmRJbmZvKTtcclxuICAgICAgICAgICAgc2VsZi5mcmllbmRMaXN0Q29udGVudC5nZXRDb21wb25lbnQoXCJGcmllbmRzTGlzdFwiKS5Bc2tGcmllbmQoKTsgIFxyXG4gICAgICAgIH0gICBcclxuICAgIH0sXHJcblxyXG4gICAgLy/lhbPpl63lpb3lj4vor7fmsYLliJfooahcclxuICAgIENsb3NlTGlzdDpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBzZWxmLmFza2luZ0xpc3QuYWN0aXZlID0gZmFsc2U7XHJcbiAgICB9LFxyXG5cclxuICAgIC8v56Gu5a6a6KaB56e76Zmk55qEaXRlbVxyXG4gICAgR2V0UmVtb3ZlZEl0ZW06ZnVuY3Rpb24obWFpbElEKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICB9LFxyXG5cclxuICAgIC8v5riF56m65aW95Y+L6K+35rGC5YiX6KGoXHJcbiAgICBDbGVhckFza2luZ0ZyaWVuZHM6ZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgZm9yKHZhciBpID1zZWxmLmFza2luZ0xpc3RDb250ZW50LmNoaWxkcmVuLmxlbmd0aC0xOyBpID49MDtpLS0pe1xyXG4gICAgICAgICAgICBzZWxmLmFza2luZ0xpc3RDb250ZW50LnJlbW92ZUNoaWxkKHNlbGYuYXNraW5nTGlzdENvbnRlbnQuY2hpbGRyZW5baV0pO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBcclxuICAgIC8v5qCH6K6w5b2T5YmN54K55Ye755qE5aW95Y+LXHJcbiAgICBTaWduU2VsZWN0ZWRGcmllbmQ6ZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgZm9yKHZhciBpID0gMDtpPHNlbGYuYXNraW5nTGlzdENvbnRlbnQuY2hpbGRyZW4ubGVuZ3RoOysraSl7XHJcbiAgICAgICAgICAgIHZhciBuYW1lID0gc2VsZi5hc2tpbmdMaXN0Q29udGVudC5jaGlsZHJlbltpXS5nZXRDaGlsZEJ5TmFtZShcIm5hbWVcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc7XHJcbiAgICAgICAgICAgIGlmKCBuYW1lID09IHVzZXJkYXRhLnNlbGVjdGVkRnJpZW5kTmFtZSl7XHJcbiAgICAgICAgICAgICAgICBzZWxmLmFza2luZ0xpc3RDb250ZW50LmNoaWxkcmVuW2ldLmdldENoaWxkQnlOYW1lKFwic2VsZWN0aW5nXCIpLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgc2VsZi5hc2tpbmdMaXN0Q29udGVudC5jaGlsZHJlbltpXS5nZXRDaGlsZEJ5TmFtZShcInNlbGVjdGluZ1wiKS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gXHJcbiAgICB9LFxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHNva2V0LmdldENoYXRNc2coKTtcclxuXHJcbiAgICAgICAgc2VsZi5Jbml0QXNraW5nTGlzdCgpO1xyXG4gICAgICAgIHNlbGYuU2lnblNlbGVjdGVkRnJpZW5kKCk7XHJcbiAgICB9LFxyXG59KTtcclxuIiwiLy/lgqjlrZjljaHniYzkv6Hmga9cclxudmFyIHVzZXJkYXRhID0gcmVxdWlyZSgnVXNlckRhdGEnKTtcclxubW9kdWxlLmV4cG9ydHM9e1xyXG4gICAgLy/liJ3lp4vljJblh73mlbDmqKHmnb/vvIzmoLnmja7kv6Hmga/liJ3lp4vljJbljaHniYzkv6Hmga/vvIzlubblgqjlrZjlnKjlr7nlupRtYXDph4zpnaLvvIzpgJrnlKjov5nkuIDkuKrlh73mlbDliJ3lp4vljJZcclxuICAgIEluaXRfY2FyZDpmdW5jdGlvbihjYXJkcyxtYXApe1xyXG4gICAgICAgIGZvcih2YXIgeCBpbiBjYXJkcyl7XHJcbiAgICAgICAgICAgIHZhciBjYXJkPW5ldyBNYXAoKTtcclxuICAgICAgICAgICAgY2FyZC5wb2ludD1jYXJkc1t4XS5DYXJkUG9pbnQ7XHJcbiAgICAgICAgICAgIGNhcmQuc3VpdD1jYXJkc1t4XS5DYXJkU3VpdDtcclxuICAgICAgICAgICAgY2FyZC5wb3NpPWNhcmRzW3hdLlBvc2l0aW9uO1xyXG4gICAgICAgICAgICBjYXJkLnN0YXRlPWNhcmRzW3hdLkNhcmRTdGF0dXM7XHJcbiAgICAgICAgICAgIG1hcC5zZXQocGFyc2VJbnQoeCksY2FyZCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBNb2RpZnlfY2FyZDpmdW5jdGlvbihjYXJkcyxtYXBzKXtcclxuICAgICAgICBmb3IodmFyIHggPTA7eDxjYXJkcy5sZW5ndGg7eCsrKXtcclxuICAgICAgICAgICAgbWFwcy5nZXQoeCkucG9pbnQ9Y2FyZHNbeF0uQ2FyZFBvaW50O1xyXG4gICAgICAgICAgICBtYXBzLmdldCh4KS5zdWl0PWNhcmRzW3hdLkNhcmRTdWl0O1xyXG4gICAgICAgICAgICBtYXBzLmdldCh4KS5wb3NpPWNhcmRzW3hdLlBvc2l0aW9uO1xyXG4gICAgICAgICAgICBtYXBzLmdldCh4KS5zdGF0ZT1jYXJkc1t4XS5DYXJkU3RhdHVzO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy/mn6Xmib7luqfkvY3lr7nlupTnmoRPcHBQbGF5ZXLkuIvmoIdcclxuICAgIEdldFNlYXQ6ZnVuY3Rpb24oc2VhdHMsZSl7XHJcbiAgICAgICAgZm9yKHZhciB4IGluIGUpe1xyXG4gICAgICAgICAgICBpZihlW3hdLlNlYXQ9PT1zZWF0cyl7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4geDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy/kuKTnjqnlrrblr7nmiJjml7bliJ3lp4vlh73mlbBcclxuICAgIEluaXRfdHdvX3BsYXllcnM6ZnVuY3Rpb24obWNhcmRzLG9jYXJkcyl7XHJcbiAgICAgICAgdXNlcmRhdGEubWNhcmQ9bmV3IE1hcCgpO1xyXG4gICAgICAgIHVzZXJkYXRhLm9jYXJkPW5ldyBNYXAoKTtcclxuICAgICAgICB0aGlzLkluaXRfY2FyZChtY2FyZHMsdXNlcmRhdGEubWNhcmQpO1xyXG4gICAgICAgIHRoaXMuSW5pdF9jYXJkKG9jYXJkcyx1c2VyZGF0YS5vY2FyZCk7XHJcblxyXG4gICAgfSxcclxuICAgIC8v5LiJ546p5a625a+55oiY5pe25Yid5aeL5Ye95pWwXHJcbiAgICBJbml0X3RocmVlX3BsYXllcnM6ZnVuY3Rpb24obWNhcmRzLGxjYXJkcyxyY2FyZHMpe1xyXG4gICAgICAgIHVzZXJkYXRhLm1jYXJkPW5ldyBNYXAoKTtcclxuICAgICAgICB1c2VyZGF0YS5sY2FyZD1uZXcgTWFwKCk7XHJcbiAgICAgICAgdXNlcmRhdGEucmNhcmQ9bmV3IE1hcCgpO1xyXG4gICAgICAgIHRoaXMuSW5pdF9jYXJkKG1jYXJkcyx1c2VyZGF0YS5tY2FyZCk7XHJcbiAgICAgICAgdGhpcy5Jbml0X2NhcmQobGNhcmRzLHVzZXJkYXRhLmxjYXJkKTtcclxuICAgICAgICB0aGlzLkluaXRfY2FyZChyY2FyZHMsdXNlcmRhdGEucmNhcmQpO1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy/liJ3lp4vljJblm5vkurrlr7nlsYDml7blr7nmiYvkv6Hmga/ku6Xlj4rljaHniYzkv6Hmga9cclxuICAgIEluaXRfZm91cl9vcHA6ZnVuY3Rpb24oZSl7XHJcbiAgICAgICAgdmFyIHI9dGhpcy5HZXRTZWF0KHVzZXJkYXRhLnJzZWF0LGUpO1xyXG4gICAgICAgICAgICB0aGlzLkluaXRfY2FyZChlW3JdLkNhcmQsdXNlcmRhdGEucmNhcmQpO1xyXG4gICAgICAgICAgICB1c2VyZGF0YS5ybmFtZT1lW3JdLlVpZDtcclxuICAgICAgICAgICAgdXNlcmRhdGEucmdyYWRlPWVbcl0uR3JhZGU7XHJcbiAgICAgICAgdmFyIGw9dGhpcy5HZXRTZWF0KHVzZXJkYXRhLmxzZWF0LGUpO1xyXG4gICAgICAgICAgICB0aGlzLkluaXRfY2FyZChlW2xdLkNhcmQsdXNlcmRhdGEubGNhcmQpO1xyXG4gICAgICAgICAgICB1c2VyZGF0YS5sbmFtZT1lW2xdLlVpZDtcclxuICAgICAgICAgICAgdXNlcmRhdGEubGdyYWRlPWVbbF0uR3JhZGU7XHJcbiAgICAgICAgdmFyIG89dGhpcy5HZXRTZWF0KHVzZXJkYXRhLm9zZWF0LGUpO1xyXG4gICAgICAgICAgICB0aGlzLkluaXRfY2FyZChlW29dLkNhcmQsdXNlcmRhdGEub2NhcmQpO1xyXG4gICAgICAgICAgICB1c2VyZGF0YS5vbmFtZT1lW29dLlVpZDtcclxuICAgICAgICAgICAgdXNlcmRhdGEub2dyYWRlPWVbb10uR3JhZGU7XHJcbiAgICB9LFxyXG4gICAgLy/lm5vnjqnlrrblr7nmiJjml7bliJ3lp4vlh73mlbBcclxuICAgIEluaXRfZm91cl9wbGF5ZXJzOmZ1bmN0aW9uKGUpe1xyXG4gICAgICAgIHVzZXJkYXRhLm1jYXJkPW5ldyBNYXAoKTtcclxuICAgICAgICB1c2VyZGF0YS5vY2FyZD1uZXcgTWFwKCk7XHJcbiAgICAgICAgdXNlcmRhdGEubGNhcmQ9bmV3IE1hcCgpO1xyXG4gICAgICAgIHVzZXJkYXRhLnJjYXJkPW5ldyBNYXAoKTtcclxuICAgICAgICB1c2VyZGF0YS50Y2FyZD1uZXcgTWFwKCk7XHJcbiAgICAgICAgdXNlcmRhdGEubXNlYXQ9cGFyc2VJbnQoZS5Nc2VhdCk7XHJcbiAgICAgICAgdGhpcy5Jbml0X2NhcmQoZS5NY2FyZCx1c2VyZGF0YS5tY2FyZCk7XHJcblxyXG4gICAgICAgIC8v5qC55o2u5oiR55qE5bqn5L2N5Zu65a6a5a+55omL5bqn5L2NXHJcbiAgICAgICAgaWYodXNlcmRhdGEubXNlYXQ9PT0xKXtcclxuICAgICAgICAgICAgdXNlcmRhdGEucnNlYXQ9MjtcclxuICAgICAgICAgICAgdXNlcmRhdGEub3NlYXQ9MztcclxuICAgICAgICAgICAgdXNlcmRhdGEubHNlYXQ9NDtcclxuICAgICAgICAgICAgdGhpcy5Jbml0X2ZvdXJfb3BwKGUuT3BwUGxheWVyKTtcclxuICAgICAgICB9ZWxzZSBpZih1c2VyZGF0YS5tc2VhdD09PTIpe1xyXG4gICAgICAgICAgICB1c2VyZGF0YS5yc2VhdD0zO1xyXG4gICAgICAgICAgICB1c2VyZGF0YS5vc2VhdD00O1xyXG4gICAgICAgICAgICB1c2VyZGF0YS5sc2VhdD0xO1xyXG4gICAgICAgICAgICB0aGlzLkluaXRfZm91cl9vcHAoZS5PcHBQbGF5ZXIpO1xyXG4gICAgICAgIH1lbHNlIGlmKHVzZXJkYXRhLm1zZWF0PT09Myl7XHJcbiAgICAgICAgICAgIHVzZXJkYXRhLnJzZWF0PTQ7XHJcbiAgICAgICAgICAgIHVzZXJkYXRhLm9zZWF0PTE7XHJcbiAgICAgICAgICAgIHVzZXJkYXRhLmxzZWF0PTI7XHJcbiAgICAgICAgICAgIHRoaXMuSW5pdF9mb3VyX29wcChlLk9wcFBsYXllcik7XHJcbiAgICAgICAgfWVsc2UgaWYodXNlcmRhdGEubXNlYXQ9PT00KXtcclxuICAgICAgICAgICAgdXNlcmRhdGEucnNlYXQ9MTtcclxuICAgICAgICAgICAgdXNlcmRhdGEub3NlYXQ9MjtcclxuICAgICAgICAgICAgdXNlcmRhdGEubHNlYXQ9MztcclxuICAgICAgICAgICAgdGhpcy5Jbml0X2ZvdXJfb3BwKGUuT3BwUGxheWVyKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdXNlcmRhdGEuZnRwbGF5ZXI9ZS5Ub3VjaHA7XHJcbiAgICAgICAgdGhpcy5UY2FyZChlLlRjYXJkKTtcclxuICAgIH0sXHJcblxyXG5cclxuICAgIC8v5qC55o2u5pG454mM5Lq65a2Y5YKo5Y2V5pG455qE5LiA5byg5Y2h54mMLHRjYXJkLnN1aXTorrDlvZXljZXmkbjniYzpopzoibJcclxuICAgIFRjYXJkOmZ1bmN0aW9uKHRjYXJkKXtcclxuICAgICAgICBpZih1c2VyZGF0YS5mdHBsYXllcj09PXVzZXJkYXRhLm1zZWF0KXtcclxuICAgICAgICAgICAgdGhpcy5JbnNlcnRfdGNhcmQodGNhcmQsdXNlcmRhdGEubWNhcmQpO1xyXG4gICAgICAgIH1lbHNlIHtcclxuICAgICAgICAgICAgdXNlcmRhdGEudGNhcmQuc3VpdD10Y2FyZC5DYXJkU3VpdDtcclxuICAgICAgICAgICAgaWYodXNlcmRhdGEuZnRwbGF5ZXI9PT11c2VyZGF0YS5vc2VhdCl7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkluc2VydF90Y2FyZCh0Y2FyZCx1c2VyZGF0YS5vY2FyZCk7XHJcbiAgICAgICAgICAgIH1lbHNlIGlmKHVzZXJkYXRhLmZ0cGxheWVyPT09dXNlcmRhdGEucnNlYXQpe1xyXG4gICAgICAgICAgICAgICAgdGhpcy5JbnNlcnRfdGNhcmQodGNhcmQsdXNlcmRhdGEucmNhcmQpO1xyXG4gICAgICAgICAgICB9ZWxzZSBpZih1c2VyZGF0YS5mdHBsYXllcj09PXVzZXJkYXRhLmxzZWF0KXtcclxuICAgICAgICAgICAgICAgIHRoaXMuSW5zZXJ0X3RjYXJkKHRjYXJkLHVzZXJkYXRhLmxjYXJkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy/ljZXmkbjniYzmj5LlhaXliLDmkbjniYzmlrnnmoRtYXBcclxuICAgIEluc2VydF90Y2FyZDpmdW5jdGlvbih0Y2FyZCxtYXApe1xyXG4gICAgICAgIGlmKHRjYXJkIT1udWxsKXsvL+WmguaenOeJjOWghuacieeJjFxyXG4gICAgICAgIHZhciBtYXBfbGVuZ3RoPW1hcC5zaXplO1xyXG4gICAgICAgIHZhciBjYXJkPW5ldyBNYXAoKTtcclxuICAgICAgICBjYXJkLnBvaW50PXRjYXJkLkNhcmRQb2ludDtcclxuICAgICAgICBjYXJkLnN1aXQ9dGNhcmQuQ2FyZFN1aXQ7XHJcbiAgICAgICAgY2FyZC5wb3NpPXRjYXJkLlBvc2l0aW9uO1xyXG4gICAgICAgIGNhcmQuc3RhdGU9dGNhcmQuQ2FyZFN0YXR1cztcclxuICAgICAgICBtYXAuc2V0KHBhcnNlSW50KG1hcF9sZW5ndGgpLGNhcmQpO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy/mjqXmlLbnjJzniYznu5Pmnpzkv6Hmga9cclxuICAgIEd1ZXNzUmVzdWx0OmZ1bmN0aW9uKGUpe1xyXG4gICAgICAgIHVzZXJkYXRhLmd1ZXNzZWRtYW49ZS5TZWF0O1xyXG4gICAgICAgIHVzZXJkYXRhLmd1ZXNzZWRjYXJkLnBvaW50PWUuQ2FyZC5DYXJkUG9pbnQ7XHJcbiAgICAgICAgdXNlcmRhdGEuZ3Vlc3NlZGNhcmQuc3VpdD1lLkNhcmQuQ2FyZFN1aXQ7XHJcbiAgICAgICAgdXNlcmRhdGEuZ3Vlc3NlZGNhcmQucG9zaT1lLkNhcmQuUG9zaXRpb247XHJcbiAgICAgICAgdXNlcmRhdGEuZ3Vlc3NlZGNhcmQuc3RhdGU9ZS5DYXJkLkNhcmRTdGF0dXM7XHJcbiAgICAgICAgaWYoZS5SZXN1bHQ9PT10cnVlKXtcclxuICAgICAgICAgICAgaWYodXNlcmRhdGEuZ3Vlc3NlZG1hbj09PXVzZXJkYXRhLm1zZWF0KXtcclxuICAgICAgICAgICAgICAgIHVzZXJkYXRhLm1jYXJkLmdldChlLkNhcmQuUG9zaXRpb24tMSkuc3RhdGU9ZS5DYXJkLkNhcmRTdGF0dXM7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSBpZih1c2VyZGF0YS5ndWVzc2VkbWFuPT09dXNlcmRhdGEub3NlYXQpe1xyXG4gICAgICAgICAgICAgICAgdXNlcmRhdGEub2NhcmQuZ2V0KGUuQ2FyZC5Qb3NpdGlvbi0xKS5wb2ludD1lLkNhcmQuQ2FyZFBvaW50O1xyXG4gICAgICAgICAgICAgICAgdXNlcmRhdGEub2NhcmQuZ2V0KGUuQ2FyZC5Qb3NpdGlvbi0xKS5zdGF0ZT1lLkNhcmQuQ2FyZFN0YXR1cztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmKHVzZXJkYXRhLmd1ZXNzZWRtYW49PT11c2VyZGF0YS5yc2VhdCl7XHJcbiAgICAgICAgICAgICAgICB1c2VyZGF0YS5yY2FyZC5nZXQoZS5DYXJkLlBvc2l0aW9uLTEpLnBvaW50PWUuQ2FyZC5DYXJkUG9pbnQ7XHJcbiAgICAgICAgICAgICAgICB1c2VyZGF0YS5yY2FyZC5nZXQoZS5DYXJkLlBvc2l0aW9uLTEpLnN0YXRlPWUuQ2FyZC5DYXJkU3RhdHVzO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYodXNlcmRhdGEuZ3Vlc3NlZG1hbj09PXVzZXJkYXRhLmxzZWF0KXtcclxuICAgICAgICAgICAgICAgIHVzZXJkYXRhLmxjYXJkLmdldChlLkNhcmQuUG9zaXRpb24tMSkucG9pbnQ9ZS5DYXJkLkNhcmRQb2ludDtcclxuICAgICAgICAgICAgICAgIHVzZXJkYXRhLmxjYXJkLmdldChlLkNhcmQuUG9zaXRpb24tMSkuc3RhdGU9ZS5DYXJkLkNhcmRTdGF0dXM7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgdXNlcmRhdGEudGNhcmQucG9pbnQ9ZS5UY2FyZC5DYXJkUG9pbnQ7XHJcbiAgICAgICAgICAgIGlmKHVzZXJkYXRhLmZ0cGxheWVyPT09dXNlcmRhdGEubXNlYXQpe1xyXG4gICAgICAgICAgICAgICAgdmFyIGNhcmRfbGVuZ3RoPXVzZXJkYXRhLm1jYXJkLnNpemU7XHJcbiAgICAgICAgICAgICAgICB1c2VyZGF0YS5tY2FyZC5nZXQoY2FyZF9sZW5ndGgtMSkuc3RhdGU9ZS5UY2FyZC5DYXJkU3RhdHVzO1xyXG4gICAgICAgICAgICB9ZWxzZSBpZih1c2VyZGF0YS5mdHBsYXllcj09PXVzZXJkYXRhLm9zZWF0KXtcclxuICAgICAgICAgICAgICAgIHZhciBjYXJkX2xlbmd0aD11c2VyZGF0YS5vY2FyZC5zaXplO1xyXG4gICAgICAgICAgICAgICAgdXNlcmRhdGEub2NhcmQuZ2V0KGNhcmRfbGVuZ3RoLTEpLnBvaW50PWUuVGNhcmQuQ2FyZFBvaW50O1xyXG4gICAgICAgICAgICAgICAgdXNlcmRhdGEub2NhcmQuZ2V0KGNhcmRfbGVuZ3RoLTEpLnN0YXRlPWUuVGNhcmQuQ2FyZFN0YXR1cztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmKHVzZXJkYXRhLmZ0cGxheWVyPT09dXNlcmRhdGEucnNlYXQpe1xyXG4gICAgICAgICAgICAgICAgdmFyIGNhcmRfbGVuZ3RoPXVzZXJkYXRhLnJjYXJkLnNpemU7XHJcbiAgICAgICAgICAgICAgICB1c2VyZGF0YS5yY2FyZC5nZXQoY2FyZF9sZW5ndGgtMSkucG9pbnQ9ZS5UY2FyZC5DYXJkUG9pbnQ7XHJcbiAgICAgICAgICAgICAgICB1c2VyZGF0YS5yY2FyZC5nZXQoY2FyZF9sZW5ndGgtMSkuc3RhdGU9ZS5UY2FyZC5DYXJkU3RhdHVzO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYodXNlcmRhdGEuZnRwbGF5ZXI9PT11c2VyZGF0YS5sc2VhdCl7XHJcbiAgICAgICAgICAgICAgICB2YXIgY2FyZF9sZW5ndGg9dXNlcmRhdGEubGNhcmQuc2l6ZTtcclxuICAgICAgICAgICAgICAgIHVzZXJkYXRhLmxjYXJkLmdldChjYXJkX2xlbmd0aC0xKS5wb2ludD1lLlRjYXJkLkNhcmRQb2ludDtcclxuICAgICAgICAgICAgICAgIHVzZXJkYXRhLmxjYXJkLmdldChjYXJkX2xlbmd0aC0xKS5zdGF0ZT1lLlRjYXJkLkNhcmRTdGF0dXM7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8v5q2j56Gu5L2N572u5o+S5YWl55qE6YCa55So5qih5p2/XHJcbiAgICBJbnNlcnRfdGVtcGxhdGU6ZnVuY3Rpb24oY2FyZHMpe1xyXG4gICAgICAgIHZhciBjYXJkX2xlbmd0aD1jYXJkcy5zaXplO1xyXG4gICAgICAgIHZhciBwb3NidWZmPWNhcmRzLmdldChjYXJkX2xlbmd0aC0xKS5wb3NpO1xyXG4gICAgICAgIGNhcmRzLmdldChjYXJkX2xlbmd0aC0xKS5wb3NpPWNhcmRfbGVuZ3RoO1xyXG4gICAgICAgIGZvcih2YXIgaT1jYXJkX2xlbmd0aDtpPnBvc2J1ZmY7aS0tKXtcclxuICAgICAgICAgICAgW2NhcmRzLmdldChpLTEpLnBvaW50LGNhcmRzLmdldChpLTIpLnBvaW50XT1bY2FyZHMuZ2V0KGktMikucG9pbnQsY2FyZHMuZ2V0KGktMSkucG9pbnRdO1xyXG4gICAgICAgICAgICBbY2FyZHMuZ2V0KGktMSkuc3VpdCxjYXJkcy5nZXQoaS0yKS5zdWl0XT1bY2FyZHMuZ2V0KGktMikuc3VpdCxjYXJkcy5nZXQoaS0xKS5zdWl0XTtcclxuICAgICAgICAgICAgW2NhcmRzLmdldChpLTEpLnN0YXRlLGNhcmRzLmdldChpLTIpLnN0YXRlXT1bY2FyZHMuZ2V0KGktMikuc3RhdGUsY2FyZHMuZ2V0KGktMSkuc3RhdGVdO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy/mm7TmlrDlgqjlrZjljaHniYznmoRtYXDnmoTkv6Hmga9cclxuICAgIEluc2VydF9jYXJkOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdXNlcmRhdGEuaW5zZXJ0X2NvdW50Kz0xO1xyXG4gICAgICAgIGlmKHVzZXJkYXRhLmZ0cGxheWVyPT09dXNlcmRhdGEubXNlYXQpe1xyXG4gICAgICAgICAgICBpZih1c2VyZGF0YS5pbnNlcnRfY291bnQ9PT0xKXtcclxuICAgICAgICAgICAgICAgIHZhciBjYXJkX2xlbmd0aD11c2VyZGF0YS5tY2FyZC5zaXplO1xyXG4gICAgICAgICAgICAgICAgZm9yKHZhciBpPWNhcmRfbGVuZ3RoLTI7aT49MDtpLS0pe1xyXG4gICAgICAgICAgICAgICAgICAgIGlmKCh1c2VyZGF0YS5tY2FyZC5nZXQoaSkucG9pbnQ+dXNlcmRhdGEubWNhcmQuZ2V0KGkrMSkucG9pbnQpfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICgodXNlcmRhdGEubWNhcmQuZ2V0KGkpLnBvaW50PT09dXNlcmRhdGEubWNhcmQuZ2V0KGkrMSkucG9pbnQpJiZ1c2VyZGF0YS5tY2FyZC5nZXQoaSkuc3VpdD09PVwiYmxhY2tcIikpe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBbdXNlcmRhdGEubWNhcmQuZ2V0KGkpLnBvaW50LHVzZXJkYXRhLm1jYXJkLmdldChpKzEpLnBvaW50XT1bdXNlcmRhdGEubWNhcmQuZ2V0KGkrMSkucG9pbnQsdXNlcmRhdGEubWNhcmQuZ2V0KGkpLnBvaW50XTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgW3VzZXJkYXRhLm1jYXJkLmdldChpKS5zdWl0LHVzZXJkYXRhLm1jYXJkLmdldChpKzEpLnN1aXRdPVt1c2VyZGF0YS5tY2FyZC5nZXQoaSsxKS5zdWl0LHVzZXJkYXRhLm1jYXJkLmdldChpKS5zdWl0XTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgW3VzZXJkYXRhLm1jYXJkLmdldChpKS5zdGF0ZSx1c2VyZGF0YS5tY2FyZC5nZXQoaSsxKS5zdGF0ZV09W3VzZXJkYXRhLm1jYXJkLmdldChpKzEpLnN0YXRlLHVzZXJkYXRhLm1jYXJkLmdldChpKS5zdGF0ZV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFt1c2VyZGF0YS5tY2FyZC5nZXQoaSkucG9zaSx1c2VyZGF0YS5tY2FyZC5nZXQoaSsxKS5wb3NpXT1bdXNlcmRhdGEubWNhcmQuZ2V0KGkrMSkucG9zaSx1c2VyZGF0YS5tY2FyZC5nZXQoaSkucG9zaV07XHJcbiAgICAgICAgICAgICAgICAgICAgfWVsc2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgdGhpcy5JbnNlcnRfdGVtcGxhdGUodXNlcmRhdGEubWNhcmQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfWVsc2UgaWYodXNlcmRhdGEuZnRwbGF5ZXI9PT11c2VyZGF0YS5vc2VhdCl7XHJcbiAgICAgICAgICAgIHRoaXMuSW5zZXJ0X3RlbXBsYXRlKHVzZXJkYXRhLm9jYXJkKTtcclxuICAgICAgICB9ZWxzZSBpZih1c2VyZGF0YS5mdHBsYXllcj09PXVzZXJkYXRhLmxzZWF0KXtcclxuICAgICAgICAgICAgdGhpcy5JbnNlcnRfdGVtcGxhdGUodXNlcmRhdGEubGNhcmQpO1xyXG4gICAgICAgIH1lbHNlIGlmKHVzZXJkYXRhLmZ0cGxheWVyPT09dXNlcmRhdGEucnNlYXQpe1xyXG4gICAgICAgICAgICB0aGlzLkluc2VydF90ZW1wbGF0ZSh1c2VyZGF0YS5yY2FyZCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvL+e7k+adn+aVsOaNruaOpeaUtlxyXG4gICAgT3ZlcjpmdW5jdGlvbihlKXtcclxuICAgICAgICB1c2VyZGF0YS53aW5uZXJfc2VhdD1lLlNXaW5uZXI7XHJcbiAgICAgICAgdXNlcmRhdGEuZ3Vlc3NlZG1hbj1lLlNlYXQ7XHJcbiAgICAgICAgdXNlcmRhdGEuZ3Vlc3NlZGNhcmQgPSBlLkNhcmQ7XHJcbiAgICAgICAgdXNlcmRhdGEuZ3Vlc3NlZGNhcmQucG9pbnQ9ZS5DYXJkLkNhcmRQb2ludDtcclxuICAgICAgICB1c2VyZGF0YS5ndWVzc2VkY2FyZC5zdWl0PWUuQ2FyZC5DYXJkU3VpdDtcclxuICAgICAgICB1c2VyZGF0YS5ndWVzc2VkY2FyZC5wb3NpPWUuQ2FyZC5Qb3NpdGlvbjtcclxuICAgICAgICB1c2VyZGF0YS5ndWVzc2VkY2FyZC5zdGF0ZT1lLkNhcmQuQ2FyZFN0YXR1cztcclxuICAgICAgICBpZih1c2VyZGF0YS53aW5uZXJfc2VhdD09PXVzZXJkYXRhLm9zZWF0KXtcclxuICAgICAgICAgICAgdGhpcy5Nb2RpZnlfY2FyZChlLkhhbmRzLHVzZXJkYXRhLm9jYXJkKTtcclxuICAgICAgICB9ZWxzZSBpZih1c2VyZGF0YS53aW5uZXJfc2VhdD09PXVzZXJkYXRhLnJzZWF0KXtcclxuICAgICAgICAgICAgdGhpcy5Nb2RpZnlfY2FyZChlLkhhbmRzLHVzZXJkYXRhLnJjYXJkKTtcclxuICAgICAgICB9ZWxzZSBpZih1c2VyZGF0YS53aW5uZXJfc2VhdD09PXVzZXJkYXRhLmxzZWF0KXtcclxuICAgICAgICAgICAgdGhpcy5Nb2RpZnlfY2FyZChlLkhhbmRzLHVzZXJkYXRhLmxjYXJkKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG59O1xyXG4iLCIvL+agueaNruS9jee9ru+8jOeJjOeahOminOiJsu+8jOeJjOeahOeCueaVsOiOt+WPluebuOW6lOeJjOeahOWbvueJh1xyXG52YXIgY2FyZFNwcml0ZXMgPSBbXTsvL+WNoeeJjOeyvueBteaVsOe7hFxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczogeyAgXHJcbiAgICAgIGxlZnRBdGxhczp7Ly/lt6bovrnnjqnlrrbljaHniYzlm77niYfkv6Hmga9cclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLlNwcml0ZUF0bGFzXHJcbiAgICAgICAgfSxcclxuICAgICAgICBcclxuICAgICAgICByaWdodEF0bGFzOnsvL+WPs+i+ueeOqeWutuWNoeeJjOWbvueJh+S/oeaBr1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuU3ByaXRlQXRsYXNcclxuICAgICAgICB9LFxyXG4gICAgICAgIFxyXG4gICAgICAgIG9wcG9zaXRlQXRsYXM6ey8v5a+56Z2i546p5a625Y2h54mM5Zu+54mH5L+h5oGvXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5TcHJpdGVBdGxhc1xyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIG15c2VsZkF0bGFzOnsvL+iHquW3seeOqeWutuWNoeeJjOWbvueJh+S/oeaBr1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuU3ByaXRlQXRsYXNcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICB1bmtub3duQXRsYXM6ey8v5pyq55+l5Y2h54mM5Zu+54mH5L+h5oGvXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5TcHJpdGVBdGxhc1xyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIF9zaWRlczpudWxsLFxyXG4gICAgICAgIF9wcmVzOm51bGwsXHJcbiAgICAgICAgY2FyZFNwcml0ZXM6bnVsbCxcclxuICAgXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgc2VsZi5fc2lkZXMgPSBbXCJteXNlbGZcIixcInJpZ2h0XCIsXCJvcHBvc2l0ZVwiLFwibGVmdFwiXTtcclxuICAgICAgc2VsZi5fcHJlcyA9IFtcIk1fXCIsXCJSX1wiLFwiT19cIixcIkxfXCJdO1xyXG5cclxuICAgICAgXHJcbiAgICAgIC8v5Y2h54mM54K55pWwXHJcbiAgICAgIGZvcih2YXIgaSA9IDA7aSA8IDE0OyArK2kpe1xyXG4gICAgICAgICAgY2FyZFNwcml0ZXMucHVzaChpKTsvLzB+MTHlrZjlgqgwfjEx54K554mM77yMMTLlrZjkuIfog73niYzvvIwxM+WtmOWCqOacquefpeeJjFxyXG4gICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvL+mAmui/h+eJjOeahOeCueaVsOiOt+WPluWvueW6lOWbvueJh+eahOeCueaVsFxyXG4gICAgZ2V0Q2FyZFNwcml0ZUJ5SUQ6IGZ1bmN0aW9uKGlkKXtcclxuICAgICAgICByZXR1cm4gY2FyZFNwcml0ZXNbaWRdO1xyXG4gICAgfSxcclxuICAgIFxyXG4gICAgLy/pgJrov4fniYznmoTpopzoibLojrflj5bniYznmoTnsbvlnotcclxuICAgIGdldENhcmRUeXBlOmZ1bmN0aW9uKGNvbG9yKSB7XHJcbiAgICAgICAgdmFyIHN0ciA9IFwiXCI7XHJcbiAgICAgICAgIGlmKGNvbG9yPT1cIndoaXRlXCIpe1xyXG4gICAgICAgICBzdHIgPSBcIndoaXRlY2FyZF9cIjtcclxuICAgICAgICAgcmV0dXJuIHN0cjsgXHJcbiAgICAgICAgfVxyXG4gICAgICAgICBpZihjb2xvcj09XCJibGFja1wiKXtcclxuICAgICAgICAgc3RyID0gXCJibGFja2NhcmRfXCI7XHJcbiAgICAgICAgIHJldHVybiBzdHI7IFxyXG4gICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgLy/pgJrov4fliY3nvIDvvIzpopzoibLnsbvlnovlkozngrnmlbDlvpfliLDljaHniYzlm77niYfnmoTlkI3lrZdcclxuICAgIGdldFNwcml0ZUZyYW1lQnlDYXJkSUQ6IGZ1bmN0aW9uKHByZSxjb2xvcixjYXJkSWQpe1xyXG4gICAgICAgIHZhciB0eXBlID0gdGhpcy5nZXRDYXJkVHlwZShjb2xvcik7XHJcbiAgICAgICAgdmFyIHNwcml0ZUZyYW1lTmFtZSA9IHRoaXMuZ2V0Q2FyZFNwcml0ZUJ5SUQoY2FyZElkKTtcclxuICAgICAgICBzcHJpdGVGcmFtZU5hbWUgPSBwcmUgKyB0eXBlICsgc3ByaXRlRnJhbWVOYW1lO1xyXG4gICAgICAgIGlmKHByZSA9PSBcIk1fXCIpe1xyXG4gICAgICAgICAgICBpZihjYXJkSWQ9PTEyKXtcclxuICAgICAgICAgICAgICAgIHNwcml0ZUZyYW1lTmFtZSA9IHByZSArIHR5cGUgKyBcIiByYW5kb21cIjtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLm15c2VsZkF0bGFzLmdldFNwcml0ZUZyYW1lKHNwcml0ZUZyYW1lTmFtZSk7XHJcbiAgICAgICAgICAgIH1lbHNlIGlmKGNhcmRJZD09MTMpey8v6Ieq5bex55qE5omL54mM5rKh5pyJMTPngrnvvIzljbPmnKrnn6XniYxcclxuICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICAgIHNwcml0ZUZyYW1lTmFtZSA9IHByZSArIHR5cGUgKyBjYXJkSWQ7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLm15c2VsZkF0bGFzLmdldFNwcml0ZUZyYW1lKHNwcml0ZUZyYW1lTmFtZSk7XHJcbiAgICAgICAgICAgIH0gICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZihwcmUgPT0gXCJPX1wiKXtcclxuICAgICAgICAgICAgaWYoY2FyZElkPT0xMil7XHJcbiAgICAgICAgICAgICAgICBzcHJpdGVGcmFtZU5hbWUgPSBwcmUgKyB0eXBlICsgXCIgcmFuZG9tXCI7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5vcHBvc2l0ZUF0bGFzLmdldFNwcml0ZUZyYW1lKHNwcml0ZUZyYW1lTmFtZSk7XHJcbiAgICAgICAgICAgIH1lbHNlIGlmKGNhcmRJZD09MTMpeyBcclxuICAgICAgICAgICAgICAgIHNwcml0ZUZyYW1lTmFtZSA9IHByZSArIHR5cGUgKyBcInVua1wiO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMub3Bwb3NpdGVBdGxhcy5nZXRTcHJpdGVGcmFtZShzcHJpdGVGcmFtZU5hbWUpO1xyXG4gICAgICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICAgIHNwcml0ZUZyYW1lTmFtZSA9IHByZSArIHR5cGUgKyBjYXJkSWQ7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5vcHBvc2l0ZUF0bGFzLmdldFNwcml0ZUZyYW1lKHNwcml0ZUZyYW1lTmFtZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZihwcmUgPT0gXCJMX1wiKXtcclxuICAgICAgICAgICAgaWYoY2FyZElkPT0xMil7XHJcbiAgICAgICAgICAgICAgICBzcHJpdGVGcmFtZU5hbWUgPSBwcmUgKyB0eXBlICsgXCIgcmFuZG9tXCI7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5sZWZ0QXRsYXMuZ2V0U3ByaXRlRnJhbWUoc3ByaXRlRnJhbWVOYW1lKTtcclxuICAgICAgICAgICAgfWVsc2UgaWYoY2FyZElkPT0xMyl7IFxyXG4gICAgICAgICAgICAgICAgc3ByaXRlRnJhbWVOYW1lID0gcHJlICsgdHlwZSArIFwidW5rXCI7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5sZWZ0QXRsYXMuZ2V0U3ByaXRlRnJhbWUoc3ByaXRlRnJhbWVOYW1lKTtcclxuICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICBzcHJpdGVGcmFtZU5hbWUgPSBwcmUgKyB0eXBlICsgY2FyZElkO1xyXG4gICAgICAgICAgICAgIHJldHVybiB0aGlzLmxlZnRBdGxhcy5nZXRTcHJpdGVGcmFtZShzcHJpdGVGcmFtZU5hbWUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYocHJlID09IFwiUl9cIil7XHJcbiAgICAgICAgICAgIGlmKGNhcmRJZD09MTIpe1xyXG4gICAgICAgICAgICAgICAgc3ByaXRlRnJhbWVOYW1lID0gcHJlICsgdHlwZSArIFwiIHJhbmRvbVwiO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucmlnaHRBdGxhcy5nZXRTcHJpdGVGcmFtZShzcHJpdGVGcmFtZU5hbWUpO1xyXG4gICAgICAgICAgICB9ZWxzZSBpZihjYXJkSWQ9PTEzKXsgXHJcbiAgICAgICAgICAgICAgICBzcHJpdGVGcmFtZU5hbWUgPSBwcmUgKyB0eXBlICsgXCJ1bmtcIjtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnJpZ2h0QXRsYXMuZ2V0U3ByaXRlRnJhbWUoc3ByaXRlRnJhbWVOYW1lKTtcclxuICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICBzcHJpdGVGcmFtZU5hbWUgPSBwcmUgKyB0eXBlICsgY2FyZElkO1xyXG4gICAgICAgICAgICAgIHJldHVybiB0aGlzLnJpZ2h0QXRsYXMuZ2V0U3ByaXRlRnJhbWUoc3ByaXRlRnJhbWVOYW1lKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBcclxufSk7XHJcblxyXG4iLCJ2YXIgc29rZXQgPSByZXF1aXJlKFwiU29rZXRVdGlsc1wiKTtcclxudmFyIHVzZXJkYXRhID0gcmVxdWlyZShcIlVzZXJEYXRhXCIpO1xyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgZmxvYXRpbmdCb3g6ey8v5rWu5qGG5pi+56S6XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5Ob2RlLCAgICAgICAgICAgICBcclxuICAgICAgICB9LFxyXG4gICAgICAgIElzRGlzcGxheTpudWxsLFxyXG4gICAgICAgIGFza2luZ0J1dHRvbjp7Ly9cclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLk5vZGUsICAgICAgICAgICAgIFxyXG4gICAgICAgIH0sXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHNlbGYuSXNEaXNwbGF5ID0gZmFsc2U7XHJcbiAgICB9LFxyXG5cclxuICAgIC8v5by55Ye65rWu5qGGXHJcbiAgICBTaG93RmxvYXRpbmdCb3g6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIGlmKHNlbGYuSXNEaXNwbGF5ID09IGZhbHNlKXtcclxuICAgICAgICAgICBzZWxmLklzRGlzcGxheSA9IHRydWU7XHJcbiAgICAgICAgfWVsc2UgaWYoc2VsZi5Jc0Rpc3BsYXkgPT0gdHJ1ZSl7XHJcbiAgICAgICAgICAgICAgICAgc2VsZi5Jc0Rpc3BsYXkgPSBmYWxzZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmKHNlbGYuSXNEaXNwbGF5ID09IHRydWUpe1xyXG4gICAgICAgICAgIHNlbGYuZmxvYXRpbmdCb3guYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICB9ZWxzZSBpZihzZWxmLklzRGlzcGxheSA9PSBmYWxzZSl7XHJcbiAgICAgICAgICAgc2VsZi5mbG9hdGluZ0JveC5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8v5YWz6Zet5rWu5qGGXHJcbiAgICBDbG9zZUZsb2F0aW5nQm94OmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHNlbGYuZmxvYXRpbmdCb3guYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgc2VsZi5Jc0Rpc3BsYXkgPSBmYWxzZTtcclxuICAgICAgICB1c2VyZGF0YS5zZWxlY3RlZE1haWxJRCA9IG51bGw7XHJcbiAgICB9LCBcclxuXHJcbiAgICAvL1xyXG4gICAgIHVwZGF0ZTpmdW5jdGlvbihkdCl7XHJcbiAgICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICAvLyAgaWYodXNlcmRhdGEuYXNraW5nRnJpZW5kSW5mbyE9bnVsbCYmdXNlcmRhdGEuYXNraW5nRnJpZW5kSW5mby5sZW5ndGghPTApe1xyXG4gICAgICAgIC8vICAgICBzZWxmLmFza2luZ0J1dHRvbi5jb2xvciA9IG5ldyBjYy5Db2xvcigwLDE5MSwyNTUpO1xyXG4gICAgICAgIC8vIH1lbHNle1xyXG4gICAgICAgIC8vICAgICBzZWxmLmFza2luZ0J1dHRvbi5jb2xvciA9IG5ldyBjYy5Db2xvcigyNTUsMjU1LDI1NSwyNTUpOyBcclxuICAgICAgICAvLyB9XHJcbiAgICAgfVxyXG59KTtcclxuIiwiLy/lpb3lj4vns7vnu5/lrqLmiLfnq6/lkozmnI3liqHlmajnmoTmlbDmja7kuqTkupJcclxudmFyIHVzZXJkYXRhID0gcmVxdWlyZSgnVXNlckRhdGEnKTtcclxubW9kdWxlLmV4cG9ydHM9e1xyXG4gICAgICAgIGZyaWVuZE51bTowLC8v5aW95Y+L5pWw6YePXHJcbiAgICAgICAgc2VhcmNoRnJpZW5kTnVtOjAsLy/mkJzntKLlpb3lj4vmlbDph49cclxuLy/liJ3lp4vljJbnlKjmiLflpb3lj4vkv6Hmga/miJbogIXmkJzntKLnmoTnjqnlrrbkv6Hmga9cclxuSW5pdF9mcmllbmRfaW5mbzpmdW5jdGlvbihmcmllbmRzLGFycmF5KXtcclxuICAgIC8v546w5Zyo5pyN5Yqh5Zmo6L+Y5rKh5pyJ5Lyg5pWw5o2u6L+H5p2l77yM5YWI5pys5Zyw5rWL6K+V5LiA5LiLXHJcbiAgICAvL+WBh+iuvuWlveWPi+S/oeaBr+WtmOaciWlkLOeUqOaIt+WktOWDj++8jOeUqOaIt+aYteensO+8jOeUqOaIt+etiee6p1xyXG4gICAgZm9yKHZhciBpID0gdGhpcy5mcmllbmROdW0tMTtpPj0wO2ktLSl7XHJcbiAgICAgICAgICAgIHZhciBmcmllbmQ9bmV3IE1hcCgpO1xyXG4gICAgICAgICAgICBmcmllbmQuSUQgPSBmcmllbmRzW2ldLlBfaWQ7XHJcbiAgICAgICAgICAgIGZyaWVuZC5GcmllbmRJY29uPWZyaWVuZHNbaV0uSGVhZEltYWdlO1xyXG4gICAgICAgICAgICBmcmllbmQuRnJpZW5kTmFtZT1mcmllbmRzW2ldLk5hbWU7XHJcbiAgICAgICAgICAgIGZyaWVuZC5GcmllbmRHcmFkZT1mcmllbmRzW2ldLkdyYWRlO1xyXG4gICAgICAgICAgICBmcmllbmQuRnJpZW5kU3RhdHVzPWZyaWVuZHNbaV0uR2FtZVN0YXR1cztcclxuICAgICAgICAgICAgYXJyYXlbaV0gPSBmcmllbmQ7XHJcbiAgICAgICAgfSAgIFxyXG59LFxyXG5cclxuSW5pdF9zZWFyY2hlZGZyaWVuZF9pbmZvOmZ1bmN0aW9uKGZyaWVuZHMsYXJyYXkpe1xyXG4gICAgLy/njrDlnKjmnI3liqHlmajov5jmsqHmnInkvKDmlbDmja7ov4fmnaXvvIzlhYjmnKzlnLDmtYvor5XkuIDkuItcclxuICAgIC8v5YGH6K6+5aW95Y+L5L+h5oGv5a2Y5pyJaWQs55So5oi35aS05YOP77yM55So5oi35pi156ew77yM55So5oi3562J57qnXHJcbiAgICBmb3IodmFyIGkgPSB0aGlzLnNlYXJjaEZyaWVuZE51bS0xO2k+PTA7aS0tKXtcclxuICAgICAgICAgICAgdmFyIGZyaWVuZD1uZXcgTWFwKCk7XHJcbiAgICAgICAgICAgIGZyaWVuZC5JRCA9IGZyaWVuZHNbaV0uUF9pZDtcclxuICAgICAgICAgICAgZnJpZW5kLkZyaWVuZEljb249ZnJpZW5kc1tpXS5IZWFkSW1hZ2U7XHJcbiAgICAgICAgICAgIGZyaWVuZC5GcmllbmROYW1lPWZyaWVuZHNbaV0uTmFtZTtcclxuICAgICAgICAgICAgZnJpZW5kLkZyaWVuZEdyYWRlPWZyaWVuZHNbaV0uR3JhZGU7XHJcbiAgICAgICAgICAgIGZyaWVuZC5GcmllbmRTdGF0dXM9ZnJpZW5kc1tpXS5HYW1lU3RhdHVzO1xyXG4gICAgICAgICAgICBhcnJheVtpXSA9IGZyaWVuZDtcclxuICAgICAgICB9ICAgXHJcbn0sXHJcblxyXG5Jbml0X2Fza2luZ2ZyaWVuZF9pbmZvOmZ1bmN0aW9uKGZyaWVuZCxhcnJheSl7XHJcbiAgICAgICAgICAgIHZhciBmPW5ldyBNYXAoKTtcclxuICAgICAgICAgICAgZi5JRD0tMTtcclxuICAgICAgICAgICAgZi5GcmllbmRJY29uPWZyaWVuZC5IZWFkSW1hZ2U7XHJcbiAgICAgICAgICAgIGYuRnJpZW5kTmFtZT1mcmllbmQuTmFtZTtcclxuICAgICAgICAgICAgZi5GcmllbmRHcmFkZT1mcmllbmQuR3JhZGU7XHJcbiAgICAgICAgICAgIGFycmF5LnB1c2goZik7XHJcbn0sXHJcblxyXG4vL+WIneWni+WMlumCrueuseS4remCruS7tuWIl+ihqOeahOmCruS7tuS/oeaBr1xyXG5Jbml0X21haWxfaW5mbzpmdW5jdGlvbihtYWlscyxhcnJheSl7XHJcbiAgICBmb3IodmFyIGkgPSAwO2k8IG1haWxzLmxlbmd0aDsrK2kpe1xyXG4gICAgICAgICAgICB2YXIgbWFpbD1uZXcgTWFwKCk7XHJcbiAgICAgICAgICAgIG1haWwuSUQ9bWFpbHNbaV0uSUQ7XHJcbiAgICAgICAgICAgIG1haWwuRnJpZW5kSWNvbj1tYWlsc1tpXS5GcmllbmRJY29uO1xyXG4gICAgICAgICAgICBtYWlsLkZyaWVuZE5hbWU9bWFpbHNbaV0uRnJpZW5kTmFtZTtcclxuICAgICAgICAgICAgbWFpbC5Db250ZW50PW1haWxzW2ldLkNvbnRlbnQ7XHJcbiAgICAgICAgICAgIGFycmF5W2ldID0gbWFpbDtcclxuICAgICAgICB9XHJcbn0sXHJcbi8v5Yid5aeL5YyW55So5oi35aW95Y+L5L+h5oGvXHJcbkluaXRfZnJpZW5kOmZ1bmN0aW9uKGUpe1xyXG4gICAgdXNlcmRhdGEuZnJpZW5kSW5mbyA9IG5ldyBBcnJheSgpO1xyXG4gICAgdGhpcy5Jbml0X2ZyaWVuZF9pbmZvKGUsdXNlcmRhdGEuZnJpZW5kSW5mbyk7XHJcbn0sXHJcblxyXG4vL+WIneWni+WMluaQnOe0oueahOeOqeWutuS/oeaBr1xyXG5Jbml0X3NlYXJjaF9mcmllbmQ6ZnVuY3Rpb24oZSl7XHJcbiAgICBpZih0aGlzLnNlYXJjaEZyaWVuZE51bSA9PSAwKXtcclxuICAgICAgICBjYy5sb2coXCLmkJzntKLkuLrnqbpcIik7XHJcbiAgICB9ZWxzZXtcclxuICAgIHVzZXJkYXRhLnNlYXJjaEZyaWVuZEluZm8gPSBuZXcgQXJyYXkoKTtcclxuICAgIHRoaXMuSW5pdF9zZWFyY2hlZGZyaWVuZF9pbmZvKGUsdXNlcmRhdGEuc2VhcmNoRnJpZW5kSW5mbyk7XHJcbiAgICB9XHJcbn0sXHJcblxyXG4vL+WIneWni+WMluivt+axgueOqeWutuS/oeaBr1xyXG5Jbml0X2Fza2luZ19mcmllbmQ6ZnVuY3Rpb24oZSl7XHJcbiAgICB1c2VyZGF0YS5hc2tpbmdGcmllbmRJbmZvID0gbmV3IEFycmF5KCk7XHJcbiAgICB0aGlzLkluaXRfYXNraW5nZnJpZW5kX2luZm8oZSx1c2VyZGF0YS5hc2tpbmdGcmllbmRJbmZvKTtcclxufSxcclxuXHJcbi8v5Yid5aeL5YyW6YKu5Lu25L+h5oGvXHJcbkluaXRfbWFpbDpmdW5jdGlvbihlKXtcclxuICAgIHVzZXJkYXRhLm1haWxJbmZvID0gbmV3IEFycmF5KCk7XHJcbiAgICB0aGlzLkluaXRfbWFpbF9pbmZvKGUuTWFpbExpc3QsdXNlcmRhdGEubWFpbEluZm8pO1xyXG59LFxyXG5cclxuLy/lop7liqDlpb3lj4tcclxuQWRkX2ZyaWVuZDpmdW5jdGlvbihmcmllbmRJRCl7XHJcbiAgICBmb3IodmFyIGk9MDtpPHVzZXJkYXRhLnNlYXJjaEZyaWVuZEluZm8ubGVuZ3RoO2krKyl7XHJcbiAgICAgICAgICAgIHZhciBmcmllbmQ9dXNlcmRhdGEuc2VhcmNoRnJpZW5kSW5mb1tpXTtcclxuICAgICAgICAgICAgaWYoZnJpZW5kLklEID09IGZyaWVuZElEKXtcclxuICAgICAgICAgICAgICAgdXNlcmRhdGEuZnJpZW5kSW5mby5wdXNoKGZyaWVuZCk7XHJcbiAgICAgICAgICAgICAgIGJyZWFrOyBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxufSxcclxuXHJcbi8v6YCa6L+H5aW95Y+LSUTliKDpmaTlpb3lj4tcclxuRGVsZXRlX2ZyaWVuZDpmdW5jdGlvbihmcmllbmRJRCl7XHJcbiAgICBmb3IodmFyIGk9MDtpPHVzZXJkYXRhLmZyaWVuZEluZm8ubGVuZ3RoO2krKyl7XHJcbiAgICAgICAgICAgIHZhciBmcmllbmQ9dXNlcmRhdGEuZnJpZW5kSW5mb1tpXTtcclxuICAgICAgICAgICAgaWYoZnJpZW5kLklEID09IGZyaWVuZElEKXtcclxuICAgICAgICAgICAgICAgdXNlcmRhdGEuZnJpZW5kSW5mby5zcGxpY2UoaSwxKTtcclxuICAgICAgICAgICAgICAgYnJlYWs7IFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG59LFxyXG5cclxuXHJcbi8v6YCa6L+H6YKu5Lu2SUTliKDpmaTpgq7ku7ZcclxuRGVsZXRlX21haWw6ZnVuY3Rpb24obWFpbElEKXtcclxuICAgIGZvcih2YXIgaT0wO2k8dXNlcmRhdGEubWFpbEluZm8ubGVuZ3RoO2krKyl7XHJcbiAgICAgICAgICAgIHZhciBtYWlsPXVzZXJkYXRhLm1haWxJbmZvW2ldO1xyXG4gICAgICAgICAgICBpZihtYWlsLklEID09IG1haWxJRCl7XHJcbiAgICAgICAgICAgICAgIHVzZXJkYXRhLm1haWxJbmZvLnNwbGljZShpLDEpO1xyXG4gICAgICAgICAgICAgICBicmVhazsgXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbn0sXHJcblxyXG4vL+mAmui/h+WQjeensOWIoOmZpFxyXG5EZWxldGVfYXNraW5nX2ZyaWVuZDpmdW5jdGlvbihmcmllbmROYW1lKXtcclxuICAgIGZvcih2YXIgaT0wO2k8dXNlcmRhdGEuYXNraW5nRnJpZW5kSW5mby5sZW5ndGg7aSsrKXtcclxuICAgICAgICAgICAgdmFyIGZyaWVuZD11c2VyZGF0YS5hc2tpbmdGcmllbmRJbmZvW2ldO1xyXG4gICAgICAgICAgICBpZihmcmllbmQuRnJpZW5kTmFtZSA9PSBmcmllbmROYW1lKXtcclxuICAgICAgICAgICAgICAgdXNlcmRhdGEuYXNraW5nRnJpZW5kSW5mby5zcGxpY2UoaSwxKTtcclxuICAgICAgICAgICAgICAgYnJlYWs7IFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG59LFxyXG5cclxuLy/pgJrov4flpb3lj4tJROiOt+W+l+WlveWPi+WQjeWtl1xyXG5HZXRGcmllbmROYW1lOmZ1bmN0aW9uKGZyaWVuZElEKXtcclxuICAgIGZvcih2YXIgaT0wO2k8dXNlcmRhdGEuZnJpZW5kSW5mby5sZW5ndGg7aSsrKXtcclxuICAgICAgICAgICAgdmFyIGZyaWVuZD11c2VyZGF0YS5mcmllbmRJbmZvW2ldO1xyXG4gICAgICAgICAgICBpZihwYXJzZUludChmcmllbmQuSUQpID09IGZyaWVuZElEKXtcclxuICAgICAgICAgICAgICAgcmV0dXJuIHVzZXJkYXRhLmZyaWVuZEluZm9baV0uRnJpZW5kTmFtZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxufSxcclxuXHJcbi8v5riF56m65YiX6KGo5L+h5oGvXHJcbkNsZWFyX2xpc3Q6ZnVuY3Rpb24oYXJyYXkpe1xyXG4gICAgYXJyYXkuc3BsaWNlKDAsYXJyYXkubGVuZ3RoKTtcclxufSxcclxuXHJcblxyXG59O1xyXG4gICBcclxuIiwidmFyIHVzZXJkYXRhID0gcmVxdWlyZSgnVXNlckRhdGEnKTtcclxudmFyIGZyaWVuZCA9IHJlcXVpcmUoJ0ZyaWVuZEFjdGl2aXR5Jyk7XHJcbnZhciBodHRwID0gcmVxdWlyZSgnSHR0cFV0aWxzJyk7XHJcbnZhciBzb2tldCA9IHJlcXVpcmUoXCJTb2tldFV0aWxzXCIpO1xyXG52YXIgSXRlbSA9IGNjLkNsYXNzKHtcclxuICAgIG5hbWU6XCJJdGVtXCIsXHJcbiAgICBwcm9wZXJ0aWVzOntcclxuICAgICAgICBpZDowLFxyXG4gICAgICAgIGZyaWVuZE5hbWU6XCJcIixcclxuICAgICAgICBmcmllbmRHcmFkZTowLFxyXG4gICAgICAgIGZyaWVuZEljb246Y2MuU3ByaXRlRnJhbWUsXHJcbiAgICB9LFxyXG59KTtcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgaXRlbXM6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OltdLFxyXG4gICAgICAgICAgICB0eXBlOkl0ZW0sXHJcbiAgICAgICAgfSwgIFxyXG4gICAgICAgIGl0ZW1GcmllbmRQcmVmYWI6IGNjLlByZWZhYixcclxuICAgICAgICBoZWFkQXRsYXM6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuU3ByaXRlQXRsYXNcclxuICAgICAgICB9LFxyXG4gICAgICAgIGZyaWVuZExpc3RDb250ZW50OnsvL+WlveWPi+WIl+ihqOWGheWuuVxyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIGZyaWVuZExpc3Q6ey8v546w5pyJ55qE55qE546p5a625YiX6KGoXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5Ob2RlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZnJpZW5kQ2hhdE5hbWUxOnsvL+iBiuWkqe+8jOaYvuekuuato+mAieaLqeeahOWlveWPi1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTGFiZWwsIFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgY2hhdEVkaXQ6ey8v6IGK5aSp6L6T5YWl5L+h5oGv5qGGXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5FZGl0Qm94LCAgICAgICAgICAgICBcclxuICAgICAgICB9LFxyXG4gICAgICAgIGNoYXRDb250ZW50OnsvL+iBiuWkqei+k+WFpeS/oeaBr+mrmOW6plxyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZSxcclxuICAgICAgICB9LCBcclxuICAgICAgICBjaGF0TGFiZWw6ey8v6IGK5aSp5L+h5oGv55qEaXRlbVxyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTGFiZWwsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBmcmllbmRDaGF0TmFtZTI6ey8v6YKu5Lu277yM5pi+56S65q2j6YCJ5oup55qE5aW95Y+LXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5MYWJlbCwgXHJcbiAgICAgICAgfSxcclxuICAgICAgICBtYWlsRWRpdDp7Ly/ogYrlpKnovpPlhaXkv6Hmga/moYZcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLkVkaXRCb3gsICAgICAgICAgICAgIFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZG9Jbml0Q2hhdEluZm86bnVsbCxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgc2VsZi5kb0luaXRDaGF0SW5mbyA9IGZhbHNlO1xyXG4gICAgICAgIC8v5q2k5aSE57uZ5pyN5Yqh5Zmo5Y+R6YCB6K+35rGCXHJcbiAgICAgICAgc2VsZi5Bc2tGcmllbmQoKTtcclxuICAgICAgICBcclxuICAgIH0sXHJcblxyXG5cclxuICAgIC8v6K+35rGC5aW95Y+L5YiX6KGoXHJcbiAgICBBc2tGcmllbmQ6ZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgLy/mraTlpITnu5nmnI3liqHlmajlj5HpgIHor7fmsYJcclxuICAgICAgICB2YXIgIGNvbnRlbnQgPSBKU09OLnN0cmluZ2lmeSh7VHlwZToxMDA1MyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTsgICAgICBcclxuICAgICAgICBjYy5sb2coXCLlkJHlpb3lj4vmnI3liqHlmajlj5HpgIHor7fmsYLlpb3lj4vliJfooajmtojmga/vvJpcIik7XHJcbiAgICAgICAgY2MubG9nKEpTT04ucGFyc2UoY29udGVudCkpO1xyXG4gICAgICAgIHNva2V0LndzLnNlbmQoY29udGVudCk7Ly/lj5HpgIHmtojmga8gXHJcbiAgICAgICAgc29rZXQuZ2V0Q2hhdE1zZygpOy8v55uR5ZCs6I635Y+W5L+h5oGvICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgfSxcclxuXHJcbiAgICAvL+WIneWni+WMluWlveWPi+WIl+ihqFxyXG4gICAgSW5pdEZyaWVuZDpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBpZih1c2VyZGF0YS5mcmllbmRJbmZvPT1udWxsKXtcclxuXHJcbiAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgIC8vY2MubG9nKHVzZXJkYXRhLmZyaWVuZEluZm8pO1xyXG4gICAgICAgICAgICBzZWxmLkNsZWFyRnJpZW5kcygpO1xyXG4gICAgICAgICAgICBzZWxmLml0ZW1zLmxlbmd0aCA9IHVzZXJkYXRhLmZyaWVuZEluZm8ubGVuZ3RoO1xyXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHNlbGYuaXRlbXMubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgIHZhciBpdGVtID0gY2MuaW5zdGFudGlhdGUoc2VsZi5pdGVtRnJpZW5kUHJlZmFiKTtcclxuICAgICAgICAgICAgICAgIHNlbGYuaXRlbXNbaV0gPSB1c2VyZGF0YS5mcmllbmRJbmZvW2ldO1xyXG4gICAgICAgICAgICAgICAgdmFyIGRhdGEgPSBzZWxmLml0ZW1zW2ldO1xyXG4gICAgICAgICAgICAgICAgc2VsZi5ub2RlLmFkZENoaWxkKGl0ZW0pO1xyXG4gICAgICAgICAgICAgICAgaXRlbS5nZXRDb21wb25lbnQoJ0l0ZW1GcmllbmQnKS5pbml0KHtcclxuICAgICAgICAgICAgICAgICAgICBpZDogZGF0YS5JRCxcclxuICAgICAgICAgICAgICAgICAgICBpdGVtTmFtZTogZGF0YS5GcmllbmROYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW1HcmFkZTogXCLliIbmlbA6XCIrZGF0YS5GcmllbmRHcmFkZSxcclxuICAgICAgICAgICAgICAgICAgICBpY29uU0Y6IHNlbGYuaGVhZEF0bGFzLmdldFNwcml0ZUZyYW1lKGRhdGEuRnJpZW5kSWNvbiksXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBzZWxmLmZyaWVuZExpc3RDb250ZW50LmhlaWdodCA9IDIwMCvjgIB1c2VyZGF0YS5mcmllbmRJbmZvLmxlbmd0aCo2MDsgICAgICAgXHJcbiAgICAgICAgfSAgIFxyXG4gICAgfSxcclxuXHJcbiAgICAvL+a4heepuuWIl+ihqFxyXG4gICAgQ2xlYXJGcmllbmRzOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIGZvcih2YXIgaSA9c2VsZi5mcmllbmRMaXN0Q29udGVudC5jaGlsZHJlbi5sZW5ndGgtMTsgaSA+PTA7aS0tKXtcclxuICAgICAgICAgICAgc2VsZi5mcmllbmRMaXN0Q29udGVudC5yZW1vdmVDaGlsZChzZWxmLmZyaWVuZExpc3RDb250ZW50LmNoaWxkcmVuW2ldKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8v5Yig6Zmk5aW95Y+L5oyJ6ZKu5Ye95pWwXHJcbiAgICBBc2tEZWxldGVGcmllbmQ6ZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgaWYoc2VsZi5mcmllbmRMaXN0LmFjdGl2ZSA9PSB0cnVlKXtcclxuICAgICAgICAgICAgaWYodXNlcmRhdGEuc2VsZWN0ZWRGcmllbmRJRCA9PSBudWxsKXtcclxuICAgICAgICAgICAgY2MubG9nKFwi6K+35YWI6YCJ5oup5oOz5Yig6Zmk55qE5aW95Y+LLlwiKTtcclxuICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICAgIC8v5q2k5aSE57uZ5pyN5Yqh5Zmo5Y+R6YCB6K+35rGCXHJcbiAgICAgICAgICAgICAgICB2YXIgIGNvbnRlbnQgPSBKU09OLnN0cmluZ2lmeSh7VHlwZToxMDA3MCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQX2lkOnBhcnNlSW50KHVzZXJkYXRhLnNlbGVjdGVkRnJpZW5kSUQpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pOyAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgY2MubG9nKFwi5ZCR5aW95Y+L5pyN5Yqh5Zmo5Y+R6YCB6K+35rGC5Yig6Zmk5aW95Y+L5raI5oGv77yaXCIpO1xyXG4gICAgICAgICAgICAgICAgY2MubG9nKEpTT04ucGFyc2UoY29udGVudCkpO1xyXG4gICAgICAgICAgICAgICAgc29rZXQud3Muc2VuZChjb250ZW50KTsvL+WPkemAgea2iOaBryBcclxuICAgICAgICAgICAgICAgIHNva2V0LmdldENoYXRNc2coKTsvL+ebkeWQrOiOt+WPluS/oeaBr1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgIGNjLmxvZyhcIuivt+WcqOWlveWPi+WIl+ihqOmAieaLqeWIoOmZpOeahOWlveWPiy5cIik7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIC8v5ZON5bqU5Yig6Zmk5aW95Y+L5Ye95pWwXHJcbiAgICBBbnN3ZXJEZWxldGVGcmllbmQ6ZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgaWYoc29rZXQuaXNEZWxldGVGcmllbmQgPT0gdHJ1ZSl7XHJcbiAgICAgICAgICAgIGNjLmxvZyh1c2VyZGF0YS5mcmllbmRJbmZvKTtcclxuICAgICAgICAgICAgc2VsZi5VcGRhdGVGcmllbmRMaXN0KCk7XHJcbiAgICAgICAgICAgIGNjLmxvZyhcIuWIl+ihqOWlveWPi2l0ZW3mlbDph486XCIrc2VsZi5mcmllbmRMaXN0Q29udGVudC5jaGlsZHJlbi5sZW5ndGgpO1xyXG4gICAgICAgICAgICBzb2tldC5pc0RlbGV0ZUZyaWVuZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICB1c2VyZGF0YS5zZWxlY3RlZEZyaWVuZE5hbWUgID0gbnVsbDtcclxuICAgICAgICAgICAgdXNlcmRhdGEuc2VsZWN0ZWRGcmllbmRJRCA9IG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKHNva2V0Lmhhc0JlZW5EZWxldGVkID09IHRydWUpe1xyXG4gICAgICAgICAgICBzb2tldC5oYXNCZWVuRGVsZXRlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICBzZWxmLkFza0ZyaWVuZCgpO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy/mm7TmlrDlpb3lj4vliJfooahcclxuICAgIFVwZGF0ZUZyaWVuZExpc3Q6ZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgICAgIHNlbGYuZnJpZW5kTGlzdENvbnRlbnQucmVtb3ZlQ2hpbGQoc2VsZi5HZXRSZW1vdmVkSXRlbSh1c2VyZGF0YS5zZWxlY3RlZEZyaWVuZElEKSk7XHJcbiAgICB9LFxyXG5cclxuICAgIC8v56Gu5a6a6KaB56e76Zmk55qEaXRlbVxyXG4gICAgR2V0UmVtb3ZlZEl0ZW06ZnVuY3Rpb24oZnJpZW5kSUQpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBmb3IodmFyIGkgPSAwO2k8c2VsZi5mcmllbmRMaXN0Q29udGVudC5jaGlsZHJlbi5sZW5ndGg7KytpKXtcclxuICAgICAgICAgICAgdmFyIGlkID0gc2VsZi5mcmllbmRMaXN0Q29udGVudC5jaGlsZHJlbltpXS5nZXRDaGlsZEJ5TmFtZShcImlkXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nO1xyXG4gICAgICAgICAgICBpZiggaWQgPT0gZnJpZW5kSUQpe1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHNlbGYuZnJpZW5kTGlzdENvbnRlbnQuY2hpbGRyZW5baV07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8v5qCH6K6w5b2T5YmN54K55Ye755qE5aW95Y+LXHJcbiAgICBTaWduU2VsZWN0ZWRGcmllbmQ6ZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgZm9yKHZhciBpID0gMDtpPHNlbGYuZnJpZW5kTGlzdENvbnRlbnQuY2hpbGRyZW4ubGVuZ3RoOysraSl7XHJcbiAgICAgICAgICAgIHZhciBpZCA9IHNlbGYuZnJpZW5kTGlzdENvbnRlbnQuY2hpbGRyZW5baV0uZ2V0Q2hpbGRCeU5hbWUoXCJpZFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZztcclxuICAgICAgICAgICAgaWYoIGlkID09IHVzZXJkYXRhLnNlbGVjdGVkRnJpZW5kSUQpe1xyXG4gICAgICAgICAgICAgICAgc2VsZi5mcmllbmRMaXN0Q29udGVudC5jaGlsZHJlbltpXS5nZXRDaGlsZEJ5TmFtZShcInNlbGVjdGluZ1wiKS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICAgIHNlbGYuZnJpZW5kTGlzdENvbnRlbnQuY2hpbGRyZW5baV0uZ2V0Q2hpbGRCeU5hbWUoXCJzZWxlY3RpbmdcIikuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IFxyXG4gICAgfSxcclxuXHJcbiAgICAvL+WPkemAgeWSjOWlveWPi+eahOiBiuWkqeS/oeaBr1xyXG4gICAgIHNlbmRDaGF0U3RyaW5nOiBmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBjYy5sb2coXCLmg7Plj5HpgIHnmoTmtojmga/vvJpcIitzZWxmLmNoYXRFZGl0LnN0cmluZyk7XHJcbiAgICAgICAgdmFyICBjaGF0Q29udGVudCA9IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFR5cGU6MTAwNzUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQX2lkOnBhcnNlSW50KHVzZXJkYXRhLnNlbGVjdGVkRnJpZW5kSUQpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGV4dDpzZWxmLmNoYXRFZGl0LnN0cmluZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pOyAgICAgIFxyXG4gICAgICAgIHNva2V0LmdldENoYXRNc2coKTtcclxuICAgICAgICBpZihzZWxmLmNoYXRFZGl0LnN0cmluZyE9XCJcIil7Ly/lj5HpgIHmtojmga/kuI3kuLrnqbrml7ZcclxuICAgICAgICBjYy5sb2coXCLlkJHogYrlpKnmnI3liqHlmajlj5HpgIHogYrlpKnmtojmga/vvJpcIik7XHJcbiAgICAgICAgY2MubG9nKEpTT04ucGFyc2UoY2hhdENvbnRlbnQpKTtcclxuICAgICAgICBzb2tldC53cy5zZW5kKGNoYXRDb250ZW50KTsvL+WPkemAgea2iOaBr1xyXG5cclxuICAgICAgICBzb2tldC5jaGF0RnJpZW5kW3BhcnNlSW50KHVzZXJkYXRhLnNlbGVjdGVkRnJpZW5kSUQpXS5jaGF0RnJpZW5kSGVpZ2h0QWRkKz0xOy8vY29udGVudOWinuWKoOS4gOasoemrmOW6plxyXG4gICAgICAgIHNva2V0LmNoYXRGcmllbmRbcGFyc2VJbnQodXNlcmRhdGEuc2VsZWN0ZWRGcmllbmRJRCldLmNoYXRGcmllbmRTdHJpbmcgPSBcclxuICAgICAgICBzb2tldC5jaGF0RnJpZW5kW3BhcnNlSW50KHVzZXJkYXRhLnNlbGVjdGVkRnJpZW5kSUQpXS5jaGF0RnJpZW5kU3RyaW5nK1wiXFxuXCIrXCLmiJHvvJpcIitzZWxmLm1lcy5UZXh0O1xyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICBzZWxmLmNoYXRFZGl0LnN0cmluZyA9IFwi6L6T5YWl5raI5oGv5LiN6IO95Li656m677yBXCI7XHJcbiAgICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICBzZWxmLmNoYXRFZGl0LnN0cmluZyA9XCJcIjtcclxuICAgICAgICAgICAgfSwgNTAwKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgc2VsZi5jaGF0RWRpdC5QbGFjZWhvbGRlciA9IFwi5Zyo5q2k6L6T5YWl6IGK5aSp5L+h5oGvLi4uLi4uLlwiO1xyXG4gICAgICAgIHNlbGYuY2hhdEVkaXQuc3RyaW5nID0gXCJcIjtcclxuICAgIH0sXHJcblxyXG4gICAgSW5pdENoYXRJbmZvOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPXRoaXM7XHJcbiAgICAgICAgZm9yKHZhciBpID0gMDtpPHVzZXJkYXRhLmZyaWVuZEluZm8ubGVuZ3RoO2krKyl7XHJcbiAgICAgICAgICAgIHZhciBjaGF0ID0gbmV3IE1hcCgpO1xyXG4gICAgICAgICAgICBjaGF0LmNoYXRGcmllbmRTdHJpbmcgPSBcIlxcblwiK1wi6IGK5aSp5aaC5LiL77yaXCI7XHJcbiAgICAgICAgICAgIGNoYXQuY2hhdEZyaWVuZEhlaWdodEFkZCA9IDA7XHJcbiAgICAgICAgICAgIHZhciBqID0gcGFyc2VJbnQodXNlcmRhdGEuZnJpZW5kSW5mb1tpXS5JRCk7XHJcbiAgICAgICAgICAgIHNva2V0LmNoYXRGcmllbmRbal0gPSBjaGF0O1xyXG4gICAgICAgIH1cclxuICAgICAgICBzZWxmLmRvSW5pdENoYXRJbmZvID0gdHJ1ZTtcclxuICAgIH0sXHJcblxyXG4gICAgLy/lj5HpgIHnu5nlpb3lj4vpgq7ku7ZcclxuICAgICBzZW5kRW1pYWxTdHJpbmc6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIGNjLmxvZyhcIuaDs+WPkemAgeeahOmCruS7tu+8mlwiK3NlbGYuY2hhdEVkaXQuc3RyaW5nKTtcclxuICAgICAgICB2YXIgIG1haWxDb250ZW50ID0gSlNPTi5zdHJpbmdpZnkoe0lkOnVzZXJkYXRhLmlkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVHlwZToxMDA0NSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5hbWU6XCI2NjZcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEtleTp1c2VyZGF0YS5jaGF0Um9vbUtleSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRleHQ6c2VsZi5tYWlsRWRpdC5zdHJpbmdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTsgICAgICBcclxuICAgICAgICAvL3Nva2V0LmdldENoYXRNc2coKTtcclxuICAgICAgICBpZihzZWxmLm1haWxFZGl0LnN0cmluZyE9XCJcIil7Ly/lj5HpgIHpgq7ku7bkv6Hmga/kuI3kuLrnqbrml7ZcclxuICAgICAgICBjYy5sb2coXCLlkJHpgq7ku7bmnI3liqHlmajlj5HpgIHpgq7ku7bkv6Hmga/vvJpcIik7XHJcbiAgICAgICAgY2MubG9nKEpTT04ucGFyc2UobWFpbENvbnRlbnQpKTtcclxuICAgICAgICAvL3Nva2V0LndzLnNlbmQobWFpbENvbnRlbnQpOy8v5Y+R6YCB6YKu5Lu25L+h5oGvXHJcbiAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgIHNlbGYubWFpbEVkaXQuc3RyaW5nID0gXCLovpPlhaXpgq7ku7blhoXlrrnkuI3og73kuLrnqbrvvIFcIjtcclxuICAgICAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHNlbGYubWFpbEVkaXQuc3RyaW5nID1cIlwiO1xyXG4gICAgICAgICAgICB9LCAxMDAwKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgc2VsZi5tYWlsRWRpdC5QbGFjZWhvbGRlciA9IFwi5Zyo5q2k6L6T5YWl6YKu5Lu25YaF5a65Li4uLi4uLlwiO1xyXG4gICAgICAgIHNlbGYubWFpbEVkaXQuc3RyaW5nID0gXCJcIjtcclxuICAgIH0sXHJcblxyXG5cclxuICAgIHVwZGF0ZTpmdW5jdGlvbihkdCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHNva2V0LmdldENoYXRNc2coKTsvL+ebkeWQrOiOt+WPluS/oeaBr1xyXG4gICAgICAgIFxyXG4gICAgICAgIHNlbGYuZnJpZW5kQ2hhdE5hbWUxLnN0cmluZyA9IFwi6IGK5aSp5aW95Y+L77yaXCIr44CAdXNlcmRhdGEuc2VsZWN0ZWRGcmllbmROYW1lICsgXCIgIGlkOlwiK3VzZXJkYXRhLnNlbGVjdGVkRnJpZW5kSUQ7XHJcbiAgICAgICAgc2VsZi5mcmllbmRDaGF0TmFtZTIuc3RyaW5nID0gXCLmlLbku7bkurrvvJpcIivjgIB1c2VyZGF0YS5zZWxlY3RlZEZyaWVuZE5hbWUgKyBcIiAgaWQ6XCIrdXNlcmRhdGEuc2VsZWN0ZWRGcmllbmRJRDtcclxuXHJcbiAgICAgICAgLy9zb2tldC5nZXRDaGF0TXNnKCk7Ly/nm5HlkKzojrflj5bogYrlpKnkv6Hmga9cclxuICAgICAgICBpZihzZWxmLmRvSW5pdENoYXRJbmZvID09IHRydWUpe1xyXG4gICAgICAgICAgICBzZWxmLmNoYXRMYWJlbC5zdHJpbmcgPSBzb2tldC5jaGF0RnJpZW5kW3BhcnNlSW50KHVzZXJkYXRhLnNlbGVjdGVkRnJpZW5kSUQpXS5jaGF0RnJpZW5kU3RyaW5nOy8v5pu05paw6IGK5aSp6K6w5b2VXHJcbiAgICAgICAgICAgIHNlbGYuY2hhdENvbnRlbnQuaGVpZ2h0ID0gMjUwICtzb2tldC5jaGF0RnJpZW5kW3BhcnNlSW50KHVzZXJkYXRhLnNlbGVjdGVkRnJpZW5kSUQpXS5jaGF0RnJpZW5kSGVpZ2h0QWRkKjYwOy8v5pu05paw6IGK5aSp5qGG6auY5bqmXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHNlbGYuSW5pdEZyaWVuZCgpO1xyXG4gICAgICAgIHNlbGYuQW5zd2VyRGVsZXRlRnJpZW5kKCk7XHJcbiAgICAgICAgc2VsZi5TaWduU2VsZWN0ZWRGcmllbmQoKTtcclxuICAgICAgICBpZihzb2tldC5pc0luaXRDaGF0ID09IHRydWUpe1xyXG4gICAgICAgICAgICBzZWxmLkluaXRDaGF0SW5mbygpO1xyXG4gICAgICAgICAgIHNva2V0LmlzSW5pdENoYXQgPT0gZmFsc2U7IFxyXG4gICAgICAgIH1cclxuICAgICB9LFxyXG59KTtcclxuIiwidmFyIGh0dHAgPSByZXF1aXJlKFwiSHR0cFV0aWxzXCIpO1xyXG52YXIgY2FyZCA9IHJlcXVpcmUoXCJDYXJkQWN0aXZpdHlcIik7XHJcbnZhciB1c2VyZGF0YSA9IHJlcXVpcmUoXCJVc2VyRGF0YVwiKTtcclxudmFyIHNva2V0ID0gcmVxdWlyZShcIlNva2V0VXRpbHNcIik7XHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvL+eCueWHu+i/lOWbnuWkp+WOheaMiemSrlxyXG4gICAgQmFja1RvSGFsbDpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBodHRwLmlzQmFja1RvSGFsbCA9IHRydWU7XHJcbiAgICAgICAgc29rZXQuY2xvc2Vfd3MoKTtcclxuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJIYWxsU2NlbmVcIik7XHJcbiAgICB9LFxyXG5cclxuICAgIC8v54K55Ye75YaN5p2l5LiA5bGA5oyJ6ZKuXHJcbiAgICBSZU1hdGNoR2FtZTpmdW5jdGlvbigpe1xyXG4gICAgICAgIC8v5YWz6Zet5LiK5LiA5bGA5ri45oiP55qEaHR0cOWSjHNvY2tldCzot7PovazliLDlpKfljoVcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgaHR0cC5pc0JhY2tUb0hhbGwgPSB0cnVlO1xyXG4gICAgICAgIHNva2V0LmNsb3NlX3dzKCk7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiSGFsbFNjZW5lXCIpO1xyXG4gICAgICAgIC8v6ams5LiK5omn6KGM5b+r6YCf5Yy56YWN5a+55omLXHJcbiAgICAgICAgdmFyIGhhbGwgPSBzZWxmLm5vZGUuZ2V0Q29tcG9uZW50KFwiSGFsbFNjZW5lXCIpO1xyXG4gICAgICAgIGhhbGwuRmluZFBsYXllcigpOyAgIFxyXG4gICAgfSxcclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXHJcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xyXG5cclxuICAgIC8vIH0sXHJcbn0pO1xyXG4iLCJ2YXIgaHR0cCA9IHJlcXVpcmUoJ0h0dHBVdGlscycpO1xyXG52YXIgdXNlcmRhdGEgPSByZXF1aXJlKCdVc2VyRGF0YScpO1xyXG52YXIgY2FyZGFjdGl2aXR5PXJlcXVpcmUoJ0NhcmRBY3Rpdml0eScpO1xyXG52YXIgc29rZXQgPSByZXF1aXJlKFwiU29rZXRVdGlsc1wiKTtcclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBcclxuICAgICAgICBob2xkQ2FyZHNfNDp7Ly805Lq65ri45oiP5Y2h54mMXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5Ob2RlXHJcbiAgICAgICAgfSxcclxuICAgICAgICBndWVzczp7Ly/njJzniYzlvLnlh7rmoYZcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLk5vZGVcclxuICAgICAgICB9LFxyXG4gICAgICAgIGd1ZXNzYmc6ey8v54yc54mM5by55Ye65qGG55qE6IOM5pmvXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5Ob2RlICAgXHJcbiAgICAgICAgfSxcclxuICAgICAgICBjb250aW51ZTp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5Ob2RlICAgICAgICAgICAgICAgXHJcbiAgICAgICAgfSxcclxuICAgICAgICBjb250aW51ZWJnOnsvL+aYr+WQpue7p+e7reeMnOeJjOeJjOW8ueWHuuahhueahOiDjOaZr1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZSAgIFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZ3Vlc3NQb2ludERpc3BsYXk6ey8v54yc54mM5by55Ye65qGG5LiK55qE5pi+56S655qE54yc54mM54K55pWwXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5FZGl0Qm94ICAgICAgICAgICAgIFxyXG4gICAgICAgIH0sIFxyXG4gICAgICAgIGluc2VydF9yYW5kb206ey8v5LiH6IO954mM5o+S5YWl5L2N572u5by55Ye65qGGXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5Ob2RlXHJcbiAgICAgICAgfSxcclxuICAgICAgICBpbnNlcnRfcmFuZG9tYmc6ey8v5LiH6IO954mM5o+S5YWl5L2N572u5by55Ye65qGG55qE6IOM5pmvXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5Ob2RlICAgXHJcbiAgICAgICAgfSxcclxuICAgICAgICBpbnNlcnRfcmFuZG9tRGlzcGxheTp7Ly/kuIfog73niYzmj5LlhaXkvY3nva7lvLnlh7rmoYbmmL7npLrnmoTkvY3nva5cclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLkVkaXRCb3ggICAgICAgICAgICAgXHJcbiAgICAgICAgfSwgXHJcbiAgICAgICAgZ2FtZW92ZXI6ey8v5ri45oiP57uT5p2f5by55Ye65qGGXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5Ob2RlLCAgICAgICAgICAgICBcclxuICAgICAgICB9LFxyXG4gICAgICAgIGdhbWVvdmVyYmc6ey8v5ri45oiP57uT5p2f5by55Ye65qGG6IOM5pmvXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5Ob2RlLCAgICAgICAgICAgICBcclxuICAgICAgICB9LFxyXG4gICAgICAgIGdhbWVSZXN1bHREaXNwbGF5OnsvL+a4uOaIj+e7k+adn+W8ueWHuuahhue7k+aenOaYvuekulxyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTGFiZWwsICAgICAgICAgICAgIFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgY2hhdEVkaXQ6ey8v6IGK5aSp6L6T5YWl5L+h5oGv5qGGXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5FZGl0Qm94LCAgICAgICAgICAgICBcclxuICAgICAgICB9LFxyXG4gICAgICAgIGNoYXRDb250ZW50OnsvL+iBiuWkqei+k+WFpeS/oeaBr+mrmOW6plxyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZSxcclxuICAgICAgICB9LCBcclxuICAgICAgICBjaGF0TGFiZWw6ey8v6IGK5aSp5L+h5oGv55qEaXRlbVxyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTGFiZWwsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBuZXdzQ29udGVudDp7Ly/muLjmiI/ljoblj7Lmtojmga/pq5jluqZcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLk5vZGUsXHJcbiAgICAgICAgfSwgXHJcbiAgICAgICAgbmV3c0xhYmVsOnsvL+a4uOaIj+WOhuWPsua2iOaBr+eahGl0ZW1cclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLkxhYmVsLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYmxhY2tDb3VudExhYmVsOnsvL+eJjOaxoOWJqeS9mem7keeJjOaVsOaYvuekulxyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTGFiZWwsXHJcbiAgICAgICAgfSwgXHJcbiAgICAgICAgd2hpdGVDb3VudExhYmVsOnsvL+eJjOaxoOWJqeS9meeZveeJjOaVsOaYvuekulxyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTGFiZWwsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBzdGVwQ291bnRMYWJlbDp7Ly/mraXml7bmmL7npLpcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLkxhYmVsLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgcm91bmRDb3VudExhYmVsOnsvL+WbnuWQiOaVsOaYvuekulxyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTGFiZWwsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBteVR1cm46ey8v5b2T5YmN54yc54mM5Lq65piv5pys5pa5566t5aS0XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5Ob2RlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgcmlnaHRUdXJuOnsvL+W9k+WJjeeMnOeJjOS6uuWPs+aWueeureWktFxyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZSxcclxuICAgICAgICB9LCBcclxuICAgICAgICBvcHBvc2l0ZVR1cm46ey8v5b2T5YmN54yc54mM5Lq65piv5a+56Z2i566t5aS0XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5Ob2RlLFxyXG4gICAgICAgIH0sIFxyXG4gICAgICAgIGxlZnRUdXJuOnsvL+W9k+WJjeeMnOeJjOS6uuaYr+W3puaWueeureWktFxyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHJpZ2h0SW5mbzp7Ly/lj7Pmlrnnjqnlrrbkv6Hmga9cclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLk5vZGUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBvcHBvc2l0ZUluZm86ey8v5a+56Z2i546p5a625L+h5oGvXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5Ob2RlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgbGVmdEluZm86ey8v5bem5pa5546p5a625L+h5oGvXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5Ob2RlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgbmV3c0Rpc3BsYXk6ey8v6aOY6L+H55qE5o+Q56S65L+h5oGvXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5MYWJlbCxcclxuICAgICAgICB9LCBcclxuICAgICAgICBpc1RpbWVPdXQ6bnVsbCwvL+atpeaXtuaYr+WQpuS4ujBcclxuICAgICAgICBzdGVwQ291bnQ6MjAsLy/mraXml7borqHmlbAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICBwbGF5ZXJzTnVtOm51bGwsLy/njqnlrrbmlbDph49cclxuICAgICAgICBteUNhcmRzOm51bGwsLy/lrZjlgqjmnKzmlrnmiYvniYzmlbDnu4RcclxuICAgICAgICByaWdodENhcmRzOm51bGwsLy/lrZjlgqjlj7PmlrnmiYvniYzmlbDnu4RcclxuICAgICAgICBvcHBvc2l0ZUNhcmRzOm51bGwsLy/lrZjlgqjlr7nmlrnmiYvniYzmlbDnu4RcclxuICAgICAgICBsZWZ0Q2FyZHM6bnVsbCwvL+WtmOWCqOW3puaWueaJi+eJjOaVsOe7hFxyXG4gICAgICAgIHVybDpudWxsLC8v5pyN5Yqh5ZmoaXDlnLDlnYBcclxuICAgICAgICBndWVzc19zdWl0Om51bGwsLy/miYDnjJzniYznmoTpopzoibJcclxuICAgICAgICBndWVzc19wb3NpOm51bGwsLy/miYDnjJzniYznmoTkvY3nva5cclxuICAgICAgICBndWVzc19wb2ludDpudWxsLC8v5omA54yc55qE54K55pWwXHJcbiAgICAgICAgaXNlcG9sbDpudWxsLC8v55So5p2l5Yaz5a6a5piv5ZCm6L2u6K+iXHJcbiAgICAgICAgbXlIb2xkczpudWxsLC8v6Ieq5bex5omL54mM6IqC54K5XHJcbiAgICAgICAgcmlnaHRIb2xkczpudWxsLC8v5Y+z5pa55omL54mM6IqC54K5XHJcbiAgICAgICAgb3Bwb3NpdGVIb2xkczpudWxsLC8v5a+56Z2i5omL54mM6IqC54K5XHJcbiAgICAgICAgbGVmdEhvbGRzOm51bGwsLy/lt6bmlrnmiYvniYzoioLngrlcclxuICAgICAgICByYW5kb21fcG9pbnQ6bnVsbCwvL+WBh+WumueahOS4h+iDveeJjOeCueaVsFxyXG4gICAgICAgIHJhbmRvbV9zdWl0Om51bGwsIC8v5LiH6IO954mM6aKc6ImyXHJcbiAgICAgICAgbmV3c0hpc3RvcnlBZGQ6MCwvL+a2iOaBr+WOhuWPsuWinuWKoFxyXG4gICAgICAgIG5ld3NIaXN0b3J5Olwi5raI5oGv5Y6G5Y+y5aaC5LiL77yaXCIsXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKXtcclxuICAgICAgICB2YXIgc2VsZj10aGlzO1xyXG4gICAgICAgIHNlbGYudXJsPVwiaHR0cDovLzE5Mi4xNjguMC4yMjk6ODA4MC90ZXN0XCI7XHJcbiAgICAgICAgc2VsZi5PbmxpbmVFcG9sbCgpO1xyXG4gICAgICAgIHNlbGYubXlDYXJkcz1bXTtcclxuICAgICAgICBzZWxmLnJpZ2h0Q2FyZHM9W107XHJcbiAgICAgICAgc2VsZi5vcHBvc2l0ZUNhcmRzPVtdO1xyXG4gICAgICAgIHNlbGYubGVmdENhcmRzPVtdO1xyXG4gICAgICAgIHNlbGYuYm9vbDE9ZmFsc2U7XHJcbiAgICAgICAgc2VsZi5ib29sMj1mYWxzZTtcclxuICAgICAgICBzZWxmLm5ld3NEaXNwbGF5LmdldENvbXBvbmVudChjYy5BbmltYXRpb24pLnBsYXkoJ25ld3NGbG93Jyk7Ly/mj5DnpLrkv6Hmga/po5jov4cuLi5cclxuICAgICAgICB1c2VyZGF0YS5ndWVzc2VkY2FyZD1uZXcgTWFwKCk7XHJcbiAgICAgICAgLy8gc2VsZi5ob2xkQ2FyZHNfMi5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAvLyBzZWxmLmhvbGRDYXJkc18zLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIHNlbGYuaG9sZENhcmRzXzQuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgc2VsZi5wbGF5ZXJzTnVtID0gNDsvL+m7mOiupDTkurrmuLjmiI9cclxuICAgICAgICBpZihzZWxmLnBsYXllcnNOdW0gPT0gNCl7XHJcbiAgICAgICAgICAgIHNlbGYuaG9sZENhcmRzXzQuYWN0aXZlID0gdHJ1ZTsvLzTkurrmiYvniYzlh7rnjrBcclxuICAgICAgICAgICAgc2VsZi5yaWdodEluZm8uYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgc2VsZi5vcHBvc2l0ZUluZm8uYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgc2VsZi5sZWZ0SW5mby5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICBzZWxmLmluc2VydF9yYW5kb20uYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHVzZXJkYXRhLnJvdW5kID0gMTtcclxuICAgICAgICAgICAgc2VsZi5PbmxpbmVDaGF0KCk7XHJcbiAgICAgICAgICAgIHRoaXMuSW5pdFZpZXcoKTsvL+WIneWni+WMluWcuuaZr1xyXG4gICAgICAgICAgICB0aGlzLkluaXRDYXJkcygpOy8vNOS6uua4uOaIj+W8gOWni++8jOWPkeeJjFxyXG4gICAgICAgICAgICB0aGlzLkRlYWxDYXJkcygpOy8vNOS6uua4uOaIj+W8gOWni++8jOaRuOeJjFxyXG4gICAgICAgICAgICB1c2VyZGF0YS5yZXN0Y2FyZCA9IHRydWU7Ly/pu5jorqTniYzloIbmnInniYxcclxuICAgICAgICAgICAgdXNlcmRhdGEuY2FyZHNBcmVOdWxsID0gMDtcclxuICAgICAgICAgICAgc2VsZi5ibGFja0NvdW50TGFiZWwuc3RyaW5nID0gdXNlcmRhdGEucmVzdEJsYWNrQ291bnQgKyBcIuW8oFwiOy8v5Yid5aeL5YyW54mM5rGg5Ymp5L2Z54mM5pWw6YePXHJcbiAgICAgICAgICAgIHNlbGYud2hpdGVDb3VudExhYmVsLnN0cmluZyA9IHVzZXJkYXRhLnJlc3RXaGl0ZUNvdW50ICsgXCLlvKBcIjtcclxuICAgICAgICAgICAgLy/mraXml7blgJLorqHml7ZcclxuICAgICAgICAgICAgc2VsZi5VcGRhdGVMZWZ0VGltZSgpO1xyXG4gICAgICAgICAgICBodHRwLmlzQmFja1RvSGFsbCA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBzZWxmLmlzZXBvbGw9ZmFsc2U7XHJcbiAgICAgICAgaWYodXNlcmRhdGEuZnRwbGF5ZXI9PT11c2VyZGF0YS5tc2VhdCl7Ly/liJ3lp4vnu5Pmnpzova7or6LvvIzlpoLmnpzmnKzmlrnmmK/mkbjniYzmlrnot7Pov4fova7or6JcclxuICAgICAgICAgICAgICAgICAgICBzZWxmLmlzZXBvbGw9ZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICAgICAgICBzZWxmLmlzZXBvbGw9dHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICBzZWxmLlJlc3VsdEVwb2xsKHNlbGYuaXNlcG9sbCk7XHJcbiAgICB9LFxyXG4gICAgLy/lnKjnur/ogYrlpKnor7fmsYJcclxuICAgIE9ubGluZUNoYXQ6ZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgIGFza0NoYXQgPSBKU09OLnN0cmluZ2lmeSh7SWQ6dXNlcmRhdGEuaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVHlwZToxMDA0MCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBNc2VhdDp1c2VyZGF0YS5tc2VhdCwvL+WKoOS4gOS4quiHquW3seeahOW6p+S9jeWPt1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5hbWU6XCI2NjZcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBLZXk6dXNlcmRhdGEuY2hhdFJvb21LZXl9KTtcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCLlkJHogYrlpKnmnI3liqHlmajlj5HpgIHor7fmsYJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKEpTT04ucGFyc2UoYXNrQ2hhdCkpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNva2V0LmNvbm5lY3QoKTsvL+W7uueri3dlYnNva2V05a+56LGhd3NcclxuICAgICAgICAgICAgICAgICAgICBzb2tldC53cy5vbm9wZW4gPSBmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICAgICAgICAgIHNva2V0LmdldENoYXRNc2coKTtcclxuICAgICAgICAgICAgICAgICAgICBzb2tldC53cy5zZW5kKGFza0NoYXQpOy8v5Y+R6YCB5raI5oGvXHJcbiAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgIH0sXHJcbiAgICAvL+eCueWHu+WPkemAgeiBiuWkqeaMiemSrlxyXG4gICAgc2VuZENoYXRTdHJpbmc6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIGNjLmxvZyhcIuaDs+WPkemAgeeahOa2iOaBr++8mlwiK3NlbGYuY2hhdEVkaXQuc3RyaW5nKTtcclxuICAgICAgICB2YXIgIGNoYXRDb250ZW50ID0gSlNPTi5zdHJpbmdpZnkoe0lkOnVzZXJkYXRhLmlkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVHlwZToxMDA0NSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5hbWU6XCI2NjZcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEtleTp1c2VyZGF0YS5jaGF0Um9vbUtleSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRleHQ6c2VsZi5jaGF0RWRpdC5zdHJpbmdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTsgICAgICBcclxuICAgICAgICBzb2tldC5nZXRDaGF0TXNnKCk7XHJcbiAgICAgICAgaWYoc2VsZi5jaGF0RWRpdC5zdHJpbmchPVwiXCIpey8v5Y+R6YCB5raI5oGv5LiN5Li656m65pe2XHJcbiAgICAgICAgY2MubG9nKFwi5ZCR6IGK5aSp5pyN5Yqh5Zmo5Y+R6YCB6IGK5aSp5raI5oGv77yaXCIpO1xyXG4gICAgICAgIGNjLmxvZyhKU09OLnBhcnNlKGNoYXRDb250ZW50KSk7XHJcbiAgICAgICAgc29rZXQud3Muc2VuZChjaGF0Q29udGVudCk7Ly/lj5HpgIHmtojmga9cclxuICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgc2VsZi5jaGF0RWRpdC5zdHJpbmcgPSBcIui+k+WFpea2iOaBr+S4jeiDveS4uuepuu+8gVwiO1xyXG4gICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgc2VsZi5jaGF0RWRpdC5zdHJpbmcgPVwiXCI7XHJcbiAgICAgICAgICAgIH0sIDEwMDApO1xyXG4gICAgICAgIH1cclxuICAgICAgICBzZWxmLmNoYXRFZGl0LlBsYWNlaG9sZGVyID0gXCLlnKjmraTovpPlhaXogYrlpKnkv6Hmga8uLi4uLi4uXCI7XHJcbiAgICB9LFxyXG4gICAgLy/lnKjnur/ova7or6JcclxuICAgIE9ubGluZUVwb2xsOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGY9dGhpcztcclxuICAgICAgICB2YXIgb25saW5lX3NkbWVzPUpTT04uc3RyaW5naWZ5KHtJZDp1c2VyZGF0YS5pZCxcclxuICAgICAgICAgICAgICAgICAgICBcIkNvbnRlbnRcIjp7XCJUeXBlXCI6MTAwMTh9fSk7XHJcbiAgICAgICAgdmFyIGNvbnRlbnQ9XCJtc2c9XCIrb25saW5lX3NkbWVzO1xyXG4gICAgICAgIGh0dHAuSHR0cFBvc3Qoc2VsZi51cmwsY29udGVudCxmdW5jdGlvbihvbmxpbmVfcnZtZXMpe1xyXG4gICAgICAgICAgICBpZiAob25saW5lX3J2bWVzID09PSAtMSkge1xyXG4gICAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcIuivt+ajgOafpee9kee7nFwiKTtcclxuICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICB2YXIgcnY9SlNPTi5wYXJzZShvbmxpbmVfcnZtZXMpO1xyXG4gICAgICAgICAgICAgICAgaWYocnYuVHlwZT09PTEwMDIwKXtcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCJvbmxpbmVcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxmLk9ubGluZUVwb2xsKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfSwxNTAwMCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgfSxcclxuXHJcbiAgICAvL+mdnueMnOeJjOaWueaJp+ihjOi9ruivoue7k+aenFxyXG4gICAgUmVzdWx0RXBvbGw6ZnVuY3Rpb24oZSl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIGlmKGUpe1xyXG4gICAgICAgICAgICB2YXIgY29udGVudCA9IEpTT04uc3RyaW5naWZ5KHtUeXBlOjEwMDI1LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBSb3VuZDp1c2VyZGF0YS5yb3VuZFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgY29udGVudCA9IEpTT04ucGFyc2UoY29udGVudCk7XHJcbiAgICAgICAgICAgIHZhciByZXN1bHRfc2RtZXM9SlNPTi5zdHJpbmdpZnkoe0lkOnVzZXJkYXRhLmlkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDb250ZW50OmNvbnRlbnRcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHZhciBjb250ZW50PVwibXNnPVwiK3Jlc3VsdF9zZG1lcztcclxuICAgICAgICAgICAgaHR0cC5IdHRwUG9zdChzZWxmLnVybCxjb250ZW50LGZ1bmN0aW9uKHJlc3VsdF9tZXMpe1xyXG4gICAgICAgICAgICAgICAgdmFyIHJlc3VsdF9ydm1lcz1KU09OLnBhcnNlKHJlc3VsdF9tZXMpO1xyXG4gICAgICAgICAgICAgICAgLy9jYy5sb2cocmVzdWx0X3J2bWVzKTtcclxuICAgICAgICAgICAgICAgIGlmKHJlc3VsdF9ydm1lcy5UeXBlID09PSAxMDAyNCl7Ly/mnKrov5Tlm57njJzniYzkv6Hmga9cclxuICAgICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIuacqui/lOWbnueMnOeJjOS/oeaBr1wiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5SZXN1bHRFcG9sbChlKTtcclxuICAgICAgICAgICAgICAgICAgICB9LDIwMDApO1xyXG4gICAgICAgICAgICAgICAgfWVsc2UgaWYocmVzdWx0X3J2bWVzLlR5cGUgPT09IDEwMDIzKXsvL+i/lOWbnueMnOeJjOS/oeaBr1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwi5pS25YiwMTAwMjNcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICBjYy5sb2cocmVzdWx0X3J2bWVzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJkYXRhLnJvdW5kICs9MTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYucm91bmRDb3VudExhYmVsLnN0cmluZyA9IHVzZXJkYXRhLnJvdW5kO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgY2FyZGFjdGl2aXR5Lkd1ZXNzUmVzdWx0KHJlc3VsdF9ydm1lcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLkNoYW5nZVJhbmRvbVBvc2kocmVzdWx0X3J2bWVzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgIGlmKHVzZXJkYXRhLmZ0cGxheWVyID09PSByZXN1bHRfcnZtZXMuR3Vlc3NTZWF0KXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmKHJlc3VsdF9ydm1lcy5SZXN1bHQ9PXRydWUpey8v6L+U5Zue54yc54mM5L+h5oGvLOS4lOeMnOWvuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwi6L+U5Zue54yc54mM5L+h5oGvLOS4lOeMnOWvuVwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmKHJlc3VsdF9ydm1lcy5HdWVzc0NhcmQuQ2FyZFBvaW50PT0xMil7Ly/kuIrmlrnpo5jov4fnmoTmj5DnpLrmtojmga9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLm5ld3NEaXNwbGF5LnN0cmluZyA9IFwi546p5a62XCIrc2VsZi5nZXROYW1lQnlTZWF0KHVzZXJkYXRhLm1zZWF0KStcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCLnjJznjqnlrrZcIitzZWxmLmdldE5hbWVCeVNlYXQodXNlcmRhdGEuZ3Vlc3NlZG1hbikrXCLnmoTnrKxcIitcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXNlcmRhdGEuZ3Vlc3NlZGNhcmQucG9zaStcIuW8oOeJjOS4uuS4h+iDveeJjO+8jOeMnOmUmeS6hlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5uZXdzRGlzcGxheS5zdHJpbmcgPSBcIueOqeWutlwiK3NlbGYuZ2V0TmFtZUJ5U2VhdCh1c2VyZGF0YS5tc2VhdCkrXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCLnjJznjqnlrrZcIitzZWxmLmdldE5hbWVCeVNlYXQodXNlcmRhdGEuZ3Vlc3NlZG1hbikrXCLnmoTnrKxcIitcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXNlcmRhdGEuZ3Vlc3NlZGNhcmQucG9zaStcIuW8oOeJjOS4ulwiK3Jlc3VsdF9ydm1lcy5HdWVzc0NhcmQuQ2FyZFBvaW50K1wi54K577yM54yc5a+55LqGXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5uZXdzSGlzdG9yeSA9IHNlbGYubmV3c0hpc3RvcnkgKyBcIlxcblwiICsgXCLnrKxcIisodXNlcmRhdGEucm91bmQtMSkrXCLlm57lkIjvvJpcIitzZWxmLm5ld3NEaXNwbGF5LnN0cmluZztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYubmV3c0hpc3RvcnlBZGQrPTE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLm5ld3NEaXNwbGF5LmdldENvbXBvbmVudChjYy5BbmltYXRpb24pLnBsYXkoJ25ld3NGbG93Jyk7Ly/mj5DnpLrkv6Hmga/po5jov4cuLi4gICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5NaW5nQnJhbmcodXNlcmRhdGEuZ3Vlc3NlZG1hbix1c2VyZGF0YS5ndWVzc2VkY2FyZCx1c2VyZGF0YS5ndWVzc2VkY2FyZC5wb3NpKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuUm91bmRDaGFuZ2UoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1lbHNlIGlmKHJlc3VsdF9ydm1lcy5SZXN1bHQ9PWZhbHNlKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy/ov5Tlm57njJzniYzkv6Hmga8s5LiU54yc6ZSZIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZihyZXN1bHRfcnZtZXMuVGltZU91dCA9PSBmYWxzZSl7Ly/mnKrotoXml7bnjJzplJlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwi6L+U5Zue54yc54mM5L+h5oGvLOS4lOeMnOmUmVwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmKHJlc3VsdF9ydm1lcy5HdWVzc0NhcmQuQ2FyZFBvaW50PT0xMil7Ly/kuIrmlrnpo5jov4fnmoTmj5DnpLrmtojmga9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLm5ld3NEaXNwbGF5LnN0cmluZyA9IFwi546p5a62XCIrc2VsZi5nZXROYW1lQnlTZWF0KHVzZXJkYXRhLm1zZWF0KStcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCLnjJznjqnlrrZcIitzZWxmLmdldE5hbWVCeVNlYXQodXNlcmRhdGEuZ3Vlc3NlZG1hbikrXCLnmoTnrKxcIitcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXNlcmRhdGEuZ3Vlc3NlZGNhcmQucG9zaStcIuW8oOeJjOS4uuS4h+iDveeJjO+8jOeMnOmUmeS6hlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5uZXdzRGlzcGxheS5zdHJpbmcgPSBcIueOqeWutlwiK3NlbGYuZ2V0TmFtZUJ5U2VhdCh1c2VyZGF0YS5tc2VhdCkrXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCLnjJznjqnlrrZcIitzZWxmLmdldE5hbWVCeVNlYXQodXNlcmRhdGEuZ3Vlc3NlZG1hbikrXCLnmoTnrKxcIitcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXNlcmRhdGEuZ3Vlc3NlZGNhcmQucG9zaStcIuW8oOeJjOS4ulwiK3Jlc3VsdF9ydm1lcy5HdWVzc0NhcmQuQ2FyZFBvaW50K1wi54K577yM54yc6ZSZ5LqGXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYubmV3c0hpc3RvcnkgPSBzZWxmLm5ld3NIaXN0b3J5ICsgXCJcXG5cIiArIFwi56ysXCIrKHVzZXJkYXRhLnJvdW5kLTEpK1wi5Zue5ZCI77yaXCIrc2VsZi5uZXdzRGlzcGxheS5zdHJpbmc7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYubmV3c0hpc3RvcnlBZGQrPTE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYubmV3c0Rpc3BsYXkuZ2V0Q29tcG9uZW50KGNjLkFuaW1hdGlvbikucGxheSgnbmV3c0Zsb3cnKTsvL+aPkOekuuS/oeaBr+mjmOi/hy4uLiAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZih1c2VyZGF0YS5yZXN0Y2FyZCl7Ly/lpoLmnpzniYzloIbmnInniYxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNjLmxvZyh1c2VyZGF0YS50Y2FyZCk7ICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLk1pbmdCcmFuZyh1c2VyZGF0YS5mdHBsYXllcix1c2VyZGF0YS50Y2FyZCxzZWxmLm15SG9sZHMuY2hpbGRyZW4ubGVuZ3RoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5Sb3VuZENoYW5nZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9ZWxzZSBpZihyZXN1bHRfcnZtZXMuVGltZU91dCA9PSB0cnVlKXsvL+i2heaXtlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwi54yc54mM5Lq66LaF5pe277yB77yB77yBXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5uZXdzRGlzcGxheS5zdHJpbmcgPSBcIueOqeWutlwiK3NlbGYuZ2V0TmFtZUJ5U2VhdCh1c2VyZGF0YS5mdHBsYXllcikrXCLnjJzniYzotoXml7ZcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYubmV3c0hpc3RvcnkgPSBzZWxmLm5ld3NIaXN0b3J5ICsgXCJcXG5cIiArIFwi56ysXCIrKHVzZXJkYXRhLnJvdW5kLTEpK1wi5Zue5ZCI77yaXCIrc2VsZi5uZXdzRGlzcGxheS5zdHJpbmc7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLm5ld3NIaXN0b3J5QWRkKz0xO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5uZXdzRGlzcGxheS5nZXRDb21wb25lbnQoY2MuQW5pbWF0aW9uKS5wbGF5KCduZXdzRmxvdycpOy8v5o+Q56S65L+h5oGv6aOY6L+HLi4uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZih1c2VyZGF0YS5yZXN0Y2FyZCl7Ly/lpoLmnpzniYzloIbmnInniYxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLk1pbmdCcmFuZyh1c2VyZGF0YS5mdHBsYXllcix1c2VyZGF0YS50Y2FyZCxzZWxmLm15SG9sZHMuY2hpbGRyZW4ubGVuZ3RoKTsgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuUm91bmRDaGFuZ2UoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgIH1lbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYy5sb2coMTExMjIyMzMzNDQ0NCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5SZXN1bHRFcG9sbChlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sMjAwMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9ZWxzZSBpZihyZXN1bHRfcnZtZXMuVHlwZSA9PT0gMTAwMzUpe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwi5Ye6546w6IOc5Yip6ICFXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgaWYodXNlcmRhdGEucmVzdGNhcmQhPSBmYWxzZSAmJiB1c2VyZGF0YS5jYXJkc0FyZU51bGwhPTEpe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FyZGFjdGl2aXR5Lk92ZXIocmVzdWx0X3J2bWVzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuSW5zZXJ0Q2FyZHMoKTsgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhcmRhY3Rpdml0eS5JbnNlcnRfY2FyZCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LCA1MDApOyAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5VcGRhdGVDYXJkc0luZm8oKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuR2FtZU92ZXIocmVzdWx0X3J2bWVzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSwyMDAxKTsgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FyZGFjdGl2aXR5Lk92ZXIocmVzdWx0X3J2bWVzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuR2FtZU92ZXIocmVzdWx0X3J2bWVzKTsvL+eJjOWghumHjOeahOeJjOWPkeWujOS6huaXtuWHuueOsOiDnOWIqeiAhSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvL+WbnuWQiOWIh+aNolxyXG4gICAgUm91bmRDaGFuZ2U6ZnVuY3Rpb24oKXtcclxuICAgICAgICBjYy5sb2coXCJSb3VuZENoYW5nZeaJp+ihjFwiKTtcclxuICAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHZhciByb3VuZF9zZG1lcz1KU09OLnN0cmluZ2lmeSh7SWQ6dXNlcmRhdGEuaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJDb250ZW50XCI6e1wiVHlwZVwiOjEwMDI4fX0pO1xyXG4gICAgICAgIHZhciBjb250ZW50PVwibXNnPVwiK3JvdW5kX3NkbWVzO1xyXG4gICAgICAgIGh0dHAuSHR0cFBvc3Qoc2VsZi51cmwsY29udGVudCxmdW5jdGlvbihyb3VuZF9tZXMpe1xyXG4gICAgICAgICAgICBpZiAocm91bmRfbWVzID09IC0xKSB7XHJcbiAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgdmFyIHJvdW5kX3J2bWVzID0gSlNPTi5wYXJzZShyb3VuZF9tZXMpO1xyXG4gICAgICAgICAgICAgICAgY2MubG9nKFwi5Zue5ZCI5YiH5o2i6L2u6K+i5o6l5Y+X5L+h5oGv5aaC5LiL77yaXCIpO1xyXG4gICAgICAgICAgICAgICAgY2MubG9nKHJvdW5kX3J2bWVzKTtcclxuICAgICAgICAgICAgICAgIHN3aXRjaChyb3VuZF9ydm1lcy5UeXBlKXtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDEwMDI5OlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCLnjJzniYzmlrnnu6fnu63njJzniYznu6fnu63ova7or6Lnu5PmnpxcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLnN0ZXBDb3VudCA9IDIxO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5SZXN1bHRFcG9sbChzZWxmLmlzZXBvbGwpOy8v54yc54mM5pa557un57ut54yc54mM57un57ut6L2u6K+i57uT5p6cXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sMTAwMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDEwMDMwOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYy5sb2coMjIyMjIyKTsgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmKHJvdW5kX3J2bWVzLlRjYXJkIT1udWxsKXsvL+WmguaenOeJjOWghuS4jeS4uuepulxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLkluc2VydENhcmRzKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FyZGFjdGl2aXR5Lkluc2VydF9jYXJkKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sIDUwMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJkYXRhLnJlc3RjYXJkID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyZGF0YS5jYXJkc0FyZU51bGwgKz0gMTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZihyb3VuZF9ydm1lcy5UY2FyZD09bnVsbCYmdXNlcmRhdGEuY2FyZHNBcmVOdWxsPT0xKXsvL+WmguaenOeJjOWghuS4uuepuuS4lOWImuWlveS4uuepuu+8iOeUqOadpeWwhuacgOWQjuS4gOW8oOaRuOeahOeJjOaPkuWFpeaJi+eJjO+8iVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5JbnNlcnRDYXJkcygpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FyZGFjdGl2aXR5Lkluc2VydF9jYXJkKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sIDUwMCk7IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCl7IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5VcGRhdGVDYXJkc0luZm8oKTtcclxuaWYodXNlcmRhdGEubXNlYXQgPT09IHVzZXJkYXRhLmZ0cGxheWVyKXtcclxuICAgICAgICAgICAgZm9yKHZhciBpPTA7aTx1c2VyZGF0YS5tY2FyZC5zaXplOysraSl7XHJcbiAgICAgICAgICAgICAgICBjYy5sb2coKGkrMSkrXCIucG9zaXRpb249XCIrc2VsZi5teUNhcmRzW2ldLnBvc2krXCIsXCIrKGkrMSkrXCIucG9pbnQ9XCIrc2VsZi5teUNhcmRzW2ldLnBvaW50K1wiLFwiKyhpKzEpK1wiLmNvbG9yPVwiK3NlbGYubXlDYXJkc1tpXS5zdWl0KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1lbHNlIGlmKHVzZXJkYXRhLnJzZWF0ID09PSB1c2VyZGF0YS5mdHBsYXllcil7ICBcclxuICAgICAgICAgICAgZm9yKHZhciBpPTA7aTx1c2VyZGF0YS5yY2FyZC5zaXplOysraSl7XHJcbiAgICAgICAgICAgICAgICAgY2MubG9nKChpKzEpK1wiLnBvc2l0aW9uPVwiK3NlbGYucmlnaHRDYXJkc1tpXS5wb3NpK1wiLFwiKyhpKzEpK1wiLnBvaW50PVwiK3NlbGYucmlnaHRDYXJkc1tpXS5wb2ludCtcIixcIisoaSsxKStcIi5jb2xvcj1cIitzZWxmLnJpZ2h0Q2FyZHNbaV0uc3VpdCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9ZWxzZSBpZih1c2VyZGF0YS5vc2VhdCA9PT0gdXNlcmRhdGEuZnRwbGF5ZXIpeyAgICAgIFxyXG4gICAgICAgICAgICBmb3IodmFyIGk9MDtpPHVzZXJkYXRhLm9jYXJkLnNpemU7KytpKXtcclxuICAgICAgICAgICAgICAgICBjYy5sb2coKGkrMSkrXCIucG9zaXRpb249XCIrc2VsZi5vcHBvc2l0ZUNhcmRzW2ldLnBvc2krXCIsXCIrKGkrMSkrXCIucG9pbnQ9XCIrc2VsZi5vcHBvc2l0ZUNhcmRzW2ldLnBvaW50K1wiLFwiKyhpKzEpK1wiLmNvbG9yPVwiK3NlbGYub3Bwb3NpdGVDYXJkc1tpXS5zdWl0KTsgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfWVsc2UgaWYodXNlcmRhdGEubHNlYXQgPT09IHVzZXJkYXRhLmZ0cGxheWVyKXsgICAgICAgICAgICBcclxuICAgICAgICAgICAgZm9yKHZhciBpPTA7aTx1c2VyZGF0YS5sY2FyZC5zaXplOysraSl7XHJcbiAgICAgICAgICAgICAgICAgY2MubG9nKChpKzEpK1wiLnBvc2l0aW9uPVwiK3NlbGYubGVmdENhcmRzW2ldLnBvc2krXCIsXCIrKGkrMSkrXCIucG9pbnQ9XCIrc2VsZi5sZWZ0Q2FyZHNbaV0ucG9pbnQrXCIsXCIrKGkrMSkrXCIuY29sb3I9XCIrc2VsZi5sZWZ0Q2FyZHNbaV0uc3VpdCk7ICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyZGF0YS5mdHBsYXllcj1yb3VuZF9ydm1lcy5Ub3VjaHA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmKHJvdW5kX3J2bWVzLlRjYXJkIT1udWxsKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FyZGFjdGl2aXR5LlRjYXJkKHJvdW5kX3J2bWVzLlRjYXJkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5EZWFsQ2FyZHMoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5ibGFja0NvdW50TGFiZWwuc3RyaW5nID0gcm91bmRfcnZtZXMuUmVzdENhcmQuYmxhY2sgKyBcIuW8oFwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLndoaXRlQ291bnRMYWJlbC5zdHJpbmcgPSByb3VuZF9ydm1lcy5SZXN0Q2FyZC53aGl0ZSArIFwi5bygXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuc3RlcENvdW50ID0gMjE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZih1c2VyZGF0YS5mdHBsYXllcj09PXVzZXJkYXRhLm1zZWF0KXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLmlzZXBvbGw9ZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLmlzZXBvbGw9dHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCLkuI3mmK/njJzniYzmlrnlsIbnu6fnu63ova7or6Lnu5PmnpzvvJvmmK/njJzniYzmlrnml7blsIblpLHmlYhcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5SZXN1bHRFcG9sbChzZWxmLmlzZXBvbGwpOy8v5LiN5piv54yc54mM5pa55bCG57un57ut6L2u6K+i57uT5p6c77yb5piv54yc54mM5pa55pe25bCG5aSx5pWIXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LDMwMDApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LCAyMDAwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMTAwMzE6ICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuUm91bmRDaGFuZ2UoKTsvL+S4jeaYr+eMnOeJjOaWueWwhue7p+e7rei9ruivoue7k+aenO+8m+aYr+eMnOeJjOaWueaXtuWwhuWkseaViFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LDUwMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrOyAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH0sXHJcblxyXG4gICAgLy/liJ3lp4vljJblnLrmma9cclxuICAgIEluaXRWaWV3OmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIC8v5pCc57Si6ZyA6KaB55qE5a2Q6IqC54K5XHJcbiAgICAgICAgdmFyIGhvbGRDYXJkc0NoaWxkID0gc2VsZi5ub2RlLmdldENoaWxkQnlOYW1lKFwibnVtXzRcIik7XHJcbiAgICAgICAgc2VsZi5teUhvbGRzID0gaG9sZENhcmRzQ2hpbGQuZ2V0Q2hpbGRCeU5hbWUoXCJwbGF5ZXIxX2NhcmRzXCIpOy8v6Ieq5bex55qE5omL54mMXHJcbiAgICAgICAgc2VsZi5yaWdodEhvbGRzID0gaG9sZENhcmRzQ2hpbGQuZ2V0Q2hpbGRCeU5hbWUoXCJwbGF5ZXIyX2NhcmRzXCIpOy8v5Y+z6L6555qE5omL54mMXHJcbiAgICAgICAgc2VsZi5vcHBvc2l0ZUhvbGRzID0gaG9sZENhcmRzQ2hpbGQuZ2V0Q2hpbGRCeU5hbWUoXCJwbGF5ZXIzX2NhcmRzXCIpOy8v5a+56Z2i55qE5omL54mMXHJcbiAgICAgICAgc2VsZi5sZWZ0SG9sZHMgPSBob2xkQ2FyZHNDaGlsZC5nZXRDaGlsZEJ5TmFtZShcInBsYXllcjRfY2FyZHNcIik7Ly/lt6bovrnnmoTmiYvniYxcclxuICAgICAgICBcclxuICAgICAgICBmb3IodmFyIGkgPSAwOyBpIDwgc2VsZi5teUhvbGRzLmNoaWxkcmVuLmxlbmd0aDsgKytpKXtcclxuICAgICAgICAgICAgc2VsZi5teUhvbGRzLmNoaWxkcmVuW2ldLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IodmFyIGkgPSAwOyBpIDwgc2VsZi5yaWdodEhvbGRzLmNoaWxkcmVuLmxlbmd0aDsgKytpKXtcclxuICAgICAgICAgICAgc2VsZi5yaWdodEhvbGRzLmNoaWxkcmVuW2ldLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IodmFyIGkgPSAwOyBpIDwgc2VsZi5vcHBvc2l0ZUhvbGRzLmNoaWxkcmVuLmxlbmd0aDsgKytpKXtcclxuICAgICAgICAgICAgc2VsZi5vcHBvc2l0ZUhvbGRzLmNoaWxkcmVuW2ldLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IodmFyIGkgPSAwOyBpIDwgc2VsZi5sZWZ0SG9sZHMuY2hpbGRyZW4ubGVuZ3RoOyArK2kpe1xyXG4gICAgICAgICAgICBzZWxmLmxlZnRIb2xkcy5jaGlsZHJlbltpXS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbigpIHtcclxuICAgICAgICAgICBzZWxmLlNob3dQbGF5ZXJJbmZvKCk7Ly/mmL7npLrnjqnlrrbkv6Hmga8gXHJcbiAgICAgICAgfSwgMjAwMCk7ICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIC8vNOS6uua4uOaIj+W8gOWni++8jOWPkeeJjFxyXG4gICAgSW5pdENhcmRzOmZ1bmN0aW9uKCkge1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICAvL+ehruWumueMnOeJjOS6uuS9jee9rlxyXG4gICAgICAgIHNlbGYuR3Vlc3NUdXJuKCk7ICAgXHJcbiAgICAgICAgLy/lj5Hoh6rlt7HnmoTniYzvvIzlvIDlp4vlj6rmnIkz5byg54mMXHJcbiAgICAgICAgZm9yKHZhciBpID0gMDtpIDwgMzsgaSsrKXtcclxuICAgICAgICAgICAgIHNlbGYubXlIb2xkcy5jaGlsZHJlbltpXS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgdmFyIHNwcml0ZSA9IHNlbGYubXlIb2xkcy5jaGlsZHJlbltpXS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcclxuICAgICAgICAgICAgIHNlbGYuU2V0U3ByaXRlRnJhbWVCeUNhcmRJRChcIk1fXCIsdXNlcmRhdGEubWNhcmQuZ2V0KGkpLnN1aXQsdXNlcmRhdGEubWNhcmQuZ2V0KGkpLnBvaW50LHNwcml0ZSk7Ly/miJHmlrnnmoTniYzlpoLlrp7mmL7npLpcclxuICAgICAgICAgICAgIHNlbGYuU2V0Q2FyZHNJbmZvKHNlbGYubXlDYXJkcyxpLHVzZXJkYXRhLm1jYXJkLmdldChpKSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgXHJcbiAgICAgICAgLy/lj5Hlj7PovrnnmoTniYzvvIzlvIDlp4vlj6rmnIkz5byg54mMXHJcbiAgICAgICAgZm9yKHZhciBpID0gMDtpIDwgMzsgaSsrKXtcclxuICAgICAgICAgICAgIHNlbGYucmlnaHRIb2xkcy5jaGlsZHJlbltpXS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgdmFyIHNwcml0ZSA9IHNlbGYucmlnaHRIb2xkcy5jaGlsZHJlbltpXS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcclxuICAgICAgICAgICAgIHNlbGYuU2V0U3ByaXRlRnJhbWVCeUNhcmRJRChcIlJfXCIsdXNlcmRhdGEucmNhcmQuZ2V0KGkpLnN1aXQsMTMsc3ByaXRlKTsgLy/lj7PovrnnmoTniYzmmL7npLrkuLrmnKrnn6XnmoRcclxuICAgICAgICAgICAgIHNlbGYuU2V0Q2FyZHNJbmZvKHNlbGYucmlnaHRDYXJkcyxpLHVzZXJkYXRhLnJjYXJkLmdldChpKSk7Ly/lrZjlgqjlj7PovrnljaHniYzkv6Hmga9cclxuICAgICAgICAgICAgIHNlbGYuR3Vlc3NDYXJkcyhzcHJpdGUubm9kZSk7Ly/njJzlj7PovrnnmoTniYxcclxuICAgICAgICB9ICAgXHJcbiAgICAgICAgLy/lj5Hlr7npnaLnmoTniYzvvIzlvIDlp4vlj6rmnIkz5byg54mMXHJcbiAgICAgICAgZm9yKHZhciBpID0gMDtpIDwgMzsgaSsrKXtcclxuICAgICAgICAgICAgIHNlbGYub3Bwb3NpdGVIb2xkcy5jaGlsZHJlbltpXS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgdmFyIHNwcml0ZSA9IHNlbGYub3Bwb3NpdGVIb2xkcy5jaGlsZHJlbltpXS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcclxuICAgICAgICAgICAgIHNlbGYuU2V0U3ByaXRlRnJhbWVCeUNhcmRJRChcIk9fXCIsdXNlcmRhdGEub2NhcmQuZ2V0KGkpLnN1aXQsMTMsc3ByaXRlKTsgLy/lr7npnaLnmoTniYzmmL7npLrkuLrmnKrnn6XnmoRcclxuICAgICAgICAgICAgIHNlbGYuU2V0Q2FyZHNJbmZvKHNlbGYub3Bwb3NpdGVDYXJkcyxpLHVzZXJkYXRhLm9jYXJkLmdldChpKSk7Ly/lrZjlgqjlr7npnaLljaHniYzkv6Hmga9cclxuICAgICAgICAgICAgIHNlbGYuR3Vlc3NDYXJkcyhzcHJpdGUubm9kZSk7Ly/njJzlr7npnaLnmoTniYxcclxuICAgICAgICB9XHJcbiAgICAgICAgLy/lj5Hlt6bovrnnmoTniYzvvIzlvIDlp4vlj6rmnIkz5byg54mMXHJcbiAgICAgICAgZm9yKHZhciBpID0gMDtpIDwgMzsgaSsrKXtcclxuICAgICAgICAgICAgIHNlbGYubGVmdEhvbGRzLmNoaWxkcmVuW2ldLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgICB2YXIgc3ByaXRlID0gc2VsZi5sZWZ0SG9sZHMuY2hpbGRyZW5baV0uZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSk7XHJcbiAgICAgICAgICAgICBzZWxmLlNldFNwcml0ZUZyYW1lQnlDYXJkSUQoXCJMX1wiLHVzZXJkYXRhLmxjYXJkLmdldChpKS5zdWl0LDEzLHNwcml0ZSk7IC8v5bem6L6555qE54mM5pi+56S65Li65pyq55+l55qEXHJcbiAgICAgICAgICAgICBzZWxmLlNldENhcmRzSW5mbyhzZWxmLmxlZnRDYXJkcyxpLHVzZXJkYXRhLmxjYXJkLmdldChpKSk7Ly/lrZjlgqjlt6bovrnljaHniYzkv6Hmga9cclxuICAgICAgICAgICAgIHNlbGYuR3Vlc3NDYXJkcyhzcHJpdGUubm9kZSk7IC8v54yc5bem6L6555qE54mMXHJcbiAgICAgICAgfSAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgIH0sXHJcblxyXG4gICAgIC8vNOS6uua4uOaIj+W8gOWni++8jOaRuOeJjFxyXG4gICAgRGVhbENhcmRzOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIC8v56Gu5a6a54yc54mM5Lq65L2N572uXHJcbiAgICAgICAgc2VsZi5HdWVzc1R1cm4oKTsgXHJcbiAgICAgICAgdmFyIHRjYXJkTG9jYXRpb24gPSBzZWxmLm15SG9sZHMuY2hpbGRyZW4ubGVuZ3RoIC0gMTtcclxuICAgICAgICBpZih1c2VyZGF0YS5tc2VhdCA9PT0gdXNlcmRhdGEuZnRwbGF5ZXIpey8v5aaC5p6c5b2T5YmN5a6i5oi356uv546p5a625piv5pG454mM5pa5XHJcbiAgICAgICAgICAgIHNlbGYubXlIb2xkcy5jaGlsZHJlbls4XS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICB2YXIgc3ByaXRlID0gc2VsZi5teUhvbGRzLmNoaWxkcmVuWzhdLmdldENvbXBvbmVudChjYy5TcHJpdGUpO1xyXG4gICAgICAgICAgICBzZWxmLlNldFNwcml0ZUZyYW1lQnlDYXJkSUQoXCJNX1wiLHVzZXJkYXRhLm1jYXJkLmdldCh1c2VyZGF0YS5tY2FyZC5zaXplLTEpLnN1aXQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyZGF0YS5tY2FyZC5nZXQodXNlcmRhdGEubWNhcmQuc2l6ZS0xKS5wb2ludCxzcHJpdGUpO1xyXG4gICAgICAgICAgICAvL+WmguaenOaRuOWIsOeahOeJjOaYr+S4h+iDveeJjFxyXG4gICAgICAgICAgICBpZih1c2VyZGF0YS5tY2FyZC5nZXQodXNlcmRhdGEubWNhcmQuc2l6ZS0xKS5wb2ludD09MTIpe1xyXG4gICAgICAgICAgICAgICAgY2MubG9nKFwi5pG45Yiw55qE54mM5piv5LiH6IO954mMXCIpO1xyXG4gICAgICAgICAgICAgICAgc2VsZi5yYW5kb21fc3VpdCA9IHVzZXJkYXRhLm1jYXJkLmdldCh1c2VyZGF0YS5tY2FyZC5zaXplLTEpLnN1aXQ7XHJcbiAgICAgICAgICAgICAgICBzZWxmLlJhbmRvbUFwcGVhcigpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHNlbGYuU2V0Q2FyZHNJbmZvKHNlbGYubXlDYXJkcyx1c2VyZGF0YS5tY2FyZC5zaXplLTEsdXNlcmRhdGEubWNhcmQuZ2V0KHVzZXJkYXRhLm1jYXJkLnNpemUtMSkpOy8v5a2Y5YKo5pG455qE54mM55qE5L+h5oGvXHJcbiAgICAgICAgfWVsc2UgaWYodXNlcmRhdGEucnNlYXQgPT09IHVzZXJkYXRhLmZ0cGxheWVyKXsvL+WmguaenOW9k+WJjeWuouaIt+err+eOqeWutueahOWPs+i+ueaYr+aRuOeJjOaWuVxyXG4gICAgICAgICAgICAgICAgc2VsZi5yaWdodEhvbGRzLmNoaWxkcmVuWzhdLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB2YXIgc3ByaXRlID0gc2VsZi5yaWdodEhvbGRzLmNoaWxkcmVuWzhdLmdldENvbXBvbmVudChjYy5TcHJpdGUpO1xyXG4gICAgICAgICAgICAgICAgc2VsZi5TZXRTcHJpdGVGcmFtZUJ5Q2FyZElEKFwiUl9cIix1c2VyZGF0YS50Y2FyZC5zdWl0LDEzLHNwcml0ZSk7XHJcbiAgICAgICAgICAgIHNlbGYuU2V0Q2FyZHNJbmZvKHNlbGYucmlnaHRDYXJkcyx1c2VyZGF0YS5yY2FyZC5zaXplLTEsdXNlcmRhdGEucmNhcmQuZ2V0KHVzZXJkYXRhLnJjYXJkLnNpemUtMSkpOy8v5a2Y5YKo5pG455qE54mM55qE5L+h5oGvICAgICAgICAgICAgICAgIFxyXG4gICAgICAgIH1lbHNlIGlmKHVzZXJkYXRhLm9zZWF0ID09PSB1c2VyZGF0YS5mdHBsYXllcil7Ly/lpoLmnpzlvZPliY3lrqLmiLfnq6/njqnlrrbnmoTlr7npnaLmmK/mkbjniYzmlrlcclxuICAgICAgICAgICAgICAgIHNlbGYub3Bwb3NpdGVIb2xkcy5jaGlsZHJlbls4XS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdmFyIHNwcml0ZSA9IHNlbGYub3Bwb3NpdGVIb2xkcy5jaGlsZHJlbls4XS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcclxuICAgICAgICAgICAgICAgIHNlbGYuU2V0U3ByaXRlRnJhbWVCeUNhcmRJRChcIk9fXCIsdXNlcmRhdGEudGNhcmQuc3VpdCwxMyxzcHJpdGUpO1xyXG4gICAgICAgICAgICBzZWxmLlNldENhcmRzSW5mbyhzZWxmLm9wcG9zaXRlQ2FyZHMsdXNlcmRhdGEub2NhcmQuc2l6ZS0xLHVzZXJkYXRhLm9jYXJkLmdldCh1c2VyZGF0YS5vY2FyZC5zaXplLTEpKTsvL+WtmOWCqOaRuOeahOeJjOeahOS/oeaBryAgICAgICAgICAgICAgICBcclxuICAgICAgICB9ZWxzZSBpZih1c2VyZGF0YS5sc2VhdCA9PT0gdXNlcmRhdGEuZnRwbGF5ZXIpey8v5aaC5p6c5b2T5YmN5a6i5oi356uv546p5a6255qE5bem6L655piv5pG454mM5pa5XHJcbiAgICAgICAgICAgICAgICBzZWxmLmxlZnRIb2xkcy5jaGlsZHJlbls4XS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdmFyIHNwcml0ZSA9IHNlbGYubGVmdEhvbGRzLmNoaWxkcmVuWzhdLmdldENvbXBvbmVudChjYy5TcHJpdGUpO1xyXG4gICAgICAgICAgICAgICAgc2VsZi5TZXRTcHJpdGVGcmFtZUJ5Q2FyZElEKFwiTF9cIix1c2VyZGF0YS50Y2FyZC5zdWl0LDEzLHNwcml0ZSk7XHJcbiAgICAgICAgICAgIHNlbGYuU2V0Q2FyZHNJbmZvKHNlbGYubGVmdENhcmRzLHVzZXJkYXRhLmxjYXJkLnNpemUtMSx1c2VyZGF0YS5sY2FyZC5nZXQodXNlcmRhdGEubGNhcmQuc2l6ZS0xKSk7Ly/lrZjlgqjmkbjnmoTniYznmoTkv6Hmga8gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgfSAgIFxyXG4gICAgfSxcclxuICAgXHJcbiAgICAvLzTkurrmuLjmiI/lvIDlp4vvvIznjJzniYxcclxuICAgIEd1ZXNzQ2FyZHM6ZnVuY3Rpb24obm9kZSl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzOyBcclxuICAgICAgICBub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULCBmdW5jdGlvbiAoZXZlbnQpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCLngrnlh7vlvIDlp4tjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVFwiKTtcclxuICAgICAgICAgICAgaWYgKG5vZGUucGFyZW50ID09PSBzZWxmLm15SG9sZHMpIHsvL+iHquW3seeahOeJjOS4jeiDveeCuVxyXG4gICAgICAgICAgICAgICAgY2MubG9nKFwi6Ieq5bex55qE54mM5LiN6IO954K5XCIpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZih1c2VyZGF0YS5mdHBsYXllciAhPSB1c2VyZGF0YS5tc2VhdCl7XHJcbiAgICAgICAgICAgICAgICBjYy5sb2coJ+S4jeaYr+iHquW3seeahOWbnuWQiO+8jOS4jeiDveeMnOeJjCcpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHZhciBtaW5ndGFnID0gbm9kZS5nZXRDaGlsZEJ5TmFtZShcIk1pbmdUYWdcIik7XHJcbiAgICAgICAgICAgIGlmKG1pbmd0YWcuYWN0aXZlID09PSB0cnVlKXtcclxuICAgICAgICAgICAgICAgIGNjLmxvZygn5bey57uP5piO54mM55qE54mM77yM5LiN6IO95YaN54ycJyk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgbm9kZS5pbnRlcmFjdGFibGUgPSBub2RlLmdldENvbXBvbmVudChjYy5CdXR0b24pLmludGVyYWN0YWJsZTtcclxuICAgICAgICAgICAgaWYgKCFub2RlLmludGVyYWN0YWJsZSkge1xyXG4gICAgICAgICAgICAgICAgY2MubG9nKFwiMzIzMjMyMzIzMlwiKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBzZWxmLmd1ZXNzLmFjdGl2ZSA9IHRydWU7Ly/orqnnjJzniYzmoYblh7rnjrBcclxuICAgICAgICAgICAgc2VsZi5ndWVzc2JnLm9uKCd0b3VjaHN0YXJ0Jywgc2VsZi5FYXRUb3VjaCwgc2VsZik7Ly/op6bmkbjlkJ7lmaxcclxuXHJcbiAgICAgICAgICAgIHNlbGYuZ3Vlc3NQb2ludERpc3BsYXkuc3RyaW5nID0gXCI3XCI7Ly/njJzniYzngrnmlbDliJ3lp4vmmL7npLrkuLo377ybXHJcbiAgICAgICAgICAgIHNlbGYuZ3Vlc3NfcG9pbnQgPSA3O1xyXG5cclxuICAgICAgICAgICAgc2VsZi5HZXRHdWVzc2VkbWFuKG5vZGUpOy8v6I635Y+W54K55Ye755qE54mM55qE5a+55omL5bqn5L2NXHJcblxyXG4gICAgICAgICAgICBjYy5sb2coXCLngrnlh7vnmoTljaHniYfnmoTngrnmlbDvvIzpopzoibLvvIzkvY3nva7vvJpcIitzZWxmLkdldENhcmRzSW5mbyhub2RlKS5wb2ludCtcclxuICAgICAgICAgICAgXCIsXCIrc2VsZi5HZXRDYXJkc0luZm8obm9kZSkuc3VpdCtcIixcIitzZWxmLkdldENhcmRzSW5mbyhub2RlKS5wb3NpKTtcclxuXHJcbiAgICAgICAgICAgIHNlbGYuZ3Vlc3Nfc3VpdCA9IHNlbGYuR2V0Q2FyZHNJbmZvKG5vZGUpLnN1aXQ7XHJcbiAgICAgICAgICAgIHNlbGYuZ3Vlc3NfcG9zaSA9IHNlbGYuR2V0Q2FyZHNJbmZvKG5vZGUpLnBvc2k7XHJcblxyXG4gICAgICAgICAgICBpZih1c2VyZGF0YS5mdHBsYXllciA9PSB1c2VyZGF0YS5tc2VhdCYmbWluZ3RhZy5hY3RpdmUgIT0gdHJ1ZSl7XHJcbiAgICAgICAgICAgICAgICBzZWxmLkd1ZXNzQ2FyZFBvcChub2RlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0uYmluZCh0aGlzKSk7XHJcblxyXG4gICAgICAgIG5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfTW92ZSwgZnVuY3Rpb24gKGV2ZW50KSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfTU9WRVwiKTtcclxuICAgICAgICAgICAgaWYgKG5vZGUucGFyZW50ID09PSBzZWxmLm15SG9sZHMpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoIW5vZGUuaW50ZXJhY3RhYmxlKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdmFyIG1pbmd0YWcgPSBub2RlLmdldENoaWxkQnlOYW1lKFwiTWluZ1RhZ1wiKTtcclxuICAgICAgICAgICAgaWYobWluZ3RhZy5hY3RpdmUgPT09IHRydWUpe1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChNYXRoLmFicyhldmVudC5nZXREZWx0YVgoKSkgKyBNYXRoLmFicyhldmVudC5nZXREZWx0YVkoKSkgPCAwLjUpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0uYmluZCh0aGlzKSk7XHJcblxyXG4gICAgICAgIG5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELCBmdW5jdGlvbiAoZXZlbnQpIHtcclxuICAgICAgICAgICAgdmFyIG1pbmd0YWcgPSBub2RlLmdldENoaWxkQnlOYW1lKFwiTWluZ1RhZ1wiKTtcclxuICAgICAgICAgICAgaWYgKG5vZGUucGFyZW50ID09PSBzZWxmLm15SG9sZHMpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoIW5vZGUuaW50ZXJhY3RhYmxlKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgIFxyXG4gICAgICAgICAgIGlmKHVzZXJkYXRhLmZ0cGxheWVyID09IHVzZXJkYXRhLm1zZWF0JiZtaW5ndGFnLmFjdGl2ZSE9IHRydWUpe1xyXG4gICAgICAgICAgICAgIHNlbGYuR3Vlc3NDYXJkUHVzaChub2RlKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJcXG7ngrnlh7vnu5PmnZ9jYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkRcIik7XHJcbiAgICAgICAgfS5iaW5kKHRoaXMpKTtcclxuXHJcbiAgICAgICAgbm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9DQU5DRUwsIGZ1bmN0aW9uIChldmVudCkge1xyXG4gICAgICAgICAgICBpZiAobm9kZS5wYXJlbnQgPT09IHNlbGYubXlIb2xkcykge1xyXG4gICAgICAgICAgICAgICAgY2MubG9nKFwi5LiN6IO954K5XCIpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICghbm9kZS5pbnRlcmFjdGFibGUpIHtcclxuICAgICAgICAgICAgICAgIGNjLmxvZyhcIuS4jeiDveeCuVwiKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0NBTkNFTFwiKTtcclxuICAgICAgICB9LmJpbmQodGhpcykpOyAgICAgICAgICAgIFxyXG4gICAgfSxcclxuXHJcbiAgICAvL+eMnOeJjOaXtu+8jOiuqeeCueWHu+eahOeJjOeqgeWHuuaJi+eJjFxyXG4gICAgR3Vlc3NDYXJkUG9wOmZ1bmN0aW9uKG5vZGUpe1xyXG4gICAgICAgIHZhciBzZWxmICA9IHRoaXM7XHJcbiAgICAgICAgdmFyIG94ID0gbm9kZS5nZXRQb3NpdGlvblgoKTtcclxuICAgICAgICB2YXIgb3kgPSBub2RlLmdldFBvc2l0aW9uWSgpO1xyXG4gICAgICAgIGlmKG5vZGUucGFyZW50PT09c2VsZi5yaWdodEhvbGRzKXtcclxuICAgICAgICAgICAgdmFyIG1vdmUxPWNjLm1vdmVUbygwLjAwMDEsY2MucChveC00MCxveSkpO1xyXG4gICAgICAgICAgICBub2RlLnJ1bkFjdGlvbihtb3ZlMSk7XHJcbiAgICAgICAgfWVsc2UgaWYobm9kZS5wYXJlbnQ9PT1zZWxmLm9wcG9zaXRlSG9sZHMpe1xyXG4gICAgICAgICAgICB2YXIgbW92ZTE9Y2MubW92ZVRvKDAuMDAwMSxjYy5wKG94LG95LTMwKSk7XHJcbiAgICAgICAgICAgIG5vZGUucnVuQWN0aW9uKG1vdmUxKTtcclxuICAgICAgICB9ZWxzZSBpZihub2RlLnBhcmVudD09PXNlbGYubGVmdEhvbGRzKXtcclxuICAgICAgICAgICAgdmFyIG1vdmUxPWNjLm1vdmVUbygwLjAwMDEsY2MucChveCs0MCxveSkpO1xyXG4gICAgICAgICAgICBub2RlLnJ1bkFjdGlvbihtb3ZlMSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvL+eMnOeJjOaXtu+8jOiuqeeCueWHu+eahOeJjOe8qeWbnuaJi+eJjFxyXG4gICAgR3Vlc3NDYXJkUHVzaDpmdW5jdGlvbihub2RlKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgdmFyIG94ID0gbm9kZS5nZXRQb3NpdGlvblgoKTtcclxuICAgICAgICB2YXIgb3kgPSBub2RlLmdldFBvc2l0aW9uWSgpO1xyXG4gICAgICAgIGlmKG5vZGUucGFyZW50PT09c2VsZi5yaWdodEhvbGRzKXtcclxuICAgICAgICAgICAgdmFyIG1vdmUxPWNjLm1vdmVUbygwLjAwNSxjYy5wKG94KzQwLG95KSk7XHJcbiAgICAgICAgICAgIG5vZGUucnVuQWN0aW9uKG1vdmUxKTtcclxuICAgICAgICB9ZWxzZSBpZihub2RlLnBhcmVudD09PXNlbGYub3Bwb3NpdGVIb2xkcyl7XHJcbiAgICAgICAgICAgIHZhciBtb3ZlMT1jYy5tb3ZlVG8oMC4wMDUsY2MucChveCxveSszMCkpO1xyXG4gICAgICAgICAgICBub2RlLnJ1bkFjdGlvbihtb3ZlMSk7XHJcbiAgICAgICAgfWVsc2UgaWYobm9kZS5wYXJlbnQ9PT1zZWxmLmxlZnRIb2xkcyl7XHJcbiAgICAgICAgICAgIHZhciBtb3ZlMT1jYy5tb3ZlVG8oMC4wMDUsY2MucChveC00MCxveSkpO1xyXG4gICAgICAgICAgICBub2RlLnJ1bkFjdGlvbihtb3ZlMSk7XHJcbiAgICAgICAgfSAgICAgICAgICBcclxuICAgIH0sXHJcbiAgICAvL+aPkueJjOWKqOS9nOaooeadv1xyXG4gICAgVGVtcGxhdGVfaW5zZXJ0OmZ1bmN0aW9uKG1hcCxzZWF0SG9sZHMsY2FyZGxlbmd0aCl7XHJcbiAgICAgICAgdmFyIHNlbGY9dGhpcztcclxuICAgICAgICB2YXIgY2FyZFBvc2l0aW9uWCA9IDA7XHJcbiAgICAgICAgdmFyIGNhcmRQb3NpdGlvblkgPSAwO1xyXG4gICAgICAgIHNlYXRIb2xkcy5jaGlsZHJlbltjYXJkbGVuZ3RoLTFdLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgY2FyZFBvc2l0aW9uWCA9IHNlYXRIb2xkcy5jaGlsZHJlblttYXAuZ2V0KGNhcmRsZW5ndGgtMSkucG9zaS0xXS5nZXRQb3NpdGlvblgoKTtcclxuICAgICAgICBjYXJkUG9zaXRpb25ZID0gc2VhdEhvbGRzLmNoaWxkcmVuW21hcC5nZXQoY2FyZGxlbmd0aC0xKS5wb3NpLTFdLmdldFBvc2l0aW9uWSgpO1xyXG4gICAgICAgIHZhciBtID0gY2FyZGxlbmd0aDtcclxuICAgICAgICB2YXIgbiA9IG1hcC5nZXQoY2FyZGxlbmd0aC0xKS5wb3NpO1xyXG4gICAgICAgIC8vIHNlbGYuRXhjaGFuZ2VDYXJkMShzZWF0SG9sZHMuY2hpbGRyZW5bY2FyZGxlbmd0aC0xXSwgc2VhdEhvbGRzLmNoaWxkcmVuW21hcC5nZXQoY2FyZGxlbmd0aC0xKS5wb3NpLTFdKTtcclxuICAgICAgICBmb3IodmFyIGkgPSBtYXAuZ2V0KGNhcmRsZW5ndGgtMSkucG9zaTsgaSA8IGNhcmRsZW5ndGg7IGkrKyl7XHJcbiAgICAgICAgICAgICAgICBzZWxmLkV4Y2hhbmdlQ2FyZDEoc2VhdEhvbGRzLmNoaWxkcmVuW2ktMV0sc2VhdEhvbGRzLmNoaWxkcmVuW2ldKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgc2VhdEhvbGRzLmNoaWxkcmVuW2NhcmRsZW5ndGgtMV0uc2V0UG9zaXRpb24oY2FyZFBvc2l0aW9uWCxjYXJkUG9zaXRpb25ZKTtcclxuICAgICAgICAgICAgc2VsZi5FeGNoYW5nZUluZGV4KHNlYXRIb2xkcyxjYXJkbGVuZ3RoLG1hcC5nZXQoY2FyZGxlbmd0aC0xKS5wb3NpKTtcclxuICAgICAgICAgICAgc2VsZi5FeGNoYW5nZUNhcmQyKHNlYXRIb2xkcy5jaGlsZHJlbltzZWF0SG9sZHMuY2hpbGRyZW4ubGVuZ3RoLTFdLHNlYXRIb2xkcy5jaGlsZHJlblttYXAuZ2V0KGNhcmRsZW5ndGgtMSkucG9zaS0xXSk7XHJcbiAgICAgICAgICAgIFtzZWF0SG9sZHMuY2hpbGRyZW5bc2VhdEhvbGRzLmNoaWxkcmVuLmxlbmd0aC0xXSxzZWF0SG9sZHMuY2hpbGRyZW5bbWFwLmdldChjYXJkbGVuZ3RoLTEpLnBvc2ktMV1dPVxyXG4gICAgICAgICAgICBbc2VhdEhvbGRzLmNoaWxkcmVuW21hcC5nZXQoY2FyZGxlbmd0aC0xKS5wb3NpLTFdLHNlYXRIb2xkcy5jaGlsZHJlbltzZWF0SG9sZHMuY2hpbGRyZW4ubGVuZ3RoLTFdXTsgICAgICAgXHJcbiAgICAgICAgICAgIH0sIDMwMCk7XHJcbiAgICB9LFxyXG4gICAgLy805Lq65ri45oiP5byA5aeL77yM5Zyo54yc54mM5ZCO77yM5o+S54mMXHJcbiAgICBJbnNlcnRDYXJkczpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBpZih1c2VyZGF0YS5mdHBsYXllcj09PXVzZXJkYXRhLm1zZWF0KXsvL+WmguaenOW9k+WJjeWuouaIt+err+eOqeWutuaYr+aRuOeJjOaWuVxyXG4gICAgICAgICAgICBzZWxmLlRlbXBsYXRlX2luc2VydCh1c2VyZGF0YS5tY2FyZCxzZWxmLm15SG9sZHMsdXNlcmRhdGEubWNhcmQuc2l6ZSk7XHJcbiAgICAgICAgfWVsc2UgaWYodXNlcmRhdGEuZnRwbGF5ZXI9PT11c2VyZGF0YS5yc2VhdCl7Ly/lpoLmnpzlvZPliY3lrqLmiLfnq6/lj7PovrnnjqnlrrbmmK/mkbjniYzmlrlcclxuICAgICAgICAgICAgc2VsZi5UZW1wbGF0ZV9pbnNlcnQodXNlcmRhdGEucmNhcmQsc2VsZi5yaWdodEhvbGRzLHVzZXJkYXRhLnJjYXJkLnNpemUpO1xyXG4gICAgICAgIH1lbHNlIGlmKHVzZXJkYXRhLmZ0cGxheWVyPT09dXNlcmRhdGEub3NlYXQpey8v5aaC5p6c5b2T5YmN5a6i5oi356uv5a+56Z2i546p5a625piv5pG454mM5pa5XHJcbiAgICAgICAgICAgIHNlbGYuVGVtcGxhdGVfaW5zZXJ0KHVzZXJkYXRhLm9jYXJkLHNlbGYub3Bwb3NpdGVIb2xkcyx1c2VyZGF0YS5vY2FyZC5zaXplKTtcclxuICAgICAgICB9ZWxzZSBpZih1c2VyZGF0YS5mdHBsYXllcj09PXVzZXJkYXRhLmxzZWF0KXsvL+WmguaenOW9k+WJjeWuouaIt+err+W3pui+ueeOqeWutuaYr+aRuOeJjOaWuVxyXG4gICAgICAgICAgICBzZWxmLlRlbXBsYXRlX2luc2VydCh1c2VyZGF0YS5sY2FyZCxzZWxmLmxlZnRIb2xkcyx1c2VyZGF0YS5sY2FyZC5zaXplKTtcclxuICAgICAgICB9ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICB9LFxyXG4gICAgIC8v6K6+572u5Y2h54mM5Zu+54mH5Ye95pWwXHJcbiAgICBTZXRTcHJpdGVGcmFtZUJ5Q2FyZElEIDpmdW5jdGlvbihwcmUsY29sb3IsY2FyZElkLHNwcml0ZSl7XHJcbiAgICAgICAgdmFyIGNhcmRtZ3IgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KFwiQ2FyZE1nclwiKTtcclxuICAgICAgICBzcHJpdGUuc3ByaXRlRnJhbWUgPSBjYXJkbWdyLmdldFNwcml0ZUZyYW1lQnlDYXJkSUQocHJlLGNvbG9yLGNhcmRJZCk7XHJcbiAgICB9LFxyXG4gICAgIFxyXG4gICAgLy/lrZjlgqjljaHniYzkv6Hmga9cclxuICAgIFNldENhcmRzSW5mbzpmdW5jdGlvbihteUNhcmRzLC8v5a2Y5YKo5Y2h54mM5L+h5oGv55qE5pWw57uEXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXgsLy/ljaHniYzlr7nlupRub2Rl5Zyo5omL54mM5Lit55qE5L2N572uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25lQ2FyZCwvL+S7juacjeWKoeWZqOaOpeWPl+WIsOeahOWNoeeJjOS/oeaBr1xyXG4gICAgICAgICl7ICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgbXlDYXJkc1tpbmRleF0gPSBvbmVDYXJkO1xyXG4gICAgfSxcclxuXHJcbiAgICAvL+aPkOWPluWNoeeJjOS/oeaBr1xyXG4gICAgR2V0Q2FyZHNJbmZvOmZ1bmN0aW9uKG5vZGUpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpczsgICAgICAgIFxyXG4gICAgICAgIGZvcih2YXIgaSA9IDA7IGkgPCBzZWxmLm15SG9sZHMuY2hpbGRyZW4ubGVuZ3RoOyBpKyspe1xyXG4gICAgICAgICAgICBpZihub2RlID09IHNlbGYubXlIb2xkcy5jaGlsZHJlbltpXSl7XHJcbiAgICAgICAgICAgICAgICBpZihpID09IHNlbGYubXlIb2xkcy5jaGlsZHJlbi5sZW5ndGgtMSl7Ly/lpoLmnpzmg7Pojrflj5bmkbjlvpfniYznmoTkv6Hmga9cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gc2VsZi5teUNhcmRzW3VzZXJkYXRhLm1jYXJkLnNpemUtMV07Ly/pgqPkuYjov5Tlm57mlbDnu4TnmoTmnIDlkI7kuIDkuKpcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgcmV0dXJuIHNlbGYubXlDYXJkc1tpXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICB9XHJcbiAgICAgICAgZm9yKHZhciBpID0gMDsgaSA8IHNlbGYucmlnaHRIb2xkcy5jaGlsZHJlbi5sZW5ndGg7IGkrKyl7XHJcbiAgICAgICAgICAgIGlmKG5vZGUgPT0gc2VsZi5yaWdodEhvbGRzLmNoaWxkcmVuW2ldKXtcclxuICAgICAgICAgICAgICAgaWYoaSA9PSBzZWxmLnJpZ2h0SG9sZHMuY2hpbGRyZW4ubGVuZ3RoLTEpey8v5aaC5p6c5oOz6I635Y+W5pG45b6X54mM55qE5L+h5oGvXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHNlbGYucmlnaHRDYXJkc1t1c2VyZGF0YS5yY2FyZC5zaXplLTFdOy8v6YKj5LmI6L+U5Zue5pWw57uE55qE5pyA5ZCO5LiA5LiqXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIHJldHVybiBzZWxmLnJpZ2h0Q2FyZHNbaV07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgfVxyXG4gICAgICAgIGZvcih2YXIgaSA9IDA7IGkgPCBzZWxmLm9wcG9zaXRlSG9sZHMuY2hpbGRyZW4ubGVuZ3RoOyBpKyspe1xyXG4gICAgICAgICAgICBpZihub2RlID09IHNlbGYub3Bwb3NpdGVIb2xkcy5jaGlsZHJlbltpXSl7XHJcbiAgICAgICAgICAgICAgIGlmKGkgPT0gc2VsZi5vcHBvc2l0ZUhvbGRzLmNoaWxkcmVuLmxlbmd0aC0xKXsvL+WmguaenOaDs+iOt+WPluaRuOW+l+eJjOeahOS/oeaBr1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBzZWxmLm9wcG9zaXRlQ2FyZHNbdXNlcmRhdGEub2NhcmQuc2l6ZS0xXTsvL+mCo+S5iOi/lOWbnuaVsOe7hOeahOacgOWQjuS4gOS4qlxyXG4gICAgICAgICAgICAgICAgfSAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgcmV0dXJuIHNlbGYub3Bwb3NpdGVDYXJkc1tpXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICB9XHJcbiAgICAgICAgZm9yKHZhciBpID0gMDsgaSA8IHNlbGYubGVmdEhvbGRzLmNoaWxkcmVuLmxlbmd0aDsgaSsrKXtcclxuICAgICAgICAgICAgaWYobm9kZSA9PSBzZWxmLmxlZnRIb2xkcy5jaGlsZHJlbltpXSl7XHJcbiAgICAgICAgICAgICAgIGlmKGkgPT0gc2VsZi5sZWZ0SG9sZHMuY2hpbGRyZW4ubGVuZ3RoLTEpey8v5aaC5p6c5oOz6I635Y+W5pG45b6X54mM55qE5L+h5oGvXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHNlbGYubGVmdENhcmRzW3VzZXJkYXRhLmxjYXJkLnNpemUtMV07Ly/pgqPkuYjov5Tlm57mlbDnu4TnmoTmnIDlkI7kuIDkuKpcclxuICAgICAgICAgICAgICAgIH0gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgIHJldHVybiBzZWxmLmxlZnRDYXJkc1tpXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICB9ICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIC8v54K55Ye754yc54mM5rWu5qGG5LiK55qE56Gu5a6a6ZSu77yM5Y+R6YCB5omA54yc55qE54mMXHJcbiAgICBHdWVzc0NvbmZpcm06ZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgc2VsZj10aGlzO1xyXG4gICAgICAgIGNjLmxvZyhcIlJvdW5kOlwiK3VzZXJkYXRhLnJvdW5kKTtcclxuICAgICAgICAvL+aJgOeMnOeahOWNoeeJjOS/oeaBr1xyXG4gICAgICAgIHZhciBjYXJkID0gSlNPTi5zdHJpbmdpZnkoe0NhcmRQb2ludDpzZWxmLmd1ZXNzX3BvaW50LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENhcmRTdWl0OnNlbGYuZ3Vlc3Nfc3VpdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQb3NpdGlvbjpzZWxmLmd1ZXNzX3Bvc2ksXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgY2FyZCA9IEpTT04ucGFyc2UoY2FyZCk7XHJcbiAgICAgICAgLy/liqDkuIrnjJznmoTlkb3ku6QxMDAyMuWSjOaJgOeMnOS6uuS9jee9rnNlYXQgICAgICAgXHJcbiAgICAgICAgdmFyIGNvbnRlbnQgPSBKU09OLnN0cmluZ2lmeSh7VHlwZToxMDAyMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTZWF0OnVzZXJkYXRhLmd1ZXNzZWRtYW4sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2FyZDpjYXJkLCAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICB9KTtcclxuICAgICAgICBjb250ZW50ID0gSlNPTi5wYXJzZShjb250ZW50KTtcclxuICAgICAgICAvL+WKoOS4iuWuouaIt+err3Nlc3Npb27lj7dpZFxyXG4gICAgICAgIHZhciBndWVzc19zZG1lcyA9IEpTT04uc3RyaW5naWZ5KHtJZDp1c2VyZGF0YS5pZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDb250ZW50OmNvbnRlbnQsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgZ3Vlc3Nfc2RtZXMgPSBcIm1zZz1cIitndWVzc19zZG1lcztcclxuICAgICAgICBjYy5sb2coXCLlj5HpgIHnjJzniYzkv6Hmga/vvJpcIitndWVzc19zZG1lcyk7XHJcbiAgICAgICAgaWYoc2VsZi5zdGVwQ291bnQ8PTApe1xyXG4gICAgICAgICAgICBjYy5sb2coJ+W3sue7j+i2heaXtuS6hu+8jOS4jeiDveWGjeWPkemAgeeMnOeJjOS/oeaBrycpO1xyXG4gICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICBzZWxmLnN0ZXBDb3VudCA9IDIxO1xyXG4gICAgICAgICAgICBodHRwLkh0dHBQb3N0KHNlbGYudXJsLGd1ZXNzX3NkbWVzLGZ1bmN0aW9uKGd1ZXNzX3J2bWVzKXtcclxuICAgICAgICAgICAgICAgIGlmIChndWVzc19ydm1lcyA9PT0gLTEpIHtcclxuICAgICAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgICAgIGd1ZXNzX3J2bWVzPUpTT04ucGFyc2UoZ3Vlc3NfcnZtZXMpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZyhndWVzc19ydm1lcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYoZ3Vlc3NfcnZtZXMuVHlwZSA9PT0gMTAwMzUpey8v5Ye6546w6IOc5Yip6ICFXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIuWHuueOsOiDnOWIqeiAhVwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYodXNlcmRhdGEucmVzdGNhcmQhPSBmYWxzZSAmJiB1c2VyZGF0YS5jYXJkc0FyZU51bGwhPTEpe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYXJkYWN0aXZpdHkuT3ZlcihndWVzc19ydm1lcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuTWluZ0JyYW5nKHVzZXJkYXRhLmZ0cGxheWVyLHVzZXJkYXRhLnRjYXJkLHNlbGYubXlIb2xkcy5jaGlsZHJlbi5sZW5ndGgpOyAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuR2FtZU92ZXIoZ3Vlc3NfcnZtZXMpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxmLkluc2VydENhcmRzKCk7ICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYXJkYWN0aXZpdHkuSW5zZXJ0X2NhcmQoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LCA1MDApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhcmRhY3Rpdml0eS5PdmVyKGd1ZXNzX3J2bWVzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuR2FtZU92ZXIoZ3Vlc3NfcnZtZXMpOy8v54mM5aCG6YeM55qE54mM5Y+R5a6M5LqG5pe25Ye6546w6IOc5Yip6ICFXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FyZGFjdGl2aXR5Lkd1ZXNzUmVzdWx0KGd1ZXNzX3J2bWVzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYoZ3Vlc3NfcnZtZXMuVHlwZT09PTEwMDIzKXsvL+i/lOWbnueMnOeJjOe7k+aenOS/oeaBr1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXNlcmRhdGEucm91bmQgKz0xO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5yb3VuZENvdW50TGFiZWwuc3RyaW5nID0gdXNlcmRhdGEucm91bmQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZihndWVzc19ydm1lcy5UY2FyZC5DYXJkUG9pbnQgPT0gMTIpey8v5aaC5p6c5pG45b6X54mM5piv5LiH6IO954mM77yM5YiZ5pS55Y+Y5YW2cG9zaVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuQ2hhbmdlUmFuZG9tUG9zaShndWVzc19ydm1lcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzd2l0Y2goZ3Vlc3NfcnZtZXMuUmVzdWx0KXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSB0cnVlOi8v54yc5a+5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCI2NjY2NjY2NueMnOWvueS6hlwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmKGd1ZXNzX3J2bWVzLkd1ZXNzQ2FyZC5DYXJkUG9pbnQ9PTEyKXsvL+S4iuaWuemjmOi/h+eahOaPkOekuua2iOaBr1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYubmV3c0Rpc3BsYXkuc3RyaW5nID0gXCLnjqnlrrZcIitzZWxmLmdldE5hbWVCeVNlYXQodXNlcmRhdGEubXNlYXQpK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIueMnOeOqeWutlwiK3NlbGYuZ2V0TmFtZUJ5U2VhdCh1c2VyZGF0YS5ndWVzc2VkbWFuKStcIueahOesrFwiK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyZGF0YS5ndWVzc2VkY2FyZC5wb3NpK1wi5byg54mM5Li65LiH6IO954mM77yM54yc5a+55LqGXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLm5ld3NEaXNwbGF5LnN0cmluZyA9IFwi546p5a62XCIrc2VsZi5nZXROYW1lQnlTZWF0KHVzZXJkYXRhLm1zZWF0KStcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIueMnOeOqeWutlwiK3NlbGYuZ2V0TmFtZUJ5U2VhdCh1c2VyZGF0YS5ndWVzc2VkbWFuKStcIueahOesrFwiK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyZGF0YS5ndWVzc2VkY2FyZC5wb3NpK1wi5byg54mM5Li6XCIrZ3Vlc3NfcnZtZXMuR3Vlc3NDYXJkLkNhcmRQb2ludCtcIueCue+8jOeMnOWvueS6hlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5uZXdzSGlzdG9yeSA9IHNlbGYubmV3c0hpc3RvcnkgKyBcIlxcblwiICsgXCLnrKxcIisodXNlcmRhdGEucm91bmQtMSkrXCLlm57lkIjvvJpcIitzZWxmLm5ld3NEaXNwbGF5LnN0cmluZztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYubmV3c0hpc3RvcnlBZGQrPTE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLm5ld3NEaXNwbGF5LmdldENvbXBvbmVudChjYy5BbmltYXRpb24pLnBsYXkoJ25ld3NGbG93Jyk7Ly/mj5DnpLrkv6Hmga/po5jov4cuLi5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuTWluZ0JyYW5nKHVzZXJkYXRhLmd1ZXNzZWRtYW4sdXNlcmRhdGEuZ3Vlc3NlZGNhcmQsdXNlcmRhdGEuZ3Vlc3NlZGNhcmQucG9zaSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLkNvbnRpbnVlUGxheSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgZmFsc2U6Ly/njJzplJlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmKGd1ZXNzX3J2bWVzLlRpbWVPdXQgPT0gZmFsc2Upey8v5pyq6LaF5pe254yc6ZSZXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCIyMzMzMzMzM+eMnOmUmeS6hlwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmKGd1ZXNzX3J2bWVzLkd1ZXNzQ2FyZC5DYXJkUG9pbnQ9PTEyKXsvL+S4iuaWuemjmOi/h+eahOaPkOekuua2iOaBr1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYubmV3c0Rpc3BsYXkuc3RyaW5nID0gXCLnjqnlrrZcIitzZWxmLmdldE5hbWVCeVNlYXQodXNlcmRhdGEubXNlYXQpK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIueMnOeOqeWutlwiK3NlbGYuZ2V0TmFtZUJ5U2VhdCh1c2VyZGF0YS5ndWVzc2VkbWFuKStcIueahOesrFwiK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyZGF0YS5ndWVzc2VkY2FyZC5wb3NpK1wi5byg54mM5Li65LiH6IO954mM77yM54yc6ZSZ5LqGXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLm5ld3NEaXNwbGF5LnN0cmluZyA9IFwi546p5a62XCIrc2VsZi5nZXROYW1lQnlTZWF0KHVzZXJkYXRhLm1zZWF0KStcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIueMnOeOqeWutlwiK3NlbGYuZ2V0TmFtZUJ5U2VhdCh1c2VyZGF0YS5ndWVzc2VkbWFuKStcIueahOesrFwiK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyZGF0YS5ndWVzc2VkY2FyZC5wb3NpK1wi5byg54mM5Li6XCIrZ3Vlc3NfcnZtZXMuR3Vlc3NDYXJkLkNhcmRQb2ludCtcIueCue+8jOeMnOmUmeS6hlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5uZXdzSGlzdG9yeSA9IHNlbGYubmV3c0hpc3RvcnkgKyBcIlxcblwiICsgXCLnrKxcIisodXNlcmRhdGEucm91bmQtMSkrXCLlm57lkIjvvJpcIitzZWxmLm5ld3NEaXNwbGF5LnN0cmluZztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYubmV3c0hpc3RvcnlBZGQrPTE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLm5ld3NEaXNwbGF5LmdldENvbXBvbmVudChjYy5BbmltYXRpb24pLnBsYXkoJ25ld3NGbG93Jyk7Ly/mj5DnpLrkv6Hmga/po5jov4cuLi5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmKHVzZXJkYXRhLnJlc3RjYXJkKXsvL+WmguaenOeJjOWghuacieeJjFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5NaW5nQnJhbmcodXNlcmRhdGEubXNlYXQsdXNlcmRhdGEubWNhcmQuZ2V0KHVzZXJkYXRhLm1jYXJkLnNpemUtMSksc2VsZi5teUhvbGRzLmNoaWxkcmVuLmxlbmd0aCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLnN0ZXBDb3VudCA9IDIxOyAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLlJvdW5kQ2hhbmdlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1lbHNlIGlmKGd1ZXNzX3J2bWVzLlRpbWVPdXQgPT0gdHJ1ZSl7Ly/njJzniYzml7bmgbDlpb3otoXml7bvvIzlsLHnm7TmjqXmjInotoXml7blpITnkIZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZih1c2VyZGF0YS5mdHBsYXllciA9PSB1c2VyZGF0YS5tc2VhdCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIuacrOaWuei2heaXtjFcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmKHVzZXJkYXRhLnJlc3RjYXJkID09IGZhbHNlKXsvL+WmguaenOeJjOWghuaXoOeJjFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwiMzMzMzMzMzMzMzMzM+eJjOWghuaXoOeJjOi2heaXtlwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWVsc2V7Ly/lpoLmnpzniYzloIbmnInniYxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuUmVzdWx0RXBvbGwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgICBzZWxmLmd1ZXNzLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgfSxcclxuXHJcbiAgICAvL+eCueWHu+eMnOeJjOa1ruahhuS4iueahOWPiemUru+8jOWPlua2iOeMnOeJjO+8jOWFs+mXreeMnOeJjOa1ruahhlxyXG4gICAgR3Vlc3NDYW5jZWw6ZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgc2VsZi5ndWVzcy5hY3RpdmUgPSBmYWxzZTtcclxuICAgIH0sXHJcbiAgICAvL+eCueWHu+aPkumaj+acuueJjOahhuS4iueahOWPiemUru+8jOWPlua2iOaPkueJjO+8jOWFs+mXreaPkueJjOa1ruahhlxyXG4gICAgSW5zZXJ0UmFuZG9tQ2FuY2VsOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHNlbGYuaW5zZXJ0X3JhbmRvbS5hY3RpdmUgPSBmYWxzZTtcclxuICAgIH0sXHJcblxyXG4gICAgLy/op6bmkbjlkJ7lmaxcclxuICAgIEVhdFRvdWNoOmZ1bmN0aW9uKGV2ZW50KXtcclxuICAgICAgICBjYy5sb2coJ0VhdFRvdWNoJyk7XHJcblx0ICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgfSxcclxuXHJcbiAgICAvL+eCueWHu+eMnOeJjOa1ruahhuS4iueahOWKoOWPt+mUru+8jOWinuWKoOeMnOeJjOeCueaVsFxyXG4gICAgQWRkR3Vlc3NQb2ludDpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICB2YXIgYSA9IDA7XHJcbiAgICAgICAgaWYoc2VsZi5ndWVzc1BvaW50RGlzcGxheS5zdHJpbmcgPT0gXCLkuIfog71cIil7XHJcbiAgICAgICAgICAgIGEgPSAxMjsgICAgICBcclxuICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgYSA9IHBhcnNlSW50KHNlbGYuZ3Vlc3NQb2ludERpc3BsYXkuc3RyaW5nKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgYSsrO1xyXG4gICAgICAgIGlmKGE8PTApe1xyXG4gICAgICAgICAgIGE9IDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKGE+PTEyKXtcclxuICAgICAgICAgICBhID0gMTI7IFxyXG4gICAgICAgIH1cclxuICAgICAgICBzZWxmLmd1ZXNzX3BvaW50ID0gYTtcclxuICAgICAgICBpZihhID09IDEyKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgIHNlbGYuZ3Vlc3NQb2ludERpc3BsYXkuc3RyaW5nID0gXCLkuIfog71cIjsgIFxyXG4gICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgc2VsZi5ndWVzc1BvaW50RGlzcGxheS5zdHJpbmcgPSBhLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvL+eCueWHu+aPkueJjOa1ruahhuS4iueahOWKoOWPt+mUru+8jOWinuWKoOaPkueJjOS9jee9rlxyXG4gICAgQWRkSW5zZXJ0TnVtOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHZhciBhID0gNztcclxuICAgICAgICBhID0gcGFyc2VJbnQoc2VsZi5pbnNlcnRfcmFuZG9tRGlzcGxheS5zdHJpbmcpO1xyXG4gICAgICAgIGErKztcclxuICAgICAgICBpZihhPD0xKXtcclxuICAgICAgICAgICBhPSAxO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZihhPj0xMSl7XHJcbiAgICAgICAgICAgYSA9IDExOyBcclxuICAgICAgICB9XHJcbiAgICAgICAgc2VsZi5yYW5kb21fcG9pbnQgPSBhO1xyXG4gICAgICAgIHNlbGYuaW5zZXJ0X3JhbmRvbURpc3BsYXkuc3RyaW5nID1hLnRvU3RyaW5nKCk7ICBcclxuICAgIH0sXHJcbiAgICAvL+eCueWHu+eMnOeJjOa1ruahhuS4iueahOWHj+WPt+mUru+8jOWHj+WwkeeMnOeJjOeCueaVsFxyXG4gICAgUmVkdWNlR3Vlc3NQb2ludDpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICB2YXIgYSA9IDA7XHJcbiAgICAgICAgaWYoc2VsZi5ndWVzc1BvaW50RGlzcGxheS5zdHJpbmcgPT0gXCLkuIfog71cIil7XHJcbiAgICAgICAgICAgIGEgPSAxMjsgICAgICBcclxuICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgYSA9IHBhcnNlSW50KHNlbGYuZ3Vlc3NQb2ludERpc3BsYXkuc3RyaW5nKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgYS0tO1xyXG4gICAgICAgIGlmKGE8PTApe1xyXG4gICAgICAgICAgIGE9IDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKGE+PTEyKXtcclxuICAgICAgICAgICBhID0gMTI7IFxyXG4gICAgICAgIH1cclxuICAgICAgICBzZWxmLmd1ZXNzX3BvaW50ID0gYTtcclxuICAgICAgICBpZihhID09IDEyKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgIHNlbGYuZ3Vlc3NQb2ludERpc3BsYXkuc3RyaW5nID0gXCLkuIfog71cIjsgIFxyXG4gICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgc2VsZi5ndWVzc1BvaW50RGlzcGxheS5zdHJpbmcgPSBhLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgfSAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIC8v54K55Ye75o+S54mM5rWu5qGG5LiK55qE5YeP5Y+36ZSu77yM5YeP5bCR5o+S54mM5L2N572uXHJcbiAgICBSZWR1Y2VJbnNlcnROdW06ZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgdmFyIGEgPSA3O1xyXG4gICAgICAgIGEgPSBwYXJzZUludChzZWxmLmluc2VydF9yYW5kb21EaXNwbGF5LnN0cmluZyk7XHJcbiAgICAgICAgYS0tO1xyXG4gICAgICAgIGlmKGE8PTEpe1xyXG4gICAgICAgICAgIGE9IDE7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKGE+PTExKXtcclxuICAgICAgICAgICBhID0gMTE7IFxyXG4gICAgICAgIH1cclxuICAgICAgICBzZWxmLnJhbmRvbV9wb2ludCA9IGE7XHJcbiAgICAgICAgc2VsZi5pbnNlcnRfcmFuZG9tRGlzcGxheS5zdHJpbmcgPSBhLnRvU3RyaW5nKCk7ICBcclxuICAgIH0sXHJcblxyXG4gICAgLy/mmI7niYzmlYjmnpxcclxuICAgIE1pbmdCcmFuZzpmdW5jdGlvbihzZWF0LGNhcmRkYXRhLHBvcyl7XHJcbiAgICAgICAgdmFyIHNlbGY9dGhpcztcclxuICAgICAgICBpZihzZWF0PT09dXNlcmRhdGEubXNlYXQpe1xyXG4gICAgICAgICAgICAvLyB2YXIgc3M9Y2MubG9hZGVyLnJlbW92ZUl0ZW0oY2FyZGRhdGEucG9pbnQpO1xyXG4gICAgICAgICAgICAvLyBzZWxmLm15SG9sZHMuY2hpbGRyZW5bcG9zLTFdLnJ1bkFjdGlvbihzcyk7XHJcbiAgICAgICAgICAgIHZhciB0YWc9c2VsZi5teUhvbGRzLmNoaWxkcmVuW3Bvcy0xXS5nZXRDaGlsZEJ5TmFtZShcIk1pbmdUYWdcIik7XHJcbiAgICAgICAgICAgIHRhZy5hY3RpdmU9dHJ1ZTtcclxuICAgICAgICB9ZWxzZSBpZihzZWF0ID09PSB1c2VyZGF0YS5yc2VhdCl7XHJcbiAgICAgICAgICAgICAgICB2YXIgc3ByaXRlID0gc2VsZi5yaWdodEhvbGRzLmNoaWxkcmVuW3Bvcy0xXS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcclxuICAgICAgICAgICAgICAgIGNjLmxvZyhcIlJfXCIrY2FyZGRhdGEuc3VpdCtcIl9cIitjYXJkZGF0YS5wb2ludCk7XHJcbiAgICAgICAgICAgICAgICBzZWxmLlNldFNwcml0ZUZyYW1lQnlDYXJkSUQoXCJSX1wiLGNhcmRkYXRhLnN1aXQsY2FyZGRhdGEucG9pbnQsc3ByaXRlKTtcclxuICAgICAgICAgICAgICAgIHZhciB0YWc9c2VsZi5yaWdodEhvbGRzLmNoaWxkcmVuW3Bvcy0xXS5nZXRDaGlsZEJ5TmFtZShcIk1pbmdUYWdcIik7XHJcbiAgICAgICAgICAgICAgICB0YWcuYWN0aXZlPXRydWU7XHJcbiAgICAgICAgfWVsc2UgaWYoc2VhdCA9PT11c2VyZGF0YS5vc2VhdCl7XHJcbiAgICAgICAgICAgICAgICB2YXIgc3ByaXRlID0gc2VsZi5vcHBvc2l0ZUhvbGRzLmNoaWxkcmVuW3Bvcy0xXS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcclxuICAgICAgICAgICAgICAgIGNjLmxvZyhcIk9fXCIrY2FyZGRhdGEuc3VpdCtcIl9cIitjYXJkZGF0YS5wb2ludCk7XHJcbiAgICAgICAgICAgICAgICBzZWxmLlNldFNwcml0ZUZyYW1lQnlDYXJkSUQoXCJPX1wiLGNhcmRkYXRhLnN1aXQsY2FyZGRhdGEucG9pbnQsc3ByaXRlKTtcclxuICAgICAgICAgICAgICAgIHZhciB0YWc9c2VsZi5vcHBvc2l0ZUhvbGRzLmNoaWxkcmVuW3Bvcy0xXS5nZXRDaGlsZEJ5TmFtZShcIk1pbmdUYWdcIik7XHJcbiAgICAgICAgICAgICAgICB0YWcuYWN0aXZlPXRydWU7XHJcbiAgICAgICAgfWVsc2UgaWYoc2VhdCA9PT0gdXNlcmRhdGEubHNlYXQpe1xyXG4gICAgICAgICAgICAgICAgdmFyIHNwcml0ZSA9IHNlbGYubGVmdEhvbGRzLmNoaWxkcmVuW3Bvcy0xXS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcclxuICAgICAgICAgICAgICAgIGNjLmxvZyhcIkxfXCIrY2FyZGRhdGEuc3VpdCtcIl9cIitjYXJkZGF0YS5wb2ludCk7XHJcbiAgICAgICAgICAgICAgICBzZWxmLlNldFNwcml0ZUZyYW1lQnlDYXJkSUQoXCJMX1wiLGNhcmRkYXRhLnN1aXQsY2FyZGRhdGEucG9pbnQsc3ByaXRlKTtcclxuICAgICAgICAgICAgICAgIHZhciB0YWc9c2VsZi5sZWZ0SG9sZHMuY2hpbGRyZW5bcG9zLTFdLmdldENoaWxkQnlOYW1lKFwiTWluZ1RhZ1wiKTtcclxuICAgICAgICAgICAgICAgIHRhZy5hY3RpdmU9dHJ1ZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvL+iOt+WPluiiq+eMnOeJjOS6uueahOW6p+S9jVxyXG4gICAgR2V0R3Vlc3NlZG1hbjpmdW5jdGlvbihub2RlKXtcclxuICAgICAgICB2YXIgc2VsZj10aGlzO1xyXG4gICAgICAgIGlmKG5vZGUucGFyZW50ID09PSBzZWxmLnJpZ2h0SG9sZHMpe1xyXG4gICAgICAgICAgICB1c2VyZGF0YS5ndWVzc2VkbWFuID0gdXNlcmRhdGEucnNlYXQ7XHJcbiAgICAgICAgfWVsc2UgaWYobm9kZS5wYXJlbnQgPT09c2VsZi5vcHBvc2l0ZUhvbGRzKXtcclxuICAgICAgICAgICAgICAgIHVzZXJkYXRhLmd1ZXNzZWRtYW4gPSB1c2VyZGF0YS5vc2VhdDtcclxuICAgICAgICB9ZWxzZSBpZihub2RlLnBhcmVudCA9PT0gc2VsZi5sZWZ0SG9sZHMpe1xyXG4gICAgICAgICAgICAgICAgdXNlcmRhdGEuZ3Vlc3NlZG1hbiA9IHVzZXJkYXRhLmxzZWF0O1xyXG4gICAgICAgIH0gICAgICAgIFxyXG4gICAgfSxcclxuICAgIFxyXG4gICAgLy/kuqTmjaLniYznmoTkvY3nva7lkozkv6Hmga9cclxuICAgIEV4Y2hhbmdlQ2FyZDE6ZnVuY3Rpb24obm9kZTEsbm9kZTIpe1xyXG4gICAgICAgIHZhciBtb3ZlMj1jYy5tb3ZlVG8oMC4yLGNjLnAobm9kZTIuZ2V0UG9zaXRpb25YKCksbm9kZTIuZ2V0UG9zaXRpb25ZKCkpKTtcclxuICAgICAgICBub2RlMS5ydW5BY3Rpb24obW92ZTIpOyAgICBcclxuICAgIH0sXHJcbiAgICBFeGNoYW5nZUNhcmQyOmZ1bmN0aW9uKG5vZGUxLG5vZGUyKXtcclxuICAgICAgICB2YXIgbW92ZTE9Y2MubW92ZVRvKDAuMixjYy5wKG5vZGUyLmdldFBvc2l0aW9uWCgpLG5vZGUyLmdldFBvc2l0aW9uWSgpKSk7XHJcbiAgICAgICAgdmFyIG1vdmUyPWNjLm1vdmVUbygwLjIsY2MucChub2RlMS5nZXRQb3NpdGlvblgoKSxub2RlMS5nZXRQb3NpdGlvblkoKSkpO1xyXG4gICAgICAgIG5vZGUxLnJ1bkFjdGlvbihtb3ZlMSk7IFxyXG4gICAgICAgIG5vZGUyLnJ1bkFjdGlvbihtb3ZlMik7ICAgIFxyXG4gICAgfSxcclxuICAgIEV4Y2hhbmdlSW5kZXg6ZnVuY3Rpb24oaG9sZHMsY2FyZHNMZW5ndGgscG9zaSl7XHJcbiAgICAgICAgICAgIGZvcih2YXIgaSA9IGNhcmRzTGVuZ3RoO2kgPiBwb3NpOyBpLS0pe1xyXG4gICAgICAgICAgICAgICAgW2hvbGRzLmNoaWxkcmVuW2ktMV0saG9sZHMuY2hpbGRyZW5baS0yXV09W2hvbGRzLmNoaWxkcmVuW2ktMl0saG9sZHMuY2hpbGRyZW5baS0xXV07XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIFVwZGF0ZUNhcmRzSW5mbzpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICAvL+WmguaenOW9k+WJjeWuouaIt+err+eOqeWutuaYr+aRuOeJjOaWuVxyXG4gICAgICAgIGlmKHVzZXJkYXRhLm1zZWF0ID09PSB1c2VyZGF0YS5mdHBsYXllcil7XHJcbiAgICAgICAgICAgIGZvcih2YXIgaT0wO2k8dXNlcmRhdGEubWNhcmQuc2l6ZTsrK2kpe1xyXG4gICAgICAgICAgICAgICAgc2VsZi5teUNhcmRzW2ldID0gdXNlcmRhdGEubWNhcmQuZ2V0KGkpO1xyXG4gICAgICAgICAgICAgICAgdmFyIHNwcml0ZSA9IHNlbGYubXlIb2xkcy5jaGlsZHJlbltpXS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcclxuICAgICAgICAgICAgICAgIHNlbGYuR3Vlc3NDYXJkcyhzcHJpdGUubm9kZSk7Ly9cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1lbHNlIGlmKHVzZXJkYXRhLnJzZWF0ID09PSB1c2VyZGF0YS5mdHBsYXllcil7ICBcclxuICAgICAgICAgICAgZm9yKHZhciBpPTA7aTx1c2VyZGF0YS5yY2FyZC5zaXplOysraSl7XHJcbiAgICAgICAgICAgICAgICBzZWxmLnJpZ2h0Q2FyZHNbaV0gPSB1c2VyZGF0YS5yY2FyZC5nZXQoaSk7XHJcbiAgICAgICAgICAgICAgICB2YXIgc3ByaXRlID0gc2VsZi5yaWdodEhvbGRzLmNoaWxkcmVuW2ldLmdldENvbXBvbmVudChjYy5TcHJpdGUpO1xyXG4gICAgICAgICAgICAgICAgc2VsZi5HdWVzc0NhcmRzKHNwcml0ZS5ub2RlKTsvL1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfWVsc2UgaWYodXNlcmRhdGEub3NlYXQgPT09IHVzZXJkYXRhLmZ0cGxheWVyKXsgICAgICBcclxuICAgICAgICAgICAgZm9yKHZhciBpPTA7aTx1c2VyZGF0YS5vY2FyZC5zaXplOysraSl7XHJcbiAgICAgICAgICAgICAgICBzZWxmLm9wcG9zaXRlQ2FyZHNbaV0gPSB1c2VyZGF0YS5vY2FyZC5nZXQoaSk7XHJcbiAgICAgICAgICAgICAgICB2YXIgc3ByaXRlID0gc2VsZi5vcHBvc2l0ZUhvbGRzLmNoaWxkcmVuW2ldLmdldENvbXBvbmVudChjYy5TcHJpdGUpO1xyXG4gICAgICAgICAgICAgICAgc2VsZi5HdWVzc0NhcmRzKHNwcml0ZS5ub2RlKTsvLyAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1lbHNlIGlmKHVzZXJkYXRhLmxzZWF0ID09PSB1c2VyZGF0YS5mdHBsYXllcil7ICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIGZvcih2YXIgaT0wO2k8dXNlcmRhdGEubGNhcmQuc2l6ZTsrK2kpe1xyXG4gICAgICAgICAgICAgICAgc2VsZi5sZWZ0Q2FyZHNbaV0gPSB1c2VyZGF0YS5sY2FyZC5nZXQoaSk7XHJcbiAgICAgICAgICAgICAgICB2YXIgc3ByaXRlID0gc2VsZi5sZWZ0SG9sZHMuY2hpbGRyZW5baV0uZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSk7XHJcbiAgICAgICAgICAgICAgICBzZWxmLkd1ZXNzQ2FyZHMoc3ByaXRlLm5vZGUpOy8vIFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgfSxcclxuXHJcbiAgICAvL+eMnOeJjOaIkOWKn+WQju+8jOW7tui/nzLnp5LlvLnlh7rmmK/lkKbnu6fnu63njJzniYznmoTlvLnmoYZcclxuICAgIENvbnRpbnVlUGxheTpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICAgICAgICAgIHNlbGYuY29udGludWUuYWN0aXZlID0gdHJ1ZTsvL+iuqeWQpue7p+e7reeMnOeJjOeahOW8ueWHuueOsFxyXG4gICAgICAgICAgICAgICAgc2VsZi5jb250aW51ZWJnLm9uKCd0b3VjaHN0YXJ0Jywgc2VsZi5FYXRUb3VjaCwgc2VsZik7Ly/op6bmkbjlkJ7lmawgIFxyXG4gICAgICAgIFxyXG4gICAgfSxcclxuICAgIENvbnRpbnVlQ29uZmlybTpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBjYy5sb2coXCLnu6fnu63njJzniYxcIik7XHJcbiAgICAgICAgLy/mmK/lkKbnu6fnu63njJzniYwgICAgICBcclxuICAgICAgICB2YXIgY29udGVudCA9IEpTT04uc3RyaW5naWZ5KHtUeXBlOjEwMDI2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvQ29udGludWU6dHJ1ZSwgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgY29udGVudCA9IEpTT04ucGFyc2UoY29udGVudCk7XHJcbiAgICAgICAgLy/liqDkuIrlrqLmiLfnq69zZXNzaW9u5Y+3aWRcclxuICAgICAgICB2YXIgY29udGludWVfc2RtZXMgPSBKU09OLnN0cmluZ2lmeSh7SWQ6dXNlcmRhdGEuaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ29udGVudDpjb250ZW50LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGNvbnRpbnVlX3NkbWVzID0gXCJtc2c9XCIrY29udGludWVfc2RtZXM7XHJcbiAgICAgICAgY2MubG9nKFwi5Y+R6YCB57un57ut54yc54mM6K+35rGC5L+h5oGv77yaXCIrY29udGludWVfc2RtZXMpO1xyXG4gICAgICAgIGh0dHAuSHR0cFBvc3Qoc2VsZi51cmwsY29udGludWVfc2RtZXMsZnVuY3Rpb24oY29udGludWVfcnZtZXMpe1xyXG4gICAgICAgICAgICBpZiAoY29udGludWVfcnZtZXMgPT09IC0xKSB7XHJcbiAgICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwi6K+35qOA5p+l572R57ucXCIpO1xyXG4gICAgICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICAgIHZhciBydj1KU09OLnBhcnNlKGNvbnRpbnVlX3J2bWVzKTtcclxuICAgICAgICAgICAgICAgIGlmKHJ2LlR5cGU9PT0xMDAyOSl7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKHJ2KTtcclxuICAgICAgICAgICAgICAgICAgICBzZWxmLnN0ZXBDb3VudCA9IDIxO1xyXG4gICAgICAgICAgICAgICAgICAgIHNlbGYuY29udGludWUuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgfSxcclxuICAgIFxyXG4gICAgQ29udGludWVDb25jZWw6ZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgY2MubG9nKFwi5LiN57un57ut54yc54mMXCIpO1xyXG4gICAgICAgIC8v5piv5ZCm57un57ut54yc54mMICAgICAgXHJcbiAgICAgICAgdmFyIGNvbnRlbnQgPSBKU09OLnN0cmluZ2lmeSh7VHlwZToxMDAyNixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb0NvbnRpbnVlOmZhbHNlLCAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICB9KTtcclxuICAgICAgICBjb250ZW50ID0gSlNPTi5wYXJzZShjb250ZW50KTtcclxuICAgICAgICAvL+WKoOS4iuWuouaIt+err3Nlc3Npb27lj7dpZFxyXG4gICAgICAgIHZhciBub2NvbnRpbnVlX3NkbWVzID0gSlNPTi5zdHJpbmdpZnkoe0lkOnVzZXJkYXRhLmlkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENvbnRlbnQ6Y29udGVudCxcclxuICAgICAgICB9KTtcclxuICAgICAgICAgbm9jb250aW51ZV9zZG1lcyA9IFwibXNnPVwiK25vY29udGludWVfc2RtZXM7XHJcbiAgICAgICAgY2MubG9nKFwi5Y+R6YCB5LiN57un57ut54yc54mM6K+35rGC5L+h5oGv77yaXCIrbm9jb250aW51ZV9zZG1lcyk7XHJcbiAgICAgICAgaHR0cC5IdHRwUG9zdChzZWxmLnVybCxub2NvbnRpbnVlX3NkbWVzLGZ1bmN0aW9uKG5vY29udGludWVfcnZtZXMpe1xyXG4gICAgICAgICAgICBpZiAobm9jb250aW51ZV9ydm1lcyA9PT0gLTEpIHtcclxuICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCLor7fmo4Dmn6XnvZHnu5xcIik7XHJcbiAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgc2VsZi5jb250aW51ZS5hY3RpdmUgPSBmYWxzZTsvL+iuqeWQpue7p+e7reeMnOeJjOeahOW8ueahhua2iOWksVxyXG4gICAgICAgICAgICAgICAgdmFyIHJ2PUpTT04ucGFyc2Uobm9jb250aW51ZV9ydm1lcyk7XHJcbiAgICAgICAgICAgICAgICBjYy5sb2cocnYpO1xyXG4gICAgICAgICAgICAgICAgaWYocnYuVHlwZT09PTEwMDMwKXtcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCLnjqnlrrbmlL7lvIPnu6fnu63njJzniYxcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuUm91bmRDaGFuZ2UoKTtcclxuICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICB9LFxyXG5cclxuICAgIC8v6L2u6K+i54yc54mM5pe25pS25Yiw5pyN5Yqh5Zmo5Y+R6YCB55qEMTAwMzXvvIzliJnkuIDkuKrnjqnlrrbog5zliKnvvIzlhbbkvZnnjqnlrrbmiYvniYzooqvnjJzlrozvvIzmuLjmiI/nu5PmnZ9cclxuICAgIEdhbWVPdmVyOmZ1bmN0aW9uKHJ2bWVzKXtcclxuICAgICAgICB2YXIgc2VsZiAgPSB0aGlzO1xyXG4gICAgICAgIHNlbGYuZ2FtZW92ZXIuYWN0aXZlID0gdHJ1ZTsgICAgICBcclxuICAgICAgICBjYy5sb2codXNlcmRhdGEuZ3Vlc3NlZGNhcmQpO1xyXG4gICAgICAgIHNlbGYuTWluZ0JyYW5nKHVzZXJkYXRhLmd1ZXNzZWRtYW4sdXNlcmRhdGEuZ3Vlc3NlZGNhcmQsdXNlcmRhdGEuZ3Vlc3NlZGNhcmQucG9zaSk7Ly/lsIbmnIDlkI7kuIDlvKDnjJznmoTniYzmmI7niYxcclxuXHJcbiAgICAgICAgZm9yKHZhciBpID0gMDtpPHJ2bWVzLkhhbmRzLmxlbmd0aDtpKyspe1xyXG4gICAgICAgICAgICBpZih1c2VyZGF0YS53aW5uZXJfc2VhdCA9PT0gdXNlcmRhdGEubXNlYXQpe1xyXG4gICAgICAgICAgICAgc2VsZi5NaW5nQnJhbmcodXNlcmRhdGEud2lubmVyX3NlYXQsdXNlcmRhdGEubWNhcmQuZ2V0KGkpLHVzZXJkYXRhLm1jYXJkLmdldChpKS5wb3NpKTsvL+WwhuiDnOWIqeiAheeahOeJjOaYjueJjFxyXG4gICAgICAgICAgICB9ZWxzZSBpZih1c2VyZGF0YS53aW5uZXJfc2VhdCA9PT0gdXNlcmRhdGEucnNlYXQpe1xyXG4gICAgICAgICAgICBzZWxmLk1pbmdCcmFuZyh1c2VyZGF0YS53aW5uZXJfc2VhdCx1c2VyZGF0YS5yY2FyZC5nZXQoaSksdXNlcmRhdGEucmNhcmQuZ2V0KGkpLnBvc2kpOy8v5bCG6IOc5Yip6ICF55qE54mM5piO54mMXHJcbiAgICAgICAgICAgIH1lbHNlIGlmKHVzZXJkYXRhLndpbm5lcl9zZWF0ID09PSB1c2VyZGF0YS5vc2VhdCl7XHJcbiAgICAgICAgICAgIHNlbGYuTWluZ0JyYW5nKHVzZXJkYXRhLndpbm5lcl9zZWF0LHVzZXJkYXRhLm9jYXJkLmdldChpKSx1c2VyZGF0YS5vY2FyZC5nZXQoaSkucG9zaSk7Ly/lsIbog5zliKnogIXnmoTniYzmmI7niYxcclxuICAgICAgICAgICAgfWVsc2UgaWYodXNlcmRhdGEud2lubmVyX3NlYXQgPT09IHVzZXJkYXRhLmxzZWF0KXtcclxuICAgICAgICAgICAgc2VsZi5NaW5nQnJhbmcodXNlcmRhdGEud2lubmVyX3NlYXQsdXNlcmRhdGEubGNhcmQuZ2V0KGkpLHVzZXJkYXRhLmxjYXJkLmdldChpKS5wb3NpKTsvL+WwhuiDnOWIqeiAheeahOeJjOaYjueJjFxyXG4gICAgICAgIH0gICBcclxuICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYodXNlcmRhdGEud2lubmVyX3NlYXQgPT09IHVzZXJkYXRhLm1zZWF0KXtcclxuICAgICAgICAgICAgY2MubG9nKHVzZXJkYXRhLm1jYXJkKTtcclxuICAgICAgICB9ZWxzZSBpZih1c2VyZGF0YS53aW5uZXJfc2VhdCA9PT0gdXNlcmRhdGEucnNlYXQpe1xyXG4gICAgICAgICAgICBjYy5sb2codXNlcmRhdGEucmNhcmQpO1xyXG4gICAgICAgIH1lbHNlIGlmKHVzZXJkYXRhLndpbm5lcl9zZWF0ID09PSB1c2VyZGF0YS5vc2VhdCl7XHJcbiAgICAgICAgICAgIGNjLmxvZyh1c2VyZGF0YS5vY2FyZCk7XHJcbiAgICAgICAgfWVsc2UgaWYodXNlcmRhdGEud2lubmVyX3NlYXQgPT09IHVzZXJkYXRhLmxzZWF0KXtcclxuICAgICAgICAgICAgY2MubG9nKHVzZXJkYXRhLmxjYXJkKTtcclxuICAgICAgICB9ICAgICAgIFxyXG5cclxuICAgICAgICBzZWxmLmdhbWVvdmVyYmcub24oJ3RvdWNoc3RhcnQnLCBzZWxmLkVhdFRvdWNoLCBzZWxmKTsvL+inpuaRuOWQnuWZrFxyXG4gICAgICAgIGlmKHJ2bWVzLlNXaW5uZXIgPT0gdXNlcmRhdGEubXNlYXQpe1xyXG4gICAgICAgICAgICBzZWxmLmdhbWVSZXN1bHREaXNwbGF5LnN0cmluZyA9IFwi5pys5pa56IOc5Yip77yB5YaN5o6l5YaN5Y6J77yBXCI7XHJcbiAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgIHNlbGYuZ2FtZVJlc3VsdERpc3BsYXkuc3RyaW5nID0gXCLmuLjmiI/lpLHotKXvvIHog5zliKnogIXmmK/vvJpcIitydm1lcy5QV2lubmVyO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgIH0sXHJcblxyXG5cclxuICAgIC8v5q2l5pe25YCS6K6h5pe2XHJcbiAgICBVcGRhdGVMZWZ0VGltZTpmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgICBzZWxmLnN0ZXBDb3VudExhYmVsLnN0cmluZyA9IFwiMjBcIjtcclxuICAgICAgICBzZWxmLnNjaGVkdWxlKGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgICAgICBzZWxmLnN0ZXBDb3VudC0tO1xyXG4gICAgICAgICAgICAgICAgaWYoc2VsZi5zdGVwQ291bnQ8PTApe1xyXG4gICAgICAgICAgICAgICAgICAgLy9zZWxmLkd1ZXNzVGltZU91dCgpO1xyXG4gICAgICAgICAgICAgICAgICAgc2VsZi5zdGVwQ291bnRMYWJlbC5zdHJpbmcgPSBcIjBcIjtcclxuICAgICAgICAgICAgICAgICAgIGlmKHNlbGYuc3RlcENvdW50ID09MCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5HdWVzc1RpbWVPdXQoKTtcclxuICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgICAgIHNlbGYuc3RlcENvdW50TGFiZWwuc3RyaW5nID0gc2VsZi5zdGVwQ291bnQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sMSk7XHJcbiAgICB9LFxyXG5cclxuICAgIC8v54yc54mM6LaF5pe2XHJcbiAgICBHdWVzc1RpbWVPdXQ6ZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgaWYoc2VsZi5zdGVwQ291bnQ8PTApeyAgICAgIFxyXG4gICAgICAgICAgICBpZih1c2VyZGF0YS5mdHBsYXllciA9PSB1c2VyZGF0YS5tc2VhdCl7XHJcbiAgICAgICAgICAgICAgICBjYy5sb2coXCLmnKzmlrnotoXml7YyXCIpO1xyXG4gICAgICAgICAgICAgICAgc2VsZi5pbnNlcnRfcmFuZG9tLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgaWYodXNlcmRhdGEucmVzdGNhcmQgPT0gZmFsc2Upey8v5aaC5p6c54mM5aCG5peg54mMXHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwiMzMzMzMzMzMzMzMzM+eJjOWghuaXoOeJjOi2heaXtlwiKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHNlbGYuUmVzdWx0RXBvbGwodHJ1ZSk7XHJcbiAgICAgICAgICAgIH0gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvL+ehruWumuW9k+WJjeeMnOeJjOaWueeureWktOaMh+WQkeiwgVxyXG4gICAgR3Vlc3NUdXJuOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIGlmKHVzZXJkYXRhLmZ0cGxheWVyID09IHVzZXJkYXRhLm1zZWF0KXtcclxuICAgICAgICAgICAgc2VsZi5teVR1cm4uYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgc2VsZi5yaWdodFR1cm4uYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHNlbGYub3Bwb3NpdGVUdXJuLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICBzZWxmLmxlZnRUdXJuLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIH1lbHNlIGlmKHVzZXJkYXRhLmZ0cGxheWVyID09IHVzZXJkYXRhLnJzZWF0KXtcclxuICAgICAgICAgICAgc2VsZi5teVR1cm4uYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHNlbGYucmlnaHRUdXJuLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgIHNlbGYub3Bwb3NpdGVUdXJuLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICBzZWxmLmxlZnRUdXJuLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIH1lbHNlIGlmKHVzZXJkYXRhLmZ0cGxheWVyID09IHVzZXJkYXRhLm9zZWF0KXtcclxuICAgICAgICAgICAgc2VsZi5teVR1cm4uYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHNlbGYucmlnaHRUdXJuLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICBzZWxmLm9wcG9zaXRlVHVybi5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICBzZWxmLmxlZnRUdXJuLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIH1lbHNlIGlmKHVzZXJkYXRhLmZ0cGxheWVyID09IHVzZXJkYXRhLmxzZWF0KXtcclxuICAgICAgICAgICAgc2VsZi5teVR1cm4uYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHNlbGYucmlnaHRUdXJuLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICBzZWxmLm9wcG9zaXRlVHVybi5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgc2VsZi5sZWZ0VHVybi5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy/kuIfog73niYzlh7rnjrBcclxuICAgIFJhbmRvbUFwcGVhcjpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBzZWxmLmluc2VydF9yYW5kb20uYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICBpZihzZWxmLmluc2VydF9yYW5kb20uYWN0aXZlPT10cnVlKXtcclxuICAgICAgICAgICAgc2VsZi5pbnNlcnRfcmFuZG9tRGlzcGxheS5zdHJpbmcgPSBcIjdcIjtcclxuICAgICAgICAgICAgc2VsZi5yYW5kb21fcG9pbnQgPSA3O1xyXG4gICAgICAgICAgICBzZWxmLmluc2VydF9yYW5kb21iZy5vbigndG91Y2hzdGFydCcsIHNlbGYuRWF0VG91Y2gsIHNlbGYpOy8v6Kem5pG45ZCe5ZmsXHJcbiAgICAgICAgICAgIH1cclxuICAgIH0sXHJcblxyXG5cclxuICAgIC8v56Gu5a6a5YGH5a6a55qE5LiH6IO954mM54K55pWwXHJcbiAgICBSYW5kb21Db25maXJtOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIGNjLmxvZyhcIuehruWumuS4h+iDveeJjOWBh+WumueCueaVsFwiKTtcclxuICAgICAgICB2YXIgY29udGVudCA9IEpTT04uc3RyaW5naWZ5KHtUeXBlOjEwMDQxLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNpbVBvaW50OnNlbGYucmFuZG9tX3BvaW50LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFN1aXQ6c2VsZi5yYW5kb21fc3VpdCAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGNvbnRlbnQgPSBKU09OLnBhcnNlKGNvbnRlbnQpO1xyXG4gICAgICAgIC8v5Yqg5LiK5a6i5oi356uvc2Vzc2lvbuWPt2lkXHJcbiAgICAgICAgdmFyIHJhbmRvbV9zZG1lcyA9IEpTT04uc3RyaW5naWZ5KHtJZDp1c2VyZGF0YS5pZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENvbnRlbnQ6Y29udGVudCxcclxuICAgICAgICB9KTtcclxuICAgICAgICAgcmFuZG9tX3NkbWVzID0gXCJtc2c9XCIrcmFuZG9tX3NkbWVzO1xyXG4gICAgICAgIGNjLmxvZyhcIuWPkemAgeS4h+iDveeJjOWBh+WumueCueaVsOS/oeaBr++8mlwiK3JhbmRvbV9zZG1lcyk7XHJcbiAgICAgICAgaHR0cC5IdHRwUG9zdChzZWxmLnVybCxyYW5kb21fc2RtZXMsZnVuY3Rpb24ocmFuZG9tX3J2bWVzKXtcclxuICAgICAgICAgICAgaWYgKHJhbmRvbV9ydm1lcyA9PT0gLTEpIHtcclxuICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCLor7fmo4Dmn6XnvZHnu5xcIik7XHJcbiAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgdmFyIHJ2PUpTT04ucGFyc2UocmFuZG9tX3J2bWVzKTtcclxuICAgICAgICAgICAgICAgIGNjLmxvZyhcIuaUtuWIsOS4h+iDveeJjOi/lOWbnuS/oeaBrzpcIityYW5kb21fcnZtZXMpOyBcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgICBzZWxmLmluc2VydF9yYW5kb20uYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIC8v5aaC5p6c5pG45b6X54mM5piv5LiH6IO954mM77yM6KaB5ZyobWFw5Lit5pS55Y+Y5YW2cG9zaVxyXG4gICAgQ2hhbmdlUmFuZG9tUG9zaTpmdW5jdGlvbihydil7XHJcbiAgICAgICAgLy/lpoLmnpzmkbjniYzkurrmmK/mnKzmlrlcclxuICAgICAgICBpZihydi5HdWVzc1NlYXQgPT0gdXNlcmRhdGEubXNlYXQpe1xyXG4gICAgICAgICAgICB2YXIgY2FyZGxlbmd0aCA9IHVzZXJkYXRhLm1jYXJkLnNpemU7XHJcbiAgICAgICAgICAgIGNjLmxvZyhcImNhcmRsZW5ndGg6XCIrY2FyZGxlbmd0aCk7XHJcbiAgICAgICAgICAgIGNjLmxvZyhcIuaUueWPmHBvc2nliY3vvJpcIit1c2VyZGF0YS5tY2FyZC5nZXQoY2FyZGxlbmd0aC0xKS5wb3NpKTtcclxuICAgICAgICAgICAgY2MubG9nKFwi5pS55Y+YcG9zaeWQju+8mlwiKyBydi5UY2FyZC5Qb3NpdGlvbik7XHJcbiAgICAgICAgICAgIHVzZXJkYXRhLm1jYXJkLmdldChjYXJkbGVuZ3RoLTEpLnBvc2kgPSBydi5UY2FyZC5Qb3NpdGlvbjtcclxuICAgICAgICB9ZWxzZSBpZihydi5HdWVzc1NlYXQgPT0gdXNlcmRhdGEucnNlYXQpe1xyXG4gICAgICAgICAgICB2YXIgY2FyZGxlbmd0aCA9IHVzZXJkYXRhLnJjYXJkLnNpemU7XHJcbiAgICAgICAgICAgIGNjLmxvZyhcImNhcmRsZW5ndGg6XCIrY2FyZGxlbmd0aCk7XHJcbiAgICAgICAgICAgIGNjLmxvZyhcIuaUueWPmHBvc2nliY3vvJpcIit1c2VyZGF0YS5yY2FyZC5nZXQoY2FyZGxlbmd0aC0xKS5wb3NpKTtcclxuICAgICAgICAgICAgY2MubG9nKFwi5pS55Y+YcG9zaeWQju+8mlwiKyBydi5UY2FyZC5Qb3NpdGlvbik7XHJcbiAgICAgICAgICAgIHVzZXJkYXRhLnJjYXJkLmdldChjYXJkbGVuZ3RoLTEpLnBvc2kgPSBydi5UY2FyZC5Qb3NpdGlvbjtcclxuICAgICAgICB9ZWxzZSBpZihydi5HdWVzc1NlYXQgPT0gdXNlcmRhdGEub3NlYXQpe1xyXG4gICAgICAgICAgICB2YXIgY2FyZGxlbmd0aCA9IHVzZXJkYXRhLm9jYXJkLnNpemU7XHJcbiAgICAgICAgICAgIGNjLmxvZyhcImNhcmRsZW5ndGg6XCIrY2FyZGxlbmd0aCk7XHJcbiAgICAgICAgICAgIGNjLmxvZyhcIuaUueWPmHBvc2nliY3vvJpcIit1c2VyZGF0YS5vY2FyZC5nZXQoY2FyZGxlbmd0aC0xKS5wb3NpKTtcclxuICAgICAgICAgICAgY2MubG9nKFwi5pS55Y+YcG9zaeWQju+8mlwiKyBydi5UY2FyZC5Qb3NpdGlvbik7XHJcbiAgICAgICAgICAgIHVzZXJkYXRhLm9jYXJkLmdldChjYXJkbGVuZ3RoLTEpLnBvc2kgPSBydi5UY2FyZC5Qb3NpdGlvbjtcclxuICAgICAgICB9ZWxzZSBpZihydi5HdWVzc1NlYXQgPT0gdXNlcmRhdGEubHNlYXQpe1xyXG4gICAgICAgICAgICB2YXIgY2FyZGxlbmd0aCA9IHVzZXJkYXRhLmxjYXJkLnNpemU7XHJcbiAgICAgICAgICAgIGNjLmxvZyhcImNhcmRsZW5ndGg6XCIrY2FyZGxlbmd0aCk7XHJcbiAgICAgICAgICAgIGNjLmxvZyhcIuaUueWPmHBvc2nliY3vvJpcIit1c2VyZGF0YS5sY2FyZC5nZXQoY2FyZGxlbmd0aC0xKS5wb3NpKTtcclxuICAgICAgICAgICAgY2MubG9nKFwi5pS55Y+YcG9zaeWQju+8mlwiKyBydi5UY2FyZC5Qb3NpdGlvbik7XHJcbiAgICAgICAgICAgIHVzZXJkYXRhLmxjYXJkLmdldChjYXJkbGVuZ3RoLTEpLnBvc2kgPSBydi5UY2FyZC5Qb3NpdGlvbjtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8v5pi+56S6546p5a625L+h5oGvXHJcbiAgICBTaG93UGxheWVySW5mbzpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICAvL+aYvuekuuWPs+aWueeOqeWutuS/oeaBryzmjInpobrluo/mmK/lpLTlg4/vvIznrYnnuqfvvIzlp5PlkI3vvIzph5HluIHvvIjnjrDlnKjlj6rmnInlp5PlkI3vvIlcclxuICAgICAgICB2YXIgcmlnaHRIZWFkSW1hZ2UgPSBzZWxmLnJpZ2h0SW5mby5nZXRDaGlsZEJ5TmFtZShcInBsYXllcl9oZWFkXCIpOy8v5aS05YOPXHJcbiAgICAgICAgdmFyIHJpZ2h0TGV2ZWwgPSBzZWxmLnJpZ2h0SW5mby5nZXRDaGlsZEJ5TmFtZShcImxldmVsXCIpOy8v562J57qnXHJcbiAgICAgICAgdmFyIHJpZ2h0TmFtZSA9IHNlbGYucmlnaHRJbmZvLmdldENoaWxkQnlOYW1lKFwibmFtZVwiKTsvL+Wnk+WQjVxyXG4gICAgICAgIHJpZ2h0TmFtZSA9IHJpZ2h0TmFtZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG4gICAgICAgIHZhciByaWdodFNjb3JlID0gc2VsZi5yaWdodEluZm8uZ2V0Q2hpbGRCeU5hbWUoXCJzY29yZVwiKTsvL+mHkeW4geaVsFxyXG5cclxuXHJcbiAgICAgICAgLy/mmL7npLrlr7npnaLnjqnlrrbkv6Hmga8s5oyJ6aG65bqP5piv5aS05YOP77yM562J57qn77yM5aeT5ZCN77yM6YeR5biB77yI546w5Zyo5Y+q5pyJ5aeT5ZCN77yJXHJcbiAgICAgICAgdmFyIG9wcG9zaXRlSGVhZEltYWdlID0gc2VsZi5vcHBvc2l0ZUluZm8uZ2V0Q2hpbGRCeU5hbWUoXCJwbGF5ZXJfaGVhZFwiKTsvL+WktOWDj1xyXG4gICAgICAgIHZhciBvcHBvc2l0ZUxldmVsID0gc2VsZi5vcHBvc2l0ZUluZm8uZ2V0Q2hpbGRCeU5hbWUoXCJsZXZlbFwiKTsvL+etiee6p1xyXG4gICAgICAgIHZhciBvcHBvc2l0ZU5hbWUgPSBzZWxmLm9wcG9zaXRlSW5mby5nZXRDaGlsZEJ5TmFtZShcIm5hbWVcIik7Ly/lp5PlkI1cclxuICAgICAgICBvcHBvc2l0ZU5hbWUgPSBvcHBvc2l0ZU5hbWUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuICAgICAgICB2YXIgb3Bwb3NpdGVTY29yZSA9IHNlbGYub3Bwb3NpdGVJbmZvLmdldENoaWxkQnlOYW1lKFwic2NvcmVcIik7Ly/ph5HluIHmlbBcclxuXHJcblxyXG5cclxuICAgICAgICAvL+aYvuekuuW3puaWueeOqeWutuS/oeaBryzmjInpobrluo/mmK/lpLTlg4/vvIznrYnnuqfvvIzlp5PlkI3vvIzph5HluIHvvIjnjrDlnKjlj6rmnInlp5PlkI3vvIlcclxuICAgICAgICB2YXIgbGVmdEhlYWRJbWFnZSA9IHNlbGYubGVmdEluZm8uZ2V0Q2hpbGRCeU5hbWUoXCJwbGF5ZXJfaGVhZFwiKTsvL+WktOWDj1xyXG4gICAgICAgIHZhciBsZWZ0TGV2ZWwgPSBzZWxmLmxlZnRJbmZvLmdldENoaWxkQnlOYW1lKFwibGV2ZWxcIik7Ly/nrYnnuqdcclxuICAgICAgICB2YXIgbGVmdE5hbWUgPSBzZWxmLmxlZnRJbmZvLmdldENoaWxkQnlOYW1lKFwibmFtZVwiKTsvL+Wnk+WQjVxyXG4gICAgICAgIGxlZnROYW1lID0gbGVmdE5hbWUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuICAgICAgICB2YXIgbGVmdFNjb3JlID0gc2VsZi5sZWZ0SW5mby5nZXRDaGlsZEJ5TmFtZShcInNjb3JlXCIpOy8v6YeR5biB5pWwXHJcblxyXG4gICAgICAgIGZvcih2YXIgaSA9MDsgaSA8IHNva2V0LnNlYXQubGVuZ3RoOyBpKyspe1xyXG4gICAgICAgICAgICBpZihzb2tldC5zZWF0W2ldID09IHVzZXJkYXRhLnJzZWF0KXtcclxuICAgICAgICAgICAgICAgIHJpZ2h0TmFtZS5zdHJpbmcgPSBzb2tldC5uYW1lW2ldO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmKHNva2V0LnNlYXRbaV0gPT0gdXNlcmRhdGEub3NlYXQpe1xyXG4gICAgICAgICAgICAgICAgb3Bwb3NpdGVOYW1lLnN0cmluZyA9IHNva2V0Lm5hbWVbaV07XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmKHNva2V0LnNlYXRbaV0gPT0gdXNlcmRhdGEubHNlYXQpe1xyXG4gICAgICAgICAgICAgICAgbGVmdE5hbWUuc3RyaW5nID0gc29rZXQubmFtZVtpXTtcclxuXHJcbiAgICAgICAgICAgIH0gICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy/nlLHnjqnlrrbluqfkvY3lj7flvpfliLDnm7jlupTnlKjmiLflkI1cclxuICAgIGdldE5hbWVCeVNlYXQ6ZnVuY3Rpb24oc2VhdCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIGZvcih2YXIgaSA9MDsgaSA8IHNva2V0LnNlYXQubGVuZ3RoOyBpKyspe1xyXG4gICAgICAgICAgICBpZihzb2tldC5zZWF0W2ldID09IHNlYXQpe1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHNva2V0Lm5hbWVbaV07XHJcbiAgICAgICAgICAgIH0gICAgICBcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICB1cGRhdGU6ZnVuY3Rpb24gKGR0KSB7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHNva2V0LmdldENoYXRNc2coKTsvL+ebkeWQrOiOt+WPluiBiuWkqeS/oeaBr1xyXG4gICAgICAgIHNlbGYuY2hhdExhYmVsLnN0cmluZyA9IHNva2V0LmNoYXRTdHJpbmc7Ly/mm7TmlrDogYrlpKnorrDlvZVcclxuICAgICAgICBzZWxmLmNoYXRDb250ZW50LmhlaWdodCA9IDQwMCArc29rZXQuY2hhdEhlaWdodEFkZCo2MDsvL+abtOaWsOiBiuWkqeahhumrmOW6plxyXG4gICAgICAgIHNlbGYubmV3c0xhYmVsLnN0cmluZyA9IHNlbGYubmV3c0hpc3Rvcnk7Ly/mm7TmlrDmuLjmiI/mtojmga/ljoblj7JcclxuICAgICAgICBzZWxmLm5ld3NDb250ZW50LmhlaWdodCA9IDQwMCArc2VsZi5uZXdzSGlzdG9yeUFkZCo2MDsvL+abtOaWsOa4uOaIj+a2iOaBr+WOhuWPsuahhumrmOW6plxyXG4gICAgICAgIHNlbGYuR3Vlc3NUdXJuKCk7Ly/mm7TmlrDmkbjniYznjqnlrrbmlrkgICAgXHJcbiAgICB9XHJcbn0pO1xyXG4iLCJ2YXIgaHR0cCA9IHJlcXVpcmUoXCJIdHRwVXRpbHNcIik7XHJcbnZhciBjYXJkID0gcmVxdWlyZShcIkNhcmRBY3Rpdml0eVwiKTtcclxudmFyIHVzZXJkYXRhID0gcmVxdWlyZShcIlVzZXJEYXRhXCIpO1xyXG52YXIgc29rZXQgPSByZXF1aXJlKFwiU29rZXRVdGlsc1wiKTtcclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBoZWxwX3VpOmNjLlByZWZhYixcclxuICAgICAgICBnYW1lX251bTp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5Ob2RlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgcGxheWVySUQ6bnVsbCxcclxuXHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICAvL+WImui/m+WFpea4uOaIj+Wkp+WOheWwseimgeeUs+ivt+eZu+mZhuWlveWPi+ezu+e7n1xyXG4gICAgICAgIHNlbGYuTG9naW5GcmllbmRTeXN0ZW0oKTtcclxuICAgIH0sXHJcbiAgICBcclxuICAgIC8v55Sz6K+355m76ZmG5aW95Y+L57O757ufXHJcbiAgICBMb2dpbkZyaWVuZFN5c3RlbTpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICB2YXIgIGNvbnRlbnQgPSBKU09OLnN0cmluZ2lmeSh7SWQ6dXNlcmRhdGEuaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUeXBlOjEwMDQxLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTmFtZTogdXNlcmRhdGEubW5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7ICAgICAgXHJcblxyXG4gICAgICAgIGNjLmxvZyhcIuWQkeWlveWPi+acjeWKoeWZqOWPkemAgeeUs+ivt+eZu+mZhua2iOaBr++8mlwiKTtcclxuICAgICAgICBjYy5sb2coSlNPTi5wYXJzZShjb250ZW50KSk7XHJcbiAgICAgICAgc29rZXQuY29ubmVjdCgpOy8v5bu656uLd2Vic29rZXTlr7nosaF3c1xyXG4gICAgICAgIHNva2V0LndzLm9ub3BlbiA9IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgICAgICAgc29rZXQuZ2V0Q2hhdE1zZygpO1xyXG4gICAgICAgICAgICAgICAgIHNva2V0LndzLnNlbmQoY29udGVudCk7Ly/lj5HpgIHmtojmga9cclxuICAgICAgICAgfTtcclxuICAgIH0sXHJcblxyXG4gICAgLy/ngrnlh7tiYWNrX3RvX2xvZ2lu5oyJ6ZKu77yM6L+U5Zue5Yiw55m76ZmG55WM6Z2iXHJcbiAgICBUb1dlbGNvbWVTY2VuZTogZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCdXZWxjb21lU2NlbmUnKVxyXG4gICAgfSxcclxuXHJcbiAgICAvL+eCueWHu21hdGNo5oyJ6ZKu77yM5ZCR5pyN5Yqh5Zmo5Y+R6YCB5ZG95Luk77yM5b+r6YCf5Yy56YWN5a+55omLXHJcbiAgICBGaW5kUGxheWVyOiBmdW5jdGlvbigpe1xyXG4gICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgIGh0dHAuaXNCYWNrVG9IYWxsID0gZmFsc2U7XHJcbiAgICAgIHZhciB1cmw9XCJodHRwOi8vMTkyLjE2OC4wLjIyOTo4MDgwL3Rlc3RcIjtcclxuICAgICAgdmFyIHBhcmFtczEgPSBKU09OLnN0cmluZ2lmeSh7SWQ6dXNlcmRhdGEuaWQgLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiQ29udGVudFwiOntcIlR5cGVcIjoxMDAwOCxcIlVpZFwiOlwiNjY2XCJ9fSk7XHJcbiAgICAgIHZhciBtc2cgPSBcIm1zZz1cIitwYXJhbXMxO1xyXG4gICAgICBjYy5sb2coXCLngrnlh7vlv6vpgJ/ljLnphY3mjInpkq7lj5HpgIHmtojmga/vvJpcIittc2cpO1xyXG4gICAgICBodHRwLkh0dHBQb3N0KHVybCwgbXNnICxmdW5jdGlvbiAocnZfbWVzKSB7ICBcclxuICAgICAgICAgICAgaWYgKHJ2X21lcyA9PT0gLTEpIHsgIFxyXG4gICAgICAgICAgICAgICAgY2MubG9nKCfor7fmo4Dmn6XnvZHnu5wnKTsgIFxyXG4gICAgICAgICAgICB9IGVsc2UgeyAgXHJcbiAgICAgICAgICAgICAgICBjYy5sb2coXCLov5Tlm57kv6Hmga/vvJpcIiArIHJ2X21lcyk7IFxyXG4gICAgICAgICAgICAgICAgcnZfbWVzID0gSlNPTi5wYXJzZShydl9tZXMpOyBcclxuICAgICAgICAgICAgICAgIGlmIChydl9tZXMuVHlwZSA9PT0gMTAwMTApIHsgIFxyXG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZygn5pyN5Yqh5Zmo5ouS57ud5byA5aeL6K+35rGC77yM5Yy56YWN6Zif5YiX5bey5ruhIO+8micrcnZfbWVzLlR5cGUpOyAgXHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYocnZfbWVzLlR5cGUgPT09IDEwMDA5KXtcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coJ+acjeWKoeWZqOaUtuWIsOW8gOWni+ivt+axgu+8jOi/m+WFpeWMuemFjemYn+WIlyDvvJonK3J2X21lcy5UeXBlKTtcclxuICAgICAgICAgICAgICAgICAgICBzZWxmLlBvbGxpbmcoKTtcclxuICAgICAgICAgICAgICAgIH0gICBcclxuICAgICAgICAgICAgfSBcclxuICAgICAgICB9KTtcclxuICAgIH0sXHJcbiAgICBcclxuICAgIC8v54K55Ye75biu5Yqp5oyJ6ZKu5by577yM5Ye65biu5Yqp5rWu5qGGXHJcbiAgICBIZWxwVGlwczogZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgc2VsZj10aGlzO1xyXG4gICAgICAgIGxldCBoZWxwdGlwc191aSA9IGNjLmluc3RhbnRpYXRlKHNlbGYuaGVscF91aSk7XHJcbiAgICAgICAgaGVscHRpcHNfdWkucGFyZW50ID0gc2VsZi5ub2RlO1xyXG4gICAgICAgIGhlbHB0aXBzX3VpLnNldFBvc2l0aW9uKDAsMCk7ICBcclxuICAgIH0sXHJcblxyXG4gICAgLy/ngrnlh7vlv6vpgJ/pnIDmib7lr7nmiYvmjInpkq7vvIzlvLnlh7rmuLjmiI/mqKHlvI/pgInmi6nmoYbvvIjlj6/pgInvvIlcclxuICAgIEdhbWVNb2RlbFNlbGVjdDogZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgc2VsZj10aGlzO1xyXG4gICAgfSxcclxuICAgICAgICBcclxuICAgIC8v5LiL6Z2i5a6e546w77yM5a6i5oi356uv5Zyo5o6l5Y+X5Yiw5YWB6K646L+b5YWl5Yy56YWN6Zif5YiX5ZCO77yM5byA5aeL6L2u6K+i6K+35rGCXHJcbiAgICAvL+ivt+axguWMuemFjeeOqeWutuaXtu+8jOi9ruivouivt+axguWHveaVsC5cclxuICAgIC8v5b2T6L+U5Zue55qE5YC8562J5LqOMTAwMTQo5om+5Yiw5a+55omLKeaXtu+8jOS4jeWPjeWkjeaJp+ihjOatpOWHveaVsFxyXG4gICAgLy/lvZPov5Tlm57nmoTlgLznrYnkuo4xMDAxNSjmnKrmib7liLDlr7nmiYsp5pe277yM5Zyo5LiA5a6a5pe26Ze05YaF5Y+N5aSN5omn6KGM5q2k5Ye95pWwXHJcbiAgICBQb2xsaW5nOiBmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICB2YXIgIHVybD1cImh0dHA6Ly8xOTIuMTY4LjAuMjI5OjgwODAvdGVzdFwiO1xyXG4gICAgICAgIHZhciAgcGFyYW1zID0gSlNPTi5zdHJpbmdpZnkoe0lkOnVzZXJkYXRhLmlkICxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJDb250ZW50XCI6e1wiVHlwZVwiOjEwMDEzfX0pOyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgIHZhciBtc2cgPSBcIm1zZz1cIitwYXJhbXM7XHJcbiAgICAgICAgY2MubG9nKFwi5Yy56YWN6L2u6K+i5pe25Y+R6YCB5raI5oGv77yaXCIrbXNnKTtcclxuICAgICAgICBodHRwLkh0dHBQb3N0KHVybCwgbXNnICxmdW5jdGlvbiAocnZfbWVzKSB7ICBcclxuICAgICAgICAgICAgaWYgKHJ2X21lcyA9PT0gLTEpIHsgIFxyXG4gICAgICAgICAgICAgICAgY2MubG9nKCfor7fmo4Dmn6XnvZHnu5zvvIEnKTsgIFxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcnZfbWVzID0gSlNPTi5wYXJzZShydl9tZXMpO1xyXG4gICAgICAgICAgICAgICAgY2MubG9nKHJ2X21lcyk7XHJcbiAgICAgICAgICAgICAgICBpZihydl9tZXMuVHlwZT09PTEwMDE1KXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5Qb2xsaW5nKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfSwgMTAwMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwi5pyq5om+5Yiw5a+55omLXCIpO1xyXG4gICAgICAgICAgICAgICAgfWVsc2UgIGlmKHJ2X21lcy5UeXBlPT09MTAwMTQpe1xyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJkYXRhLnJlc3RCbGFja0NvdW50ID0gcnZfbWVzLlJlc3RDYXJkLmJsYWNrO1xyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJkYXRhLnJlc3RXaGl0ZUNvdW50ID0gcnZfbWVzLlJlc3RDYXJkLndoaXRlO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhcmQuSW5pdF9mb3VyX3BsYXllcnMocnZfbWVzKTtcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCLmib7liLDlr7nmiYtcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgLy/lkJHogYrlpKnmnI3liqHlmajlj5HpgIHor7fmsYLov57mjqXogYrlpKnlrqRcclxuICAgICAgICAgICAgICAgICAgICB1c2VyZGF0YS5jaGF0Um9vbUtleSA9IHJ2X21lcy5LZXk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcIldhaXRpbmdHYW1lU2NlbmVcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgfSwgMTAwMCk7XHJcbiAgICAgICAgICAgICAgICB9IFxyXG4gICAgICAgICAgICB9IFxyXG4gICAgICAgIH0pO1xyXG4gICAgfSxcclxuICAgICBcclxuXHJcbiAgICAgdXBkYXRlOmZ1bmN0aW9uKGR0KXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgc29rZXQuZ2V0Q2hhdE1zZygpO1xyXG4gICAgIH0sXHJcbn0pO1xyXG4iLCJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgICBoZWxwYmc6ey8vaGVscOW8ueWHuuahhueahOiDjOaZr1xyXG4gICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgIHR5cGU6Y2MuTm9kZSAgIFxyXG4gICAgICAgICB9LFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBzZWxmPXRoaXM7XHJcbiAgICAgICAgc2VsZi5oZWxwYmcub24oJ3RvdWNoc3RhcnQnLCBzZWxmLmVhdFRvdWNoLCBzZWxmKTtcclxuICAgIH0sXHJcblxyXG4gICAgZWF0VG91Y2g6ZnVuY3Rpb24oZXZlbnQpe1xyXG5cdCAgICBjYy5sb2coJ2VhdFRvdWNoJyk7XHJcblx0ICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgfSxcclxuICAgIGNsb3NlOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5ub2RlLmRlc3Ryb3koKTtcclxuICAgIH1cclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXHJcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xyXG5cclxuICAgIC8vIH0sXHJcbn0pO1xyXG4iLCIvL2h0dHBVdGlscy5qc+iEmuacrOeUqOS9nOaooeadv21vZHVsZe+8jOaPkOS+m+WQkeacjeWKoeWZqOWPkemAgea2iOaBr++8jOaOpeaUtua2iOaBr+etieWKn+iDvVxyXG5tb2R1bGUuZXhwb3J0cz17XHJcbiAgICBpc0JhY2tUb0hhbGw6ZmFsc2UsXHJcbiAgICAvL+WQkeacjeWKoeerr+WPkemAgXBvc3Tlkb3ku6Qs6KaB5rGC5pS55Y+Y5L+h5oGvXHJcbiAgICBIdHRwUG9zdDogZnVuY3Rpb24gKHVybCwgcGFyYW1zLCBjYWxsYmFjaykge1xyXG4gICAgICAgIGlmKHRoaXMuaXNCYWNrVG9IYWxsPT10cnVlKXtcclxuICAgICAgICAgICAgY2MubG9nKFwi6L+U5Zue5aSn5Y6F5LqGXCIpOyBcclxuICAgICAgICAgICAgfWVsc2V7ICBcclxuICAgICAgICAgICAgIHZhciB4aHIgPSBjYy5sb2FkZXIuZ2V0WE1MSHR0cFJlcXVlc3QoKTsgIFxyXG4gICAgICAgICAgICAgeGhyLm9wZW4oXCJQT1NUXCIsIHVybCwgdHJ1ZSk7XHJcbiAgICAgICAgICAgICB4aHIuc2V0UmVxdWVzdEhlYWRlcihcIkNvbnRlbnQtVHlwZVwiLCBcImFwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZFwiKTtcclxuICAgICAgICAgICAgeGhyLm9ucmVhZHlzdGF0ZWNoYW5nZSA9IGZ1bmN0aW9uICgpeyAgXHJcbiAgICAgICAgICAgICAgICBpZiAoeGhyLnJlYWR5U3RhdGUgPT09IDQgJiYgKHhoci5zdGF0dXMgPj0gMjAwICYmIHhoci5zdGF0dXMgPCAzMDApKSB7ICBcclxuICAgICAgICAgICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSB4aHIucmVzcG9uc2VUZXh0OyBcclxuICAgICAgICAgICAgICAgICAgICBjYWxsYmFjayhyZXNwb25zZSk7ICBcclxuICAgICAgICAgICAgICAgIH1lbHNleyAgXHJcbiAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2soLTEpOyAgXHJcbiAgICAgICAgICAgICAgICB9ICBcclxuICAgICAgICAgICAgfTsgICAgICAgIFxyXG4gICAgICAgICAgICB4aHIuc2VuZChwYXJhbXMpO1xyXG4gICAgICAgIH0gIFxyXG4gICAgfSwgXHJcblxyXG59OyIsInZhciB1c2VyZGF0YSA9IHJlcXVpcmUoJ1VzZXJEYXRhJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBpZDogY2MuTGFiZWwsXHJcbiAgICAgICAgaWNvbjogY2MuU3ByaXRlLFxyXG4gICAgICAgIGZyaWVuZE5hbWU6IGNjLkxhYmVsLFxyXG4gICAgICAgIGZyaWVuZEdyYWRlOiBjYy5MYWJlbFxyXG4gICAgfSxcclxuXHJcblxyXG4gICAgaW5pdDpmdW5jdGlvbihkYXRhKXtcclxuICAgICAgICB0aGlzLmlkLnN0cmluZyA9IGRhdGEuaWQ7XHJcbiAgICAgICAgdGhpcy5pY29uLnNwcml0ZUZyYW1lID0gZGF0YS5pY29uU0Y7XHJcbiAgICAgICAgdGhpcy5mcmllbmROYW1lLnN0cmluZyA9IGRhdGEuaXRlbU5hbWU7XHJcbiAgICAgICAgdGhpcy5mcmllbmRHcmFkZS5zdHJpbmcgPSBkYXRhLml0ZW1HcmFkZTtcclxuICAgIH0sXHJcblxyXG4gICAgLy/lpb3lj4vliJfooahpdGVt55qE54K55Ye75ZON5bqU5Ye95pWwXHJcbiAgICBTZWxlY3RGcmllbmQ6ZnVuY3Rpb24obm9kZSl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHZhciBpZCA9IG5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJpZFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZztcclxuICAgICAgICB2YXIgbmFtZSA9IG5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJuYW1lXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nOyBcclxuICAgICAgICBub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULCBmdW5jdGlvbiAoZXZlbnQpIHtcclxuICAgICAgICAgICAgbm9kZS5pbnRlcmFjdGFibGUgPSBub2RlLmdldENvbXBvbmVudChjYy5CdXR0b24pLmludGVyYWN0YWJsZTtcclxuICAgICAgICAgICAgaWYgKCFub2RlLmludGVyYWN0YWJsZSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHVzZXJkYXRhLnNlbGVjdGVkRnJpZW5kTmFtZSA9IHNlbGYuZnJpZW5kTmFtZS5zdHJpbmc7XHJcbiAgICAgICAgICAgIHVzZXJkYXRhLnNlbGVjdGVkRnJpZW5kSUQgPSBzZWxmLmlkLnN0cmluZztcclxuICAgICAgICAgICAgaWYoaWQgPT0gdXNlcmRhdGEuc2VsZWN0ZWRGcmllbmRJRCl7XHJcbiAgICAgICAgICAgIG5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJzZWxlY3RpbmdcIikuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgIGlmKG5hbWUgPT0gdXNlcmRhdGEuc2VsZWN0ZWRGcmllbmROYW1lKXtcclxuICAgICAgICAgICAgbm9kZS5nZXRDaGlsZEJ5TmFtZShcInNlbGVjdGluZ1wiKS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgY2MubG9nKHVzZXJkYXRhLnNlbGVjdGVkRnJpZW5kTmFtZSk7XHJcbiAgICAgICAgfS5iaW5kKHRoaXMpKTtcclxuXHJcbiAgICAgICAgbm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9Nb3ZlLCBmdW5jdGlvbiAoZXZlbnQpIHtcclxuICAgICAgICAgICAgaWYgKCFub2RlLmludGVyYWN0YWJsZSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfS5iaW5kKHRoaXMpKTtcclxuXHJcbiAgICAgICAgbm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsIGZ1bmN0aW9uIChldmVudCkge1xyXG4gICAgICAgICAgICBpZiAoIW5vZGUuaW50ZXJhY3RhYmxlKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LmJpbmQodGhpcykpO1xyXG5cclxuICAgICAgICBub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0NBTkNFTCwgZnVuY3Rpb24gKGV2ZW50KSB7XHJcbiAgICAgICAgICAgIGlmICghbm9kZS5pbnRlcmFjdGFibGUpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0uYmluZCh0aGlzKSk7ICAgICAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICBvbkxvYWQ6ZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgc2VsZi5TZWxlY3RGcmllbmQodGhpcy5ub2RlKTtcclxuICAgIH0sXHJcbn0pO1xyXG4iLCJ2YXIgdXNlcmRhdGEgPSByZXF1aXJlKCdVc2VyRGF0YScpO1xyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgaWQ6IGNjLkxhYmVsLFxyXG4gICAgICAgIGljb246IGNjLlNwcml0ZSxcclxuICAgICAgICB0aXRsZTogY2MuTGFiZWwsXHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICBpbml0OmZ1bmN0aW9uKGRhdGEpe1xyXG4gICAgICAgIHRoaXMuaWQuc3RyaW5nID0gZGF0YS5pZDtcclxuICAgICAgICB0aGlzLmljb24uc3ByaXRlRnJhbWUgPSBkYXRhLmljb25TRjtcclxuICAgICAgICB0aGlzLnRpdGxlLnN0cmluZyA9IGRhdGEudGl0bGU7XHJcbiAgICB9LFxyXG5cclxuICAgIC8v5aW95Y+L5YiX6KGoaXRlbeeahOeCueWHu+WTjeW6lOWHveaVsFxyXG4gICAgU2VsZWN0RnJpZW5kOmZ1bmN0aW9uKG5vZGUpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICB2YXIgaWQgPSBub2RlLmdldENoaWxkQnlOYW1lKFwiaWRcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc7IFxyXG4gICAgICAgIG5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsIGZ1bmN0aW9uIChldmVudCkge1xyXG4gICAgICAgICAgICBub2RlLmludGVyYWN0YWJsZSA9IG5vZGUuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbikuaW50ZXJhY3RhYmxlO1xyXG4gICAgICAgICAgICBpZiAoIW5vZGUuaW50ZXJhY3RhYmxlKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgY2MubG9nKFwi54K55Ye75p+l55yL6YKu5Lu2XCIpO1xyXG4gICAgICAgICAgICB1c2VyZGF0YS5zZWxlY3RlZE1haWxJRCA9IHNlbGYuaWQuc3RyaW5nO1xyXG4gICAgICAgICAgICBpZihpZCA9PSB1c2VyZGF0YS5zZWxlY3RlZE1haWxJRCl7XHJcbiAgICAgICAgICAgICAgICBub2RlLmdldENoaWxkQnlOYW1lKFwic2VsZWN0aW5nXCIpLmFjdGl2ZSA9IHRydWU7ICAgXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LmJpbmQodGhpcykpO1xyXG5cclxuICAgICAgICBub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX01vdmUsIGZ1bmN0aW9uIChldmVudCkge1xyXG4gICAgICAgICAgICBpZiAoIW5vZGUuaW50ZXJhY3RhYmxlKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LmJpbmQodGhpcykpO1xyXG5cclxuICAgICAgICBub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0VORCwgZnVuY3Rpb24gKGV2ZW50KSB7XHJcbiAgICAgICAgICAgIGlmICghbm9kZS5pbnRlcmFjdGFibGUpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0uYmluZCh0aGlzKSk7XHJcblxyXG4gICAgICAgIG5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfQ0FOQ0VMLCBmdW5jdGlvbiAoZXZlbnQpIHtcclxuICAgICAgICAgICAgaWYgKCFub2RlLmludGVyYWN0YWJsZSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfS5iaW5kKHRoaXMpKTsgICAgICAgICAgICBcclxuICAgIH0sXHJcblxyXG5cclxuICAgIG9uTG9hZDpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBzZWxmLlNlbGVjdEZyaWVuZCh0aGlzLm5vZGUpO1xyXG4gICAgfSxcclxufSk7XHJcbiIsInZhciBodHRwID0gcmVxdWlyZSgnSHR0cFV0aWxzJyk7XHJcbnZhciB1c2VyZGF0YSA9IHJlcXVpcmUoXCJVc2VyRGF0YVwiKTtcclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIGlkRWRpdEJveDp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5FZGl0Qm94LCBcclxuICAgICAgICB9LFxyXG4gICAgICAgIHBhZEVkaXRCb3g6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuRWRpdEJveCwgXHJcbiAgICAgICAgfSxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIFRvSGFsbDogZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHZhciB1cmw9XCJodHRwOi8vMTkyLjE2OC4wLjIyOTo4MDgwL3Rlc3RcIjtcclxuICAgICAgICB1c2VyZGF0YS5tbmFtZT1zZWxmLmlkRWRpdEJveC5zdHJpbmc7XHJcbiAgICAgICAgdmFyIGNvbnRlbnQgPSBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFR5cGU6MTAwMDEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFVpZDpzZWxmLmlkRWRpdEJveC5zdHJpbmcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBzZDpzZWxmLnBhZEVkaXRCb3guc3RyaW5nLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGNvbnRlbnQgPSBKU09OLnBhcnNlKGNvbnRlbnQpO1xyXG4gICAgICAgIHZhciBpZF9tZXMgPSBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENvbnRlbnQ6Y29udGVudCxcclxuICAgICAgICB9KTtcclxuICAgICAgICBjb250ZW50PVwibXNnPVwiK2lkX21lcztcclxuICAgICAgICBjYy5sb2coY29udGVudCk7XHJcbiAgICAgICAgaHR0cC5IdHRwUG9zdCh1cmwsY29udGVudCxmdW5jdGlvbihydl9tZXMpe1xyXG4gICAgICAgICAgICBpZiAocnZfbWVzID09PSAtMSkgeyAgXHJcbiAgICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwi6K+35qOA5p+l572R57ucXCIpO1xyXG4gICAgICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICAgIGNjLmxvZyhydl9tZXMpO1xyXG4gICAgICAgICAgICAgICAgdmFyIHJ2PUpTT04ucGFyc2UocnZfbWVzKTtcclxuICAgICAgICAgICAgICAgIGlmKHJ2LlR5cGU9PT0xMDAwMil7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwiNjY2NlwiKTtcclxuICAgICAgICAgICAgICAgICAgICB1c2VyZGF0YS5pZD1ydi5JRDtcclxuICAgICAgICAgICAgICAgICAgICB1c2VyZGF0YS5ncmFkZT1ydi5HcmFkZTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgYmc9Y2MuZmluZChcIkNhbnZhcy9iZ1wiKTtcclxuICAgICAgICAgICAgICAgICAgIC8vIHZhciBzZXEyPWNjLnNlcXVlbmNlKGNjLmZhZGVPdXQoMSksY2MuZGVsYXlUaW1lKDEuMDEpLGNjLmNhbGxGdW5jKFxyXG4gICAgICAgICAgICAgICAgICAgLy8gZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiSGFsbFNjZW5lXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgLy8gfSkpO1xyXG4gICAgICAgICAgICAgICAgICAgLy8gYmcucnVuQWN0aW9uKHNlcTIpO1xyXG4gICAgICAgICAgICAgICAgfWVsc2UgaWYocnYuVHlwZT09PTEwMDAzKXtcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCI1NTU1XCIpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgIH1cclxuXHJcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xyXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuXHJcbiAgICAvLyB9LFxyXG59KTtcclxuIiwidmFyIHVzZXJkYXRhID0gcmVxdWlyZSgnVXNlckRhdGEnKTtcclxudmFyIGZyaWVuZCA9IHJlcXVpcmUoJ0ZyaWVuZEFjdGl2aXR5Jyk7XHJcbnZhciBodHRwID0gcmVxdWlyZSgnSHR0cFV0aWxzJyk7XHJcbnZhciBzb2tldCA9IHJlcXVpcmUoXCJTb2tldFV0aWxzXCIpO1xyXG52YXIgSXRlbTMgPSBjYy5DbGFzcyh7XHJcbiAgICBuYW1lOlwiSXRlbTNcIixcclxuICAgIHByb3BlcnRpZXM6e1xyXG4gICAgICAgIGlkOjAsXHJcbiAgICAgICAgZnJpZW5kTmFtZTpcIlwiLFxyXG4gICAgICAgIGZyaWVuZEljb246Y2MuU3ByaXRlRnJhbWUsXHJcbiAgICB9LFxyXG59KTtcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBpdGVtczp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6W10sXHJcbiAgICAgICAgICAgIHR5cGU6SXRlbTMsXHJcbiAgICAgICAgfSwgIFxyXG4gICAgICAgIGl0ZW1NYWlsUHJlZmFiOiBjYy5QcmVmYWIsXHJcbiAgICAgICAgaGVhZEF0bGFzOntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLlNwcml0ZUF0bGFzXHJcbiAgICAgICAgfSxcclxuICAgICAgICBtYWlsTGlzdENvbnRlbnQ6ey8v6YKu5Lu25YiX6KGo5YaF5a65XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5Ob2RlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgbWFpbEJveDp7Ly/pgq7nrrFcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLk5vZGUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBtYWlsRGV0YWlsOnsvL+mCruS7tuWFt+S9k+S/oeaBr+a1ruahhlxyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIG1haWxBZGRyZXNzZXI6ey8v6YKu5Lu25Y+R5Lu25Lq6XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5MYWJlbCxcclxuICAgICAgICB9LFxyXG4gICAgICAgIG1haWxEZXRhaWxDb250ZW50OnsvL+mCruS7tuWFt+S9k+S/oeaBr+WGheWuuVxyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIG1haWxEZXRhaWxMYWJlbDp7Ly/pgq7ku7blhbfkvZPkv6Hmga/mlofmnKxcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLkxhYmVsLFxyXG4gICAgICAgIH0sXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgdXNlcmRhdGEuc2VsZWN0ZWRNYWlsSUQgPSBudWxsO1xyXG4gICAgICAgIHZhciBlNCA9IEpTT04uc3RyaW5naWZ5KHtUeXBlOjMwMDAwMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJNYWlsTGlzdFwiOlt7XCJJRFwiOjEsXCJGcmllbmRJY29uXCI6XCJoZWFkMVwiLFwiRnJpZW5kTmFtZVwiOlwiYWHmkpLml6ZcIixcIkNvbnRlbnRcIjpcIuWUkOWkquWul+adjuS4luawke+8iOWFrOWFgzU5OOW5tDHmnIgyOOaXpeOAkOS4gOivtDU5OeW5tDHmnIgyM+aXpeOAke+8jeWFrOWFgzY0OeW5tDfmnIgxMOaXpe+8ie+8jOeUn+S6juatpuWKn+S5i+WIq+mmhu+8iOS7iumZleilv+atpuWKn++8ie+8jOaYr+WUkOmrmOelluadjua4iuWSjOeqpueah+WQjueahOasoeWtkO+8jOWUkOacneesrOS6jOS9jeeah+W4ne+8jOadsOWHuueahOaUv+ayu+WutuOAgeaImOeVpeWutuOAgeWGm+S6i+WutuOAgeivl+S6uuOAguadjuS4luawkeWwkeW5tOS7juWGm++8jOabvuWOu+mbgemXqOWFs+iQpeaVkemai+eCgOW4neOAguWUkOacneW7uueri+WQju+8jOadjuS4luawkeWumOWxheWwmuS5puS7pOOAgeWPs+atpuWAmeWkp+WwhuWGm++8jOWPl+WwgeS4uuenpuWbveWFrO+8jOWQjuaZi+WwgeS4uuenpueOi++8jOWFiOWQjueOh+mDqOW5s+WumuS6huiWm+S7geadsuOAgeWImOatpuWRqOOAgeeqpuW7uuW+t+OAgeeOi+S4luWFheetieWGm+mYgO+8jOWcqOWUkOacneeahOW7uueri+S4jue7n+S4gOi/h+eoi+S4reeri+S4i+i1q+i1q+aImOWKn+OAguWFrOWFgzYyNuW5tDfmnIgy5pel77yI5q2m5b635Lmd5bm05YWt5pyI5Yid5Zub77yJ77yM5p2O5LiW5rCR5Y+R5Yqo4oCc546E5q2m6Zeo5LmL5Y+Y4oCd77yM5p2A5q276Ieq5bex55qE5YWE6ZW/5aSq5a2Q5p2O5bu65oiQ44CB5Zub5byf6b2Q546L5p2O5YWD5ZCJ5Y+K5LqM5Lq66K+45a2Q77yM6KKr56uL5Li65aSq5a2Q77yM5ZSQ6auY56WW5p2O5riK5LiN5LmF6YCA5L2N77yM5p2O5LiW5rCR5Y2z5L2N77yM5pS55YWD6LSe6KeC44CCWzFdIOadjuS4luawkeS4uuW4neS5i+WQju+8jOenr+aegeWQrOWPlue+pOiHo+eahOaEj+inge+8jOWvueWGheS7peaWh+ayu+WkqeS4i++8jOiZmuW/g+e6s+iwj++8jOWOieihjOiKgue6pu+8jOWKneivvuWGnOahke+8jOS9v+eZvuWnk+iDveWkn+S8keWFu+eUn+aBr++8jOWbveazsOawkeWuie+8jOW8gOWIm+S6huS4reWbveWOhuWPsuS4iuiRl+WQjeeahOi0nuinguS5i+ayu+OAguWvueWkluW8gOeWhuaLk+Wcn++8jOaUu+eBreS4nOeqgeWOpeS4juiWm+W7tumZgO+8jOW+geacjemrmOaYjOOAgem+n+WFueOAgeWQkOiwt+a1ke+8jOmHjeWIm+mrmOWPpeS4ve+8jOiuvueri+Wuieilv+Wbm+mVh++8jOWQhOawkeaXj+iejea0veebuOWkhO+8jOiiq+WQhOaXj+S6uuawkeWwiuensOS4uuWkqeWPr+axl++8jOS4uuWQjuadpeWUkOacneS4gOeZvuWkmuW5tOeahOebm+S4luWloOWumumHjeimgeWfuuehgOOAguWFrOWFgzY0OeW5tDfmnIgxMOaXpe+8iOi0nuinguS6jOWNgeS4ieW5tOS6lOaciOW3seW3s+aXpe+8ie+8jOadjuS4luawkeWboOeXhempvuW0qeS6juWQq+mjjuauv++8jOS6q+W5tOS6lOWNgeS6jOWyge+8jOWcqOS9jeS6jOWNgeS4ieW5tO+8jOW6meWPt+WkquWul++8jOiRrOS6juaYremZteOAguadjuS4luawkeeIseWlveaWh+WtpuS4juS5puazle+8jOacieWiqOWuneS8oOS4luOAglwifSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XCJJRFwiOjIsXCJGcmllbmRJY29uXCI6XCJoZWFkMlwiLFwiRnJpZW5kTmFtZVwiOlwiYmJi5pKS5pemXCIsXCJDb250ZW50XCI6XCIyMjIyMjIyMjIyMjIyMjIyMjIyMlwifSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XCJJRFwiOjMsXCJGcmllbmRJY29uXCI6XCJoZWFkM1wiLFwiRnJpZW5kTmFtZVwiOlwi6ZKf5a6H57+UXCIsXCJDb250ZW50XCI6XCIzMzMzMzMzMzMzMzMzMzMzMzMzM1wifSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XCJJRFwiOjQsXCJGcmllbmRJY29uXCI6XCJoZWFkNFwiLFwiRnJpZW5kTmFtZVwiOlwiZGRkXCIsXCJDb250ZW50XCI6XCI0NDQ0NDQ0NDQ0NDQ0NDRcIn0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1wiSURcIjo1LFwiRnJpZW5kSWNvblwiOlwiaGVhZDVcIixcIkZyaWVuZE5hbWVcIjpcIkphY2sgYmxhY2tcIixcIkNvbnRlbnRcIjpcIjU1NTU1NTU1NTU1NTU1NTU1NTU1NVwifSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XCJJRFwiOjYsXCJGcmllbmRJY29uXCI6XCJoZWFkNlwiLFwiRnJpZW5kTmFtZVwiOlwiZmZmXCIsXCJDb250ZW50XCI6XCI2NjY2NjY2NjY2NjY2NjY2NjY2NjZcIn0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1wiSURcIjo4LFwiRnJpZW5kSWNvblwiOlwiaGVhZDhcIixcIkZyaWVuZE5hbWVcIjpcImhoaFwiLFwiQ29udGVudFwiOlwiNzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3NzdcIn0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1wiSURcIjo5LFwiRnJpZW5kSWNvblwiOlwiaGVhZDlcIixcIkZyaWVuZE5hbWVcIjpcImlpaVwiLFwiQ29udGVudFwiOlwi5L2g5aW95L2g5aW95L2gc3Nzc+WlveS9oOWlvVwifSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XCJJRFwiOjEwLFwiRnJpZW5kSWNvblwiOlwiaGVhZDEwXCIsXCJGcmllbmROYW1lXCI6XCJqampcIixcIkNvbnRlbnRcIjpcIuS9oOWlveS9oOWlvXFx5L2g5aW9XCJ9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcIklEXCI6MTEsXCJGcmllbmRJY29uXCI6XCJoZWFkMTFcIixcIkZyaWVuZE5hbWVcIjpcImtra1wiLFwiQ29udGVudFwiOlwi5L2g5aW95L2g5aW9ZGTkvaDlpb3kvaDlpb3kvaDlpb3kvaDlpb1cIn0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgZTQgPSBKU09OLnBhcnNlKGU0KTtcclxuICAgICAgICBmcmllbmQuSW5pdF9tYWlsKGU0KTtcclxuICAgICAgICBjYy5sb2codXNlcmRhdGEubWFpbEluZm8pOyAgICAgICAgICBcclxuICAgICAgICBzZWxmLml0ZW1zLmxlbmd0aCA9IHVzZXJkYXRhLm1haWxJbmZvLmxlbmd0aDtcclxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHNlbGYuaXRlbXMubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgIHZhciBpdGVtID0gY2MuaW5zdGFudGlhdGUoc2VsZi5pdGVtTWFpbFByZWZhYik7XHJcbiAgICAgICAgICAgICBzZWxmLml0ZW1zW2ldID0gdXNlcmRhdGEubWFpbEluZm9baV07XHJcbiAgICAgICAgICAgICB2YXIgZGF0YSA9IHNlbGYuaXRlbXNbaV07XHJcbiAgICAgICAgICAgICBzZWxmLm5vZGUuYWRkQ2hpbGQoaXRlbSk7XHJcbiAgICAgICAgICAgICBpdGVtLmdldENvbXBvbmVudCgnSXRlbU1haWwnKS5pbml0KHtcclxuICAgICAgICAgICAgICAgIGlkOiBkYXRhLklELFxyXG4gICAgICAgICAgICAgICAgdGl0bGU6IFwi5qCH6aKY77ya5p2l6IeqXCIrc2VsZi5JZ25vcmVMb25nTmFtZShkYXRhLkZyaWVuZE5hbWUpK1wiLi7nmoTpgq7ku7ZcIixcclxuICAgICAgICAgICAgICAgIGljb25TRjogc2VsZi5oZWFkQXRsYXMuZ2V0U3ByaXRlRnJhbWUoZGF0YS5GcmllbmRJY29uKSxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvL+WmguaenOmCruS7tuagh+mimOS4reeOqeWutuWnk+WQjei/h+mVv++8jOiHquWKqOecgeeVpeS7juesrDTkvY3lvIDlp4vnmoTlrZfnrKZcclxuICAgIElnbm9yZUxvbmdOYW1lOmZ1bmN0aW9uKGxvbmdOYW1lKXtcclxuICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgIHZhciBpZ25vcmVlZE5hbWUgPSBsb25nTmFtZS5zbGljZSgwLDMpOztcclxuICAgICAgIHJldHVybiBpZ25vcmVlZE5hbWU7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvL+WIoOmZpOmCruS7tuaMiemSruWTjeW6lOWHveaVsFxyXG4gICAgRGVsZXRlTWFpbDpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICAgICAgLy/mraTlpITnu5nmnI3liqHlmajlj5HpgIHor7fmsYJcclxuICAgICAgICAgICAgaWYodXNlcmRhdGEuc2VsZWN0ZWRNYWlsSUQgPT0gbnVsbCl7XHJcbiAgICAgICAgICAgIGNjLmxvZyhcIuivt+WFiOmAieaLqeaDs+WIoOmZpOeahOmCruS7ti5cIik7XHJcbiAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgZnJpZW5kLkRlbGV0ZV9tYWlsKHVzZXJkYXRhLnNlbGVjdGVkTWFpbElEKTtcclxuICAgICAgICAgICAgICAgIGNjLmxvZyh1c2VyZGF0YS5tYWlsSW5mbyk7XHJcbiAgICAgICAgICAgICAgICBzZWxmLlVwZGF0ZU1haWxMaXN0KCk7XHJcbiAgICAgICAgICAgICAgICBjYy5sb2coXCLliJfooajpgq7ku7ZpdGVt5pWw6YePOlwiK3NlbGYubWFpbExpc3RDb250ZW50LmNoaWxkcmVuLmxlbmd0aCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICB1c2VyZGF0YS5zZWxlY3RlZE1haWxJRCA9IG51bGw7XHJcbiAgICB9LFxyXG5cclxuICAgIC8v5pu05paw6YKu5Lu25YiX6KGoXHJcbiAgICBVcGRhdGVNYWlsTGlzdDpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICAgICBzZWxmLm1haWxMaXN0Q29udGVudC5yZW1vdmVDaGlsZChzZWxmLkdldFJlbW92ZWRJdGVtKHVzZXJkYXRhLnNlbGVjdGVkTWFpbElEKSk7XHJcbiAgICB9LFxyXG5cclxuICAgIC8v5p+l55yL6YKu5Lu25YW35L2T5YaF5a655oyJ6ZKu5ZON5bqU5Ye95pWwXHJcbiAgICBSZWFkTWFpbDpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBpZih1c2VyZGF0YS5zZWxlY3RlZE1haWxJRCA9PSBudWxsKXtcclxuICAgICAgICAgICAgY2MubG9nKFwi6K+35YWI6YCJ5oup5oOz5p+l55yL55qE6YKu5Lu2LlwiKTtcclxuICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICBzZWxmLm1haWxEZXRhaWwuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIGNjLmxvZyhcIm1haWxJRFwiK3VzZXJkYXRhLnNlbGVjdGVkTWFpbElEKTtcclxuICAgICAgICAgICAgICAgIGZvcih2YXIgaSA9IDA7IGk8dXNlcmRhdGEubWFpbEluZm8ubGVuZ3RoOysraSl7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGlkID0gdXNlcmRhdGEubWFpbEluZm9baV0uSUQ7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYoIGlkID09IHVzZXJkYXRhLnNlbGVjdGVkTWFpbElEKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5tYWlsQWRkcmVzc2VyLnN0cmluZyA9IFwi5Y+R5Lu25Lq677yaXCIrdXNlcmRhdGEubWFpbEluZm9baV0uRnJpZW5kTmFtZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5tYWlsRGV0YWlsTGFiZWwuc3RyaW5nID0gXCJcXG5cIitcIlxcblwiK1wi6YKu5Lu25L+h5oGv5aaC5LiLOlwiK1wiXFxuXCIrdXNlcmRhdGEubWFpbEluZm9baV0uQ29udGVudDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgY2MubG9nKHNlbGYubWFpbERldGFpbExhYmVsLnN0cmluZy5sZW5ndGgpO1xyXG4gICAgfSxcclxuXHJcbiAgICBDbG9zZU1haWw6ZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgc2VsZi5tYWlsRGV0YWlsLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIHVzZXJkYXRhLnNlbGVjdGVkTWFpbElEID0gbnVsbDtcclxuICAgIH0sXHJcblxyXG4gICAgLy/noa7lrpropoHnp7vpmaTnmoRpdGVtXHJcbiAgICBHZXRSZW1vdmVkSXRlbTpmdW5jdGlvbihtYWlsSUQpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBmb3IodmFyIGkgPSAwO2k8c2VsZi5tYWlsTGlzdENvbnRlbnQuY2hpbGRyZW4ubGVuZ3RoOysraSl7XHJcbiAgICAgICAgICAgIHZhciBpZCA9IHNlbGYubWFpbExpc3RDb250ZW50LmNoaWxkcmVuW2ldLmdldENoaWxkQnlOYW1lKFwiaWRcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc7XHJcbiAgICAgICAgICAgIGlmKCBpZCA9PSBtYWlsSUQpe1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHNlbGYubWFpbExpc3RDb250ZW50LmNoaWxkcmVuW2ldO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvL+agh+iusOW9k+WJjeeCueWHu+eahOmCruS7tlxyXG4gICAgU2lnblNlbGVjdGVkRnJpZW5kOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIGZvcih2YXIgaSA9IDA7aTxzZWxmLm1haWxMaXN0Q29udGVudC5jaGlsZHJlbi5sZW5ndGg7KytpKXtcclxuICAgICAgICAgICAgdmFyIGlkID0gc2VsZi5tYWlsTGlzdENvbnRlbnQuY2hpbGRyZW5baV0uZ2V0Q2hpbGRCeU5hbWUoXCJpZFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZztcclxuICAgICAgICAgICAgaWYoIGlkID09IHVzZXJkYXRhLnNlbGVjdGVkTWFpbElEKXtcclxuICAgICAgICAgICAgICAgIHNlbGYubWFpbExpc3RDb250ZW50LmNoaWxkcmVuW2ldLmdldENoaWxkQnlOYW1lKFwic2VsZWN0aW5nXCIpLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgc2VsZi5tYWlsTGlzdENvbnRlbnQuY2hpbGRyZW5baV0uZ2V0Q2hpbGRCeU5hbWUoXCJzZWxlY3RpbmdcIikuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IFxyXG4gICAgfSxcclxuXHJcbiAgICAvL+abtOaWsOmCruS7tuWGheWuueeahOmrmOW6plxyXG4gICAgVXBkYXRlTWFpbEhlaWdodDpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICB2YXIgY291bnQgPSBNYXRoLnJvdW5kKHNlbGYubWFpbERldGFpbExhYmVsLnN0cmluZy5sZW5ndGgvMjIpO1xyXG4gICAgICAgIHNlbGYubWFpbERldGFpbENvbnRlbnQuaGVpZ2h0ID0gMjAwK+OAgGNvdW50KjM1O1xyXG4gICAgfSxcclxuICAgIFxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHNlbGYubWFpbExpc3RDb250ZW50LmhlaWdodCA9IDIzMCAr44CAdXNlcmRhdGEubWFpbEluZm8ubGVuZ3RoKjYwO1xyXG4gICAgICAgIHNlbGYuU2lnblNlbGVjdGVkRnJpZW5kKCk7XHJcbiAgICAgICAgc2VsZi5VcGRhdGVNYWlsSGVpZ2h0KCk7XHJcbiAgICB9LFxyXG59KTtcclxuIiwidmFyIHVzZXJkYXRhID0gcmVxdWlyZSgnVXNlckRhdGEnKTtcclxudmFyIGZyaWVuZCA9IHJlcXVpcmUoJ0ZyaWVuZEFjdGl2aXR5Jyk7XHJcbnZhciBodHRwID0gcmVxdWlyZSgnSHR0cFV0aWxzJyk7XHJcbnZhciBzb2tldCA9IHJlcXVpcmUoXCJTb2tldFV0aWxzXCIpO1xyXG52YXIgSXRlbTIgPSBjYy5DbGFzcyh7XHJcbiAgICBuYW1lOlwiSXRlbTJcIixcclxuICAgIHByb3BlcnRpZXM6e1xyXG4gICAgICAgIGlkOjAsXHJcbiAgICAgICAgZnJpZW5kTmFtZTpcIlwiLFxyXG4gICAgICAgIGZyaWVuZEdyYWRlOjAsXHJcbiAgICAgICAgZnJpZW5kSWNvbjpjYy5TcHJpdGVGcmFtZSxcclxuICAgIH0sXHJcbn0pO1xyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBpdGVtczp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6W10sXHJcbiAgICAgICAgICAgIHR5cGU6SXRlbTIsXHJcbiAgICAgICAgfSwgIFxyXG4gICAgICAgIGl0ZW1GcmllbmRQcmVmYWI6IGNjLlByZWZhYixcclxuICAgICAgICBoZWFkQXRsYXM6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuU3ByaXRlQXRsYXNcclxuICAgICAgICB9LFxyXG4gICAgICAgIGZyaWVuZExpc3RDb250ZW50OnsvL+WlveWPi+WIl+ihqOWGheWuuVxyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZSxcclxuICAgICAgICB9LCBcclxuICAgICAgICBzZWFyY2hlZEZyaWVuZE5hbWU6ey8v6L6T5YWl55qE5pCc57Si55qE5aW95Y+L5aeT5ZCNXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5FZGl0Qm94LFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgc2VhcmNoZWRGcmllbmRMaXN0Q29udGVudDp7Ly/mkJzntKLnmoTlpb3lj4vliJfooajlhoXlrrlcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLk5vZGUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBmcmllbmRMaXN0OnsvL+eOsOacieeahOeahOeOqeWutuWIl+ihqFxyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHNlYXJjaGVkZnJpZW5kTGlzdDp7Ly/mkJzntKLnmoTnjqnlrrbliJfooahcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLk5vZGUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBmcmllbmRDaGF0TmFtZTE6ey8v6IGK5aSp77yM5pi+56S65q2j6YCJ5oup55qE5aW95Y+LXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5MYWJlbCwgXHJcbiAgICAgICAgfSxcclxuICAgICAgICBmcmllbmRDaGF0TmFtZTI6ey8v6YKu5Lu277yM5pi+56S65q2j6YCJ5oup55qE5aW95Y+LXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5MYWJlbCwgXHJcbiAgICAgICAgfSxcclxuICAgICAgICBzZWFyY2hDb3VudDowLFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgIH0sXHJcblxyXG4gICAgLy/mkJzntKLmoLnmja7mmLXnp7DmkJzntKLnjqnlrrbmjInpkq7lk43lupTlh73mlbBcclxuICAgIFNlYXJjaEZyaWVuZDpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICAgICAgc2VsZi5zZWFyY2hDb3VudCs9MTtcclxuICAgICAgICAgICAgdXNlcmRhdGEuc2VsZWN0ZWRGcmllbmRJRCA9IG51bGw7XHJcbiAgICAgICAgICAgIHNlbGYuZnJpZW5kTGlzdC5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgc2VsZi5zZWFyY2hlZGZyaWVuZExpc3QuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAvL+atpOWkhOe7meacjeWKoeWZqOWPkemAgeivt+axglxyXG4gICAgICAgIHZhciAgY29udGVudCA9IEpTT04uc3RyaW5naWZ5KHtUeXBlOjEwMDU3LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBXb3JkczpzZWxmLnNlYXJjaGVkRnJpZW5kTmFtZS5zdHJpbmcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7ICAgICAgICAgXHJcblxyXG4gICAgICAgIGlmKHNlbGYuc2VhcmNoZWRGcmllbmROYW1lLnN0cmluZyAhPVwiXCIpey8v5Y+R6YCB5pCc57Si5aeT5ZCN5LiN5Li656m65pe2XHJcbiAgICAgICAgY2MubG9nKFwi5ZCR5aW95Y+L5pyN5Yqh5Zmo5Y+R6YCB6K+35rGC5pCc57Si5aW95Y+L5raI5oGv77yaXCIpO1xyXG4gICAgICAgIGNjLmxvZyhKU09OLnBhcnNlKGNvbnRlbnQpKTtcclxuICAgICAgICBjYy5sb2coMik7XHJcbiAgICAgICAgc29rZXQud3Muc2VuZChjb250ZW50KTsvL+WPkemAgea2iOaBryBcclxuICAgICAgICBzb2tldC5nZXRDaGF0TXNnKCk7Ly/nm5HlkKzojrflj5bkv6Hmga8gXHJcbiAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICBzZWxmLmZyaWVuZExpc3QuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgIHNlbGYuc2VhcmNoZWRmcmllbmRMaXN0LmFjdGl2ZSA9IGZhbHNlOyAgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHNlbGYuc2VhcmNoZWRGcmllbmROYW1lLlBsYWNlaG9sZGVyID0gXCLlnKjmraTovpPlhaXmkJzntKLlp5PlkI0uLi4uLi4uXCI7XHJcbiAgICB9LFxyXG5cclxuICAgIC8v5Yid5aeL5YyW5pCc57Si546p5a625YiX6KGoXHJcbiAgICBJbml0U2VhcmNoZWRGcmllbmQ6ZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgaWYodXNlcmRhdGEuc2VhcmNoRnJpZW5kSW5mbz09bnVsbCl7XHJcblxyXG4gICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAvLyAgY2MubG9nKHNlbGYuc2VhcmNoQ291bnQpO1xyXG4gICAgICAgICAgICAvLyAgaWYoc2VsZi5zZWFyY2hDb3VudD4xKXtcclxuICAgICAgICAgICAgLy8gICAgIHNlbGYuQ2xlYXJTZWFyY2hlZCgpO1xyXG4gICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgIGZvcih2YXIgaSA9c2VsZi5zZWFyY2hlZEZyaWVuZExpc3RDb250ZW50LmNoaWxkcmVuLmxlbmd0aC0xOyBpID49MDtpLS0pe1xyXG4gICAgICAgICAgICAgICAgc2VsZi5zZWFyY2hlZEZyaWVuZExpc3RDb250ZW50LnJlbW92ZUNoaWxkKHNlbGYuc2VhcmNoZWRGcmllbmRMaXN0Q29udGVudC5jaGlsZHJlbltpXSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgc2VsZi5pdGVtcy5sZW5ndGggPSB1c2VyZGF0YS5zZWFyY2hGcmllbmRJbmZvLmxlbmd0aDtcclxuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBzZWxmLml0ZW1zLmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgaXRlbSA9IGNjLmluc3RhbnRpYXRlKHNlbGYuaXRlbUZyaWVuZFByZWZhYik7XHJcbiAgICAgICAgICAgICAgICBpdGVtLmNvbG9yID0gbmV3IGNjLkNvbG9yKDAsMTkxLDI1NSk7XHJcbiAgICAgICAgICAgICAgICBzZWxmLml0ZW1zW2ldID0gdXNlcmRhdGEuc2VhcmNoRnJpZW5kSW5mb1tpXTtcclxuICAgICAgICAgICAgICAgIHZhciBkYXRhID0gc2VsZi5pdGVtc1tpXTtcclxuICAgICAgICAgICAgICAgIHNlbGYubm9kZS5hZGRDaGlsZChpdGVtKTtcclxuICAgICAgICAgICAgICAgIGl0ZW0uZ2V0Q29tcG9uZW50KCdJdGVtRnJpZW5kJykuaW5pdCh7XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ6IGRhdGEuSUQsXHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbU5hbWU6IGRhdGEuRnJpZW5kTmFtZSxcclxuICAgICAgICAgICAgICAgICAgICBpdGVtR3JhZGU6IFwi5YiG5pWwOlwiK2RhdGEuRnJpZW5kR3JhZGUsXHJcbiAgICAgICAgICAgICAgICAgICAgaWNvblNGOiBzZWxmLmhlYWRBdGxhcy5nZXRTcHJpdGVGcmFtZShkYXRhLkZyaWVuZEljb24pLFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgc2VsZi5zZWFyY2hlZEZyaWVuZExpc3RDb250ZW50LmhlaWdodCA9IDIwMCAr44CAdXNlcmRhdGEuc2VhcmNoRnJpZW5kSW5mby5sZW5ndGgqNjA7ICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICAvL+WinuWKoOWlveWPi+aMiemSruWTjeW6lOWHveaVsFxyXG4gICAgQWRkRnJpZW5kOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIC8v5q2k5aSE57uZ5pyN5Yqh5Zmo5Y+R6YCB6K+35rGCXHJcblxyXG4gICAgICAgIGlmKHNlbGYuZnJpZW5kTGlzdC5hY3RpdmUgPT0gZmFsc2UmJnNlbGYuc2VhcmNoZWRmcmllbmRMaXN0LmFjdGl2ZSA9PSB0cnVlKXtcclxuICAgICAgICAgICAgaWYodXNlcmRhdGEuc2VsZWN0ZWRGcmllbmRJRCA9PSBudWxsKXtcclxuICAgICAgICAgICAgICAgIGNjLmxvZyhcIuivt+WFiOmAieaLqeaDs+a3u+WKoOeahOWlveWPiy5cIik7XHJcbiAgICAgICAgICAgIH1lbHNlIGlmKHNlbGYuQ29udGFpbnModXNlcmRhdGEuZnJpZW5kSW5mbyx1c2VyZGF0YS5zZWxlY3RlZEZyaWVuZElEKSl7XHJcbiAgICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIueOsOacieWlveWPi+S4reW3suWtmOWcqOaDs+WinuWKoOeahOWlveWPi1wiKTtcclxuICAgICAgICAgICAgICAgICAgICAgc2VsZi5mcmllbmRMaXN0LmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgIHNlbGYuc2VhcmNoZWRmcmllbmRMaXN0LmFjdGl2ZSA9IGZhbHNlOyBcclxuICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICB2YXIgIGNvbnRlbnQgPSBKU09OLnN0cmluZ2lmeSh7VHlwZToxMDA2MSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOYW1lOnNlbGYuR2V0QWRkSXRlbSh1c2VyZGF0YS5zZWxlY3RlZEZyaWVuZElEKS5GcmllbmROYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pOyAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgY2MubG9nKFwi5ZCR5aW95Y+L5pyN5Yqh5Zmo5Y+R6YCB6K+35rGC5aKe5Yqg5aW95Y+L5raI5oGv77yaXCIpO1xyXG4gICAgICAgICAgICAgICAgY2MubG9nKEpTT04ucGFyc2UoY29udGVudCkpO1xyXG4gICAgICAgICAgICAgICAgc29rZXQud3Muc2VuZChjb250ZW50KTsvL+WPkemAgea2iOaBryBcclxuICAgICAgICAgICAgICAgIHNva2V0LmdldENoYXRNc2coKTsvL+ebkeWQrOiOt+WPluS/oeaBr1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgIGNjLmxvZyhcIuivt+WFiOaQnOe0ouaDs+a3u+WKoOeahOWlveWPiy5cIik7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvL+WTjeW6lOWinuWKoOWlveWPi+WHveaVsFxyXG4gICAgQW5zd2VyQWRkRnJpZW5kOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIGlmKHNva2V0LmlzU2VuZEFkZEZyaWVuZCA9PSB0cnVlKXtcclxuICAgICAgICAgICAgc29rZXQuaXNTZW5kQWRkRnJpZW5kID0gZmFsc2U7XHJcbiAgICAgICAgICAgIC8vIHNlbGYuZnJpZW5kTGlzdC5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAvLyBzZWxmLnNlYXJjaGVkZnJpZW5kTGlzdC5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICB9IFxyXG4gICAgICAgIFxyXG4gICAgICAgIGlmKHNva2V0LmlzQWRkRnJpZW5kID09IHRydWUpe1xyXG4gICAgICAgICAgICBjYy5sb2coXCLlt7Lnu4/lop7liqDlpb3lj4vmiJDlip9cIik7XHJcbiAgICAgICAgICAgIHNlbGYuVXBkYXRlRnJpZW5kTGlzdCgpO1xyXG4gICAgICAgICAgICBzb2tldC5pc0FkZEZyaWVuZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICBzZWxmLmZyaWVuZExpc3QuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgc2VsZi5zZWFyY2hlZGZyaWVuZExpc3QuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHVzZXJkYXRhLnNlbGVjdGVkRnJpZW5kTmFtZSAgPSBudWxsO1xyXG4gICAgICAgICAgICB1c2VyZGF0YS5zZWxlY3RlZEZyaWVuZElEID0gbnVsbDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmKHNva2V0LmlzUmVqZWN0QWRkRnJpZW5kID09IHRydWUpe1xyXG4gICAgICAgICAgICBjYy5sb2coXCLor6Xnjqnlrrblt7Lnu4/mi5Lnu53mt7vliqDlpb3lj4tcIik7XHJcbiAgICAgICAgICAgIHNva2V0LmlzUmVqZWN0QWRkRnJpZW5kID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHNlbGYuZnJpZW5kTGlzdC5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICBzZWxmLnNlYXJjaGVkZnJpZW5kTGlzdC5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgdXNlcmRhdGEuc2VsZWN0ZWRGcmllbmROYW1lICA9IG51bGw7XHJcbiAgICAgICAgICAgIHVzZXJkYXRhLnNlbGVjdGVkRnJpZW5kSUQgPSBudWxsO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy/or7fmsYLmlrnmm7TmlrDlpb3lj4vliJfooahcclxuICAgIFVwZGF0ZUZyaWVuZExpc3Q6ZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7ICAgXHJcbiAgICAgICAgc2VsZi5mcmllbmRMaXN0LmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgdmFyIGl0ZW0gPSBjYy5pbnN0YW50aWF0ZShzZWxmLml0ZW1GcmllbmRQcmVmYWIpO1xyXG4gICAgICAgIHZhciBkYXRhID0gc2VsZi5HZXRBZGRJdGVtKHVzZXJkYXRhLnNlbGVjdGVkRnJpZW5kSUQpO1xyXG4gICAgICAgICBpdGVtLmdldENvbXBvbmVudCgnSXRlbUZyaWVuZCcpLmluaXQoe1xyXG4gICAgICAgICAgICAgICAgaWQ6IGRhdGEuSUQsXHJcbiAgICAgICAgICAgICAgICBpdGVtTmFtZTogZGF0YS5GcmllbmROYW1lLFxyXG4gICAgICAgICAgICAgICAgaXRlbUdyYWRlOiBcIuWIhuaVsDpcIitkYXRhLkZyaWVuZEdyYWRlLFxyXG4gICAgICAgICAgICAgICAgaWNvblNGOiBzZWxmLmhlYWRBdGxhcy5nZXRTcHJpdGVGcmFtZShkYXRhLkZyaWVuZEljb24pLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICBzZWxmLmZyaWVuZExpc3RDb250ZW50LmFkZENoaWxkKGl0ZW0pO1xyXG4gICAgICAgIHNlbGYuQ2xlYXJTZWFyY2hlZCgpO1xyXG4gICAgfSxcclxuXHJcbiAgICAvL+a4heepuuaQnOe0ouWIl+ihqFxyXG4gICAgQ2xlYXJTZWFyY2hlZDpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBmb3IodmFyIGkgPXNlbGYuc2VhcmNoZWRGcmllbmRMaXN0Q29udGVudC5jaGlsZHJlbi5sZW5ndGgtMTsgaSA+PTA7aS0tKXtcclxuICAgICAgICAgICAgc2VsZi5zZWFyY2hlZEZyaWVuZExpc3RDb250ZW50LnJlbW92ZUNoaWxkKHNlbGYuc2VhcmNoZWRGcmllbmRMaXN0Q29udGVudC5jaGlsZHJlbltpXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZyaWVuZC5DbGVhcl9saXN0KHVzZXJkYXRhLnNlYXJjaEZyaWVuZEluZm8pO1xyXG4gICAgfSxcclxuICAgIC8v56Gu5a6a6KaB5aKe5Yqg55qEaXRlbVxyXG4gICAgR2V0QWRkSXRlbTpmdW5jdGlvbihmcmllbmRJRCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIGZvcih2YXIgaSA9IDA7IGk8dXNlcmRhdGEuc2VhcmNoRnJpZW5kSW5mby5sZW5ndGg7KytpKXtcclxuICAgICAgICAgICAgdmFyIGlkID0gdXNlcmRhdGEuc2VhcmNoRnJpZW5kSW5mb1tpXS5JRDtcclxuICAgICAgICAgICAgaWYoIGlkID09IGZyaWVuZElEKXtcclxuICAgICAgICAgICAgICAgIHJldHVybiB1c2VyZGF0YS5zZWFyY2hGcmllbmRJbmZvW2ldO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvL+agh+iusOW9k+WJjeeCueWHu+eahOWlveWPi1xyXG4gICAgU2lnblNlbGVjdGVkRnJpZW5kOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIGZvcih2YXIgaSA9IDA7aTxzZWxmLnNlYXJjaGVkRnJpZW5kTGlzdENvbnRlbnQuY2hpbGRyZW4ubGVuZ3RoOysraSl7XHJcbiAgICAgICAgICAgIHZhciBpZCA9IHNlbGYuc2VhcmNoZWRGcmllbmRMaXN0Q29udGVudC5jaGlsZHJlbltpXS5nZXRDaGlsZEJ5TmFtZShcImlkXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nO1xyXG4gICAgICAgICAgICBpZiggaWQgPT0gdXNlcmRhdGEuc2VsZWN0ZWRGcmllbmRJRCl7XHJcbiAgICAgICAgICAgICAgICBzZWxmLnNlYXJjaGVkRnJpZW5kTGlzdENvbnRlbnQuY2hpbGRyZW5baV0uZ2V0Q2hpbGRCeU5hbWUoXCJzZWxlY3RpbmdcIikuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICBzZWxmLnNlYXJjaGVkRnJpZW5kTGlzdENvbnRlbnQuY2hpbGRyZW5baV0uZ2V0Q2hpbGRCeU5hbWUoXCJzZWxlY3RpbmdcIikuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IFxyXG4gICAgfSxcclxuXHJcbiAgICAvL+WIpOaWreeOsOacieWlveWPi+S4reaYr+WQpuW3suWtmOWcqOaDs+WinuWKoOeahOWlveWPi1xyXG4gICAgQ29udGFpbnM6ZnVuY3Rpb24oYXJyYXksZnJpZW5kSUQpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBmb3IodmFyIGkgPSAwOyBpIDwgYXJyYXkubGVuZ3RoOysraSl7XHJcbiAgICAgICAgICAgIHZhciBpZCA9IGFycmF5W2ldLklEO1xyXG4gICAgICAgICAgICBpZiggaWQgPT0gZnJpZW5kSUQpe1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7Ly/lrZjlnKhcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gZmFsc2U7ICBcclxuICAgIH0sXHJcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xyXG4gICAgdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgIHNva2V0LmdldENoYXRNc2coKTsvL+ebkeWQrOiOt+WPluS/oeaBryBcclxuICAgICAgICBzZWxmLmZyaWVuZENoYXROYW1lMS5zdHJpbmcgPSBcIuiBiuWkqeWlveWPi++8mlwiK+OAgHVzZXJkYXRhLnNlbGVjdGVkRnJpZW5kTmFtZSArIFwiICBcIit1c2VyZGF0YS5zZWxlY3RlZEZyaWVuZElEO1xyXG4gICAgICAgIHNlbGYuZnJpZW5kQ2hhdE5hbWUyLnN0cmluZyA9IFwi5pS25Lu25Lq677yaXCIr44CAdXNlcmRhdGEuc2VsZWN0ZWRGcmllbmROYW1lICsgXCIgIFwiK3VzZXJkYXRhLnNlbGVjdGVkRnJpZW5kSUQ7XHJcbiAgICAgICAgc2VsZi5Jbml0U2VhcmNoZWRGcmllbmQoKTtcclxuICAgICAgICBzZWxmLkFuc3dlckFkZEZyaWVuZCgpO1xyXG4gICAgICAgIHNlbGYuU2lnblNlbGVjdGVkRnJpZW5kKCk7XHJcbiAgICB9LFxyXG59KTtcclxuIiwidmFyIGZyaWVuZCA9IHJlcXVpcmUoJ0ZyaWVuZEFjdGl2aXR5Jyk7XHJcbnZhciB1c2VyZGF0YSA9IHJlcXVpcmUoJ1VzZXJEYXRhJyk7XHJcbi8vc29rZXTlt6XlhbfmqKHmnb9cclxubW9kdWxlLmV4cG9ydHMgPSB7XHJcbiAgICB3czpudWxsLFxyXG4gICAgbWVzOm51bGwsXHJcbiAgICAvL+a4uOaIj+WGheiBiuWkqVxyXG4gICAgY2hhdFN0cmluZzpcIueOqeWutuWPkeiogOWmguS4i++8mlwiLC8v5ri45oiP5YaF6IGK5aSp5L+h5oGvXHJcbiAgICBjaGF0SGVpZ2h0QWRkOjAsLy/muLjmiI/lhoXogYrlpKnkv6Hmga/moYbpq5jluqblop7liqBcclxuICAgIHNlYXQ6QXJyYXkoKSwvL+aUtuWIsOeahOeUqOaIt+eahOW6p+S9jeWPt1xyXG4gICAgbmFtZTpBcnJheSgpLC8v5pS25Yiw55qE55So5oi355qE5aeT5ZCNXHJcblxyXG4gICAgLy/lpb3lj4vns7vnu5/vvIjlop7liKDlpb3lj4vvvIlcclxuICAgIGlzQWRkRnJpZW5kOmZhbHNlLC8v5piv5ZCm5aKe5Yqg5aW95Y+LXHJcbiAgICBpc1NlbmRBZGRGcmllbmQ6ZmFsc2UsLy/mmK/lkKblt7Llj5HpgIHlop7liqDlpb3lj4tcclxuICAgIGlzUmVqZWN0QWRkRnJpZW5kOmZhbHNlLC8v5piv5ZCm5ouS57ud5aKe5Yqg5aW95Y+LXHJcbiAgICBpc0RlbGV0ZUZyaWVuZDpmYWxzZSwvL+aYr+WQpuWIoOmZpOWlveWPi1xyXG4gICAgaGFzQmVlbkRlbGV0ZWQ6ZmFsc2UsLy/mmK/lkKblt7LooqvliKDpmaTlpb3lj4tcclxuXHJcbiAgICAvL+WlveWPi+ezu+e7n++8iOWlveWPi+mXtOiBiuWkqe+8iVxyXG4gICAgY2hhdEZyaWVuZDpBcnJheSgpLC8v5ZKM5aW95Y+L6IGK5aSp5L+h5oGvXHJcbiAgICBpc0luaXRDaGF0OmZhbHNlLC8v5piv5ZCm5Yid5aeL5YyW5ZKM5aW95Y+L55qE6IGK5aSp5L+h5oGvXHJcbiAgICBcclxuICAgIGNvbm5lY3Q6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGY9dGhpcztcclxuICAgICAgICBzZWxmLndzID1uZXcgV2ViU29ja2V0KFwid3M6Ly8xOTIuMTY4LjAuMjI5OjEwODAvd3NcIixbXSk7XHJcbiAgICB9LFxyXG4gICAgY2xvc2Vfd3M6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGY9dGhpcztcclxuICAgICAgICBzZWxmLndzLmNsb3NlKCk7XHJcbiAgICB9LFxyXG4gICAgLy/mlLbliLDogYrlpKnmnI3liqHlmajnmoTov5Tlm57lgLxcclxuICAgICBnZXRDaGF0TXNnOmZ1bmN0aW9uICgpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBzZWxmLndzLm9ubWVzc2FnZSA9IGZ1bmN0aW9uKGUpe1xyXG4gICAgICAgICAgICBzZWxmLm1lcyA9IGUuZGF0YTtcclxuICAgICAgICAgICAgY2MubG9nKFwi6L+e5o6l5pyN5Yqh5Zmo5oiQ5YqfLi4uLi4uXCIpO1xyXG4gICAgICAgICAgICBjYy5sb2coXCLmlLbliLDmnI3liqHlmajmtojmga9cIik7XHJcbiAgICAgICAgICAgIHNlbGYubWVzID0gSlNPTi5wYXJzZShzZWxmLm1lcyk7XHJcbiAgICAgICAgICAgIGNjLmxvZyhzZWxmLm1lcyk7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoc2VsZi5tZXMuVHlwZSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxMDA0MjpcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCLmnKznlKjmiLfov5vlhaXogYrlpKnlrqTmiJDlip9JROS4uu+8mlwiK3NlbGYubWVzLk5hbWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNlbGYuc2VhdC5wdXNoKHNlbGYubWVzLk1zZWF0KTtcclxuICAgICAgICAgICAgICAgICAgICBzZWxmLm5hbWUucHVzaChzZWxmLm1lcy5OYW1lKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgMTAwNDY6XHJcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5jaGF0SGVpZ2h0QWRkKz0xOy8vY29udGVudOWinuWKoOS4gOasoemrmOW6plxyXG4gICAgICAgICAgICAgICAgICAgIHNlbGYuY2hhdFN0cmluZyA9IHNlbGYuY2hhdFN0cmluZytcIlxcblwiK3NlbGYubWVzLk5hbWUrXCIg5Y+R6KiA77yaXCIrc2VsZi5tZXMuVGV4dDtcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coc2VsZi5jaGF0U3RyaW5nKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgMTAwNTA6XHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwi5pys55So5oi36L+b5YWl6IGK5aSp5a6k5aSx6LSlXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxMDA1NTpcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCLmnKznlKjmiLfmlLbliLDlpb3lj4vkv6Hmga9cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgZnJpZW5kLmZyaWVuZE51bSA9IHNlbGYubWVzLkZudW07XHJcbiAgICAgICAgICAgICAgICAgICAgaWYodXNlcmRhdGEuZnJpZW5kSW5mbyAhPSBudWxsJiZ1c2VyZGF0YS5mcmllbmRJbmZvLmxlbmd0aCE9MCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZyaWVuZC5DbGVhcl9saXN0KHVzZXJkYXRhLmZyaWVuZEluZm8pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBmcmllbmQuSW5pdF9mcmllbmQoc2VsZi5tZXMuRnJpZW5kcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5pc0luaXRDaGF0ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgMTAwNTg6XHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwi5pys55So5oi35pS25Yiw5pCc57Si5aW95Y+L5L+h5oGvXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIGZyaWVuZC5zZWFyY2hGcmllbmROdW0gPSBzZWxmLm1lcy5GbnVtO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmKHVzZXJkYXRhLnNlYXJjaEZyaWVuZEluZm8gIT0gbnVsbCYmdXNlcmRhdGEuc2VhcmNoRnJpZW5kSW5mby5sZW5ndGghPTApe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmcmllbmQuQ2xlYXJfbGlzdCh1c2VyZGF0YS5zZWFyY2hGcmllbmRJbmZvKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZnJpZW5kLkluaXRfc2VhcmNoX2ZyaWVuZChzZWxmLm1lcy5GcmllbmRzKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgMTAwNzE6XHJcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5pc0RlbGV0ZUZyaWVuZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwi5Yig6Zmk5aW95Y+L5oiQ5YqfXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIGZyaWVuZC5EZWxldGVfZnJpZW5kKHVzZXJkYXRhLnNlbGVjdGVkRnJpZW5kSUQpO1xyXG4gICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgMTAwNzI6XHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwi5L2g6KKr5Yig6Zmk5aW95Y+L5LqGXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNlbGYuaGFzQmVlbkRlbGV0ZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgMTAwNjM6XHJcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5pc0FkZEZyaWVuZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwi5aKe5Yqg5aW95Y+L5oiQ5YqfXCIpOyAgICBcclxuICAgICAgICAgICAgICAgICAgICBmcmllbmQuQWRkX2ZyaWVuZCh1c2VyZGF0YS5zZWxlY3RlZEZyaWVuZElEKTtcclxuICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDEwMDY0OiAgXHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwi6K+l546p5a6256a757q/5oiW5LiN5a2Y5ZyoXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgMTAwNjU6ICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIuivpeeOqeWutuaLkue7neWlveWPi+ivt+axglwiKTtcclxuICAgICAgICAgICAgICAgICAgICBzZWxmLmlzUmVqZWN0QWRkRnJpZW5kID0gdHJ1ZTsgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxMDA2NjogIFxyXG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIuWlveWPi+ivt+axguW3suWPkemAgVwiKTtcclxuICAgICAgICAgICAgICAgICAgICBzZWxmLmlzU2VuZEFkZEZyaWVuZCA9IHRydWU7ICAgXHJcbiAgICAgICAgICAgICAgICAgICAgIGJyZWFrOyAgXHJcbiAgICAgICAgICAgICAgICBjYXNlIDEwMDY4OiAgXHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwi5Ye6546w5aW95Y+L6K+35rGCXCIpOyAgICBcclxuICAgICAgICAgICAgICAgICAgICBmcmllbmQuSW5pdF9hc2tpbmdfZnJpZW5kKHNlbGYubWVzKTtcclxuICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDEwMDc2OiAgXHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwi6IGK5aSp5L+h5oGv5bey5Y+R6YCBXCIpOyAgICBcclxuICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDEwMDc4OiAgXHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwi6IGK5aSp5L+h5oGv5bey6L2s5Y+R5oiQ5YqfXCIpOyAgICBcclxuICAgICAgICAgICAgICAgICAgICBzZWxmLmNoYXRGcmllbmRbc2VsZi5tZXMuUF9pZF0uY2hhdEZyaWVuZEhlaWdodEFkZCs9MTsvL2NvbnRlbnTlop7liqDkuIDmrKHpq5jluqZcclxuICAgICAgICAgICAgICAgICAgICBzZWxmLmNoYXRGcmllbmRbc2VsZi5tZXMuUF9pZF0uY2hhdEZyaWVuZFN0cmluZyA9IFxyXG4gICAgICAgICAgICAgICAgICAgIHNlbGYuY2hhdEZyaWVuZFtzZWxmLm1lcy5QX2lkXS5jaGF0RnJpZW5kU3RyaW5nK1wiXFxuXCIrZnJpZW5kLkdldEZyaWVuZE5hbWUoc2VsZi5tZXMuUF9pZCkrXCLvvJpcIitzZWxmLm1lcy5UZXh0O1xyXG4gICAgICAgICAgICAgICAgICAgICBicmVhazsgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gXHJcbiAgICAgfSAgXHJcbn1cclxuIiwiLy/lgqjlrZjnlKjmiLdJRO+8jOS7peWPiuavj+WxgOWvueaImOeahOeJjOS/oeaBr1xyXG5tb2R1bGUuZXhwb3J0cz17XHJcbiAgICBtbmFtZTpudWxsLC8v6Ieq5bex55qE5ZCN5a2XXHJcbiAgICBpZDpudWxsLC8v5a+55oiYaWRcclxuICAgIG1ncmFkZTpudWxsLC8v6Ieq5bex55qE56ev5YiGXHJcbiAgICB0b2tlbjpudWxsLC8vXHJcbiAgICBvbmFtZTpudWxsLC8v5a+56Z2i546p5a6255qE5ZCN5a2XXHJcbiAgICBvZ3JhZGU6bnVsbCwvL+WvuemdoueOqeWutueahOenr+WIhlxyXG4gICAgbG5hbWU6bnVsbCwvL+W3pui+ueeOqeWutueahOWQjeWtl1xyXG4gICAgbGdyYWRlOm51bGwsLy/lt6bovrnnjqnlrrbnmoTnp6/liIZcclxuICAgIHJuYW1lOm51bGwsLy/lj7PovrnnjqnlrrbnmoTlkI3lrZdcclxuICAgIHJncmFkZTpudWxsLC8v5Y+z6L65546p5a6255qE56ev5YiGXHJcbiAgICBtc2VhdDpudWxsLC8v6Ieq5bex55qE5bqn5L2N5Y+3XHJcbiAgICBvc2VhdDpudWxsLC8v5a+56Z2i546p5a625bqn5L2N5Y+3XHJcbiAgICBsc2VhdDpudWxsLC8v5bem6L65546p5a625bqn5L2N5Y+3XHJcbiAgICByc2VhdDpudWxsLC8v5Y+z6L65546p5a625bqn5L2N5Y+3XHJcbiAgICBtY2FyZDpudWxsLC8v5YKo5a2Y6Ieq5bex54mM55qEbWFwXHJcbiAgICBvY2FyZDpudWxsLC8v5YKo5a2Y5a+56Z2i546p5a6254mM55qEbWFwXHJcbiAgICBsY2FyZDpudWxsLC8v5YKo5a2Y5bem6L65546p5a6254mM55qEbWFwXHJcbiAgICByY2FyZDpudWxsLC8v5YKo5a2Y5Y+z6L65546p5a6254mM55qEbWFwXHJcbiAgICBmdHBsYXllcjpudWxsLC8v5YWI5omL5pG454mM546p5a62XHJcbiAgICB0Y2FyZDpudWxsLC8v5Y2V5pG455qE54mM55qE5L+h5oGvXHJcbiAgICBndWVzc2VkbWFuOm51bGwsLy/ooqvnjJzniYznmoTnjqnlrrbluqfkvY3lj7dcclxuICAgIGd1ZXNzZWRjYXJkOm51bGwsLy/ooqvnjJzniYznmoTkv6Hmga9cclxuICAgIHN1cnBsdXM6bnVsbCwvL+WJqeS9meWNoeeJjOWghuW8oOaVsFxyXG4gICAgaW5zZXJ0X2NvdW50Om51bGwsLy/mj5LniYzmrKHmlbBcclxuICAgIHJlc3RjYXJkOm51bGwsLy/niYzloIbmmK/lkKbliankvZnniYxcclxuICAgIGNhcmRzQXJlTnVsbDpudWxsLC8v5Yik5pat54mM5aCG5oGw5aW95Li65Li656m6XHJcbiAgICBjaGF0Um9vbUtleTpudWxsLC8v6IGK5aSp5a6k57yW5Y+3XHJcbiAgICByZXN0QmxhY2tDb3VudDpudWxsLC8v5byA5aeL5ri45oiP5pe254mM5rGg5Ymp5L2Z55qE6buR54mM5pWwXHJcbiAgICByZXN0V2hpdGVDb3VudDpudWxsLC8v5byA5aeL5ri45oiP5pe254mM5rGg5Ymp5L2Z55qE55m954mM5pWwXHJcbiAgICByb3VuZDpudWxsLC8v5b2T5YmN5Zue5ZCI5pWwXHJcbiAgICBmcmllbmRJbmZvOm51bGwsLy/lrZjlgqjlpb3lj4vkv6Hmga9cclxuICAgIHNlbGVjdGVkRnJpZW5kTmFtZTpcIlwiLC8v6YCJ5oup55qE5aW95Y+L5ZCNXHJcbiAgICBzZWxlY3RlZEZyaWVuZElEOm51bGwsLy/pgInmi6nnmoTlpb3lj4tpZFxyXG4gICAgc2VhcmNoRnJpZW5kSW5mbzpudWxsLC8v5a2Y5YKo5pCc57Si55qE546p5a625L+h5oGvXHJcbiAgICBhc2tpbmdGcmllbmRJbmZvOm51bGwsLy/lrZjlgqjor7fmsYLnjqnlrrbkv6Hmga9cclxuICAgIG1haWxJbmZvOm51bGwsLy/lrZjlgqjpgq7ku7bkv6Hmga9cclxuICAgIHNlbGVjdGVkTWFpbElEOm51bGwsLy/pgInmi6nnmoTpgq7ku7ZpZFxyXG4gICAgXHJcbn07XHJcbiIsInZhciBodHRwID0gcmVxdWlyZSgnSHR0cFV0aWxzJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgLy8gZm9vOiB7XHJcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXHJcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxyXG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcclxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyAuLi5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB2YXIgd2FpdGluZ1RpbWUgPSAyMDAwO1xyXG4gICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCdHYW1lU2NlbmUnKTtcclxuICAgICAgICB9LHdhaXRpbmdUaW1lKTtcclxuICAgIH0sXHJcblxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcblxyXG4gICAgLy8gfSxcclxufSk7XHJcbiIsInZhciBodHRwID0gcmVxdWlyZSgnSHR0cFV0aWxzJyk7XHJcbnZhciB1c2VyZGF0YSA9IHJlcXVpcmUoXCJVc2VyRGF0YVwiKTtcclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBsYWJlbDE6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgbGFiZWwyOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcclxuICAgICAgICB9LFxyXG4gICAgICAgICBzdGFydEdhbWU6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgXHJcbiAgICAgXHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICBcclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKXtcclxuICAgICAgICB0aGlzLmxhYmVsMS5nZXRDb21wb25lbnQoY2MuQW5pbWF0aW9uKS5wbGF5KCdsYWJlbDFfbW92ZXJpZ2h0Jyk7XHJcbiAgICAgICAgdGhpcy5sYWJlbDIuZ2V0Q29tcG9uZW50KGNjLkFuaW1hdGlvbikucGxheSgnbGFiZWwyX21vdmVyaWdodCcpO1xyXG4gICAgICAgIHRoaXMuc3RhcnRHYW1lLmdldENvbXBvbmVudChjYy5BbmltYXRpb24pLnBsYXkoJ3N0YXJ0R2FtZV9tb3ZlcmlnaHQnKTtcclxuICAgIFxyXG4gICAgfSxcclxuICAgIC8v54K55Ye75byA5aeL5ri45oiP77yM6Lez6L2s5Yiw55m76ZmG55WM6Z2iIFxyXG4gICAgVG9Mb2dpbjogZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgdmFyIGJnPWNjLmZpbmQoXCJDYW52YXMvYmcxXCIpO1xyXG4gICAgICAgIHZhciBzZXEyPWNjLnNlcXVlbmNlKGNjLmZhZGVPdXQoMSksY2MuZGVsYXlUaW1lKDEuMDEpLGNjLmNhbGxGdW5jKFxyXG4gICAgICAgICAgICAgICAgIGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiTG9naW5TY2VuZVwiKTtcclxuICAgICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgIGJnLnJ1bkFjdGlvbihzZXEyKTtcclxuICAgICAgICBcclxuICAgIH0sXHJcbn0pO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9