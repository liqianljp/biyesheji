var http = require('HttpUtils');
var userdata = require('UserData');
var cardactivity=require('CardActivity');
var soket = require("SoketUtils");
cc.Class({
    extends: cc.Component,

    properties: {
        
        holdCards_4:{//4人游戏卡牌
            default:null,
            type:cc.Node
        },
        guess:{//猜牌弹出框
            default:null,
            type:cc.Node
        },
        guessbg:{//猜牌弹出框的背景
            default:null,
            type:cc.Node   
        },
        continue:{
            default:null,
            type:cc.Node               
        },
        continuebg:{//是否继续猜牌牌弹出框的背景
            default:null,
            type:cc.Node   
        },
        guessPointDisplay:{//猜牌弹出框上的显示的猜牌点数
            default:null,
            type:cc.EditBox             
        }, 
        insert_random:{//万能牌插入位置弹出框
            default:null,
            type:cc.Node
        },
        insert_randombg:{//万能牌插入位置弹出框的背景
            default:null,
            type:cc.Node   
        },
        insert_randomDisplay:{//万能牌插入位置弹出框显示的位置
            default:null,
            type:cc.EditBox             
        }, 
        gameover:{//游戏结束弹出框
            default:null,
            type:cc.Node,             
        },
        gameoverbg:{//游戏结束弹出框背景
            default:null,
            type:cc.Node,             
        },
        gameResultDisplay:{//游戏结束弹出框结果显示
            default:null,
            type:cc.Label,             
        },
        chatEdit:{//聊天输入信息框
            default:null,
            type:cc.EditBox,             
        },
        chatContent:{//聊天输入信息高度
            default:null,
            type:cc.Node,
        }, 
        chatLabel:{//聊天信息的item
            default:null,
            type:cc.Label,
        },
        newsContent:{//游戏历史消息高度
            default:null,
            type:cc.Node,
        }, 
        newsLabel:{//游戏历史消息的item
            default:null,
            type:cc.Label,
        },
        blackCountLabel:{//牌池剩余黑牌数显示
            default:null,
            type:cc.Label,
        }, 
        whiteCountLabel:{//牌池剩余白牌数显示
            default:null,
            type:cc.Label,
        },
        stepCountLabel:{//步时显示
            default:null,
            type:cc.Label,
        },
        roundCountLabel:{//回合数显示
            default:null,
            type:cc.Label,
        },
        myTurn:{//当前猜牌人是本方箭头
            default:null,
            type:cc.Node,
        },
        rightTurn:{//当前猜牌人右方箭头
            default:null,
            type:cc.Node,
        }, 
        oppositeTurn:{//当前猜牌人是对面箭头
            default:null,
            type:cc.Node,
        }, 
        leftTurn:{//当前猜牌人是左方箭头
            default:null,
            type:cc.Node,
        },
        rightInfo:{//右方玩家信息
            default:null,
            type:cc.Node,
        },
        oppositeInfo:{//对面玩家信息
            default:null,
            type:cc.Node,
        },
        leftInfo:{//左方玩家信息
            default:null,
            type:cc.Node,
        },
        newsDisplay:{//飘过的提示信息
            default:null,
            type:cc.Label,
        }, 
        isTimeOut:null,//步时是否为0
        stepCount:20,//步时计数                        
        playersNum:null,//玩家数量
        myCards:null,//存储本方手牌数组
        rightCards:null,//存储右方手牌数组
        oppositeCards:null,//存储对方手牌数组
        leftCards:null,//存储左方手牌数组
        url:null,//服务器ip地址
        guess_suit:null,//所猜牌的颜色
        guess_posi:null,//所猜牌的位置
        guess_point:null,//所猜的点数
        isepoll:null,//用来决定是否轮询
        myHolds:null,//自己手牌节点
        rightHolds:null,//右方手牌节点
        oppositeHolds:null,//对面手牌节点
        leftHolds:null,//左方手牌节点
        random_point:null,//假定的万能牌点数
        random_suit:null, //万能牌颜色
        newsHistoryAdd:0,//消息历史增加
        newsHistory:"消息历史如下：",
    },

    // use this for initialization
    onLoad: function (){
        var self=this;
        self.url="http://192.168.0.229:8080/test";
        self.OnlineEpoll();
        self.myCards=[];
        self.rightCards=[];
        self.oppositeCards=[];
        self.leftCards=[];
        self.bool1=false;
        self.bool2=false;
        self.newsDisplay.getComponent(cc.Animation).play('newsFlow');//提示信息飘过...
        userdata.guessedcard=new Map();
        // self.holdCards_2.active = false;
        // self.holdCards_3.active = false;
        self.holdCards_4.active = false;
        self.playersNum = 4;//默认4人游戏
        if(self.playersNum == 4){
            self.holdCards_4.active = true;//4人手牌出现
            self.rightInfo.active = true;
            self.oppositeInfo.active = true;
            self.leftInfo.active = true;
            self.insert_random.active = false;
            userdata.round = 1;
            self.OnlineChat();
            this.InitView();//初始化场景
            this.InitCards();//4人游戏开始，发牌
            this.DealCards();//4人游戏开始，摸牌
            userdata.restcard = true;//默认牌堆有牌
            userdata.cardsAreNull = 0;
            self.blackCountLabel.string = userdata.restBlackCount + "张";//初始化牌池剩余牌数量
            self.whiteCountLabel.string = userdata.restWhiteCount + "张";
            //步时倒计时
            self.UpdateLeftTime();
            http.isBackToHall = false;
        }
        self.isepoll=false;
        if(userdata.ftplayer===userdata.mseat){//初始结果轮询，如果本方是摸牌方跳过轮询
                    self.isepoll=false;
                }else{
                    self.isepoll=true;
                }
        self.ResultEpoll(self.isepoll);
    },
    //在线聊天请求
    OnlineChat:function(){
        var  askChat = JSON.stringify({Id:userdata.id,
                                      Type:10040,
                                      Mseat:userdata.mseat,//加一个自己的座位号
                                      Name:"666",
                                      Key:userdata.chatRoomKey});
                    cc.log("向聊天服务器发送请求");
                    cc.log(JSON.parse(askChat));
                    soket.connect();//建立websoket对象ws
                    soket.ws.onopen = function(){
                    soket.getChatMsg();
                    soket.ws.send(askChat);//发送消息
                    };
    },
    //点击发送聊天按钮
    sendChatString: function(){
        var self = this;
        cc.log("想发送的消息："+self.chatEdit.string);
        var  chatContent = JSON.stringify({Id:userdata.id,
                                           Type:10045,
                                           Name:"666",
                                           Key:userdata.chatRoomKey,
                                           Text:self.chatEdit.string
                                         });      
        soket.getChatMsg();
        if(self.chatEdit.string!=""){//发送消息不为空时
        cc.log("向聊天服务器发送聊天消息：");
        cc.log(JSON.parse(chatContent));
        soket.ws.send(chatContent);//发送消息
        }else{
            self.chatEdit.string = "输入消息不能为空！";
            setTimeout(function() {
                self.chatEdit.string ="";
            }, 1000);
        }
        self.chatEdit.Placeholder = "在此输入聊天信息.......";
    },
    //在线轮询
    OnlineEpoll:function(){
        var self=this;
        var online_sdmes=JSON.stringify({Id:userdata.id,
                    "Content":{"Type":10018}});
        var content="msg="+online_sdmes;
        http.HttpPost(self.url,content,function(online_rvmes){
            if (online_rvmes === -1) {
                //console.log("请检查网络");
            }else{
                var rv=JSON.parse(online_rvmes);
                if(rv.Type===10020){
                    cc.log("online");
                    setTimeout(function(){
                        self.OnlineEpoll();
                    },15000);
                }
            }
        })
    },

    //非猜牌方执行轮询结果
    ResultEpoll:function(e){
        var self = this;
        if(e){
            var content = JSON.stringify({Type:10025,
                                          Round:userdata.round
            });
            content = JSON.parse(content);
            var result_sdmes=JSON.stringify({Id:userdata.id,
                                             Content:content
            });
            var content="msg="+result_sdmes;
            http.HttpPost(self.url,content,function(result_mes){
                var result_rvmes=JSON.parse(result_mes);
                //cc.log(result_rvmes);
                if(result_rvmes.Type === 10024){//未返回猜牌信息
                    setTimeout(function(){
                        cc.log("未返回猜牌信息");
                        self.ResultEpoll(e);
                    },2000);
                }else if(result_rvmes.Type === 10023){//返回猜牌信息
                         cc.log("收到10023");
                         cc.log(result_rvmes);
                         userdata.round +=1;
                         self.roundCountLabel.string = userdata.round;
                         cardactivity.GuessResult(result_rvmes);
                         self.ChangeRandomPosi(result_rvmes);
                         if(userdata.ftplayer === result_rvmes.GuessSeat){
                            if(result_rvmes.Result==true){//返回猜牌信息,且猜对
                               cc.log("返回猜牌信息,且猜对");
                               if(result_rvmes.GuessCard.CardPoint==12){//上方飘过的提示消息
                                            self.newsDisplay.string = "玩家"+self.getNameBySeat(userdata.mseat)+
                                                                     "猜玩家"+self.getNameBySeat(userdata.guessedman)+"的第"+
                                                                     userdata.guessedcard.posi+"张牌为万能牌，猜错了";
                                        }else{
                                            self.newsDisplay.string = "玩家"+self.getNameBySeat(userdata.mseat)+
                                                                    "猜玩家"+self.getNameBySeat(userdata.guessedman)+"的第"+
                                                                     userdata.guessedcard.posi+"张牌为"+result_rvmes.GuessCard.CardPoint+"点，猜对了";
                                        }

                               self.newsHistory = self.newsHistory + "\n" + "第"+(userdata.round-1)+"回合："+self.newsDisplay.string;
                               self.newsHistoryAdd+=1;
                               self.newsDisplay.getComponent(cc.Animation).play('newsFlow');//提示信息飘过...        
                               self.MingBrang(userdata.guessedman,userdata.guessedcard,userdata.guessedcard.posi);
                               self.RoundChange();
                            }else if(result_rvmes.Result==false){
                                    //返回猜牌信息,且猜错 
                                    if(result_rvmes.TimeOut == false){//未超时猜错
                                    cc.log("返回猜牌信息,且猜错");
                                     if(result_rvmes.GuessCard.CardPoint==12){//上方飘过的提示消息
                                            self.newsDisplay.string = "玩家"+self.getNameBySeat(userdata.mseat)+
                                                                     "猜玩家"+self.getNameBySeat(userdata.guessedman)+"的第"+
                                                                     userdata.guessedcard.posi+"张牌为万能牌，猜错了";
                                        }else{
                                            self.newsDisplay.string = "玩家"+self.getNameBySeat(userdata.mseat)+
                                                                    "猜玩家"+self.getNameBySeat(userdata.guessedman)+"的第"+
                                                                     userdata.guessedcard.posi+"张牌为"+result_rvmes.GuessCard.CardPoint+"点，猜错了";
                                        }
                                    self.newsHistory = self.newsHistory + "\n" + "第"+(userdata.round-1)+"回合："+self.newsDisplay.string;
                                    self.newsHistoryAdd+=1;
                                    self.newsDisplay.getComponent(cc.Animation).play('newsFlow');//提示信息飘过...   
                                    if(userdata.restcard){//如果牌堆有牌
                                        cc.log(userdata.tcard);   
                                        self.MingBrang(userdata.ftplayer,userdata.tcard,self.myHolds.children.length);
                                    }
                                        self.RoundChange();
                                    }else if(result_rvmes.TimeOut == true){//超时
                                        cc.log("猜牌人超时！！！");
                                        self.newsDisplay.string = "玩家"+self.getNameBySeat(userdata.ftplayer)+"猜牌超时";
                                        self.newsHistory = self.newsHistory + "\n" + "第"+(userdata.round-1)+"回合："+self.newsDisplay.string;
                                        self.newsHistoryAdd+=1;
                                        self.newsDisplay.getComponent(cc.Animation).play('newsFlow');//提示信息飘过...
                                        if(userdata.restcard){//如果牌堆有牌
                                            self.MingBrang(userdata.ftplayer,userdata.tcard,self.myHolds.children.length);   
                                        }
                                        self.RoundChange();
                                    }                           
                             }
                         }else {
                             cc.log(1112223334444);
                            setTimeout(function(){
                                self.ResultEpoll(e);
                            },2000);
                         }
                }else if(result_rvmes.Type === 10035){
                         cc.log("出现胜利者");
                         if(userdata.restcard!= false && userdata.cardsAreNull!=1){
                            cardactivity.Over(result_rvmes);
                            self.InsertCards();  
                            setTimeout(function() {
                            cardactivity.Insert_card();
                                    }, 500);        
                            setTimeout(function() {
                            self.UpdateCardsInfo();
                            self.GameOver(result_rvmes);
                                    },2001);         
                         }else{
                            cardactivity.Over(result_rvmes);
                            self.GameOver(result_rvmes);//牌堆里的牌发完了时出现胜利者 
                         }
                }
            });
        }
    },

    //回合切换
    RoundChange:function(){
        cc.log("RoundChange执行");
         var self = this;
        
        var round_sdmes=JSON.stringify({Id:userdata.id,
                    "Content":{"Type":10028}});
        var content="msg="+round_sdmes;
        http.HttpPost(self.url,content,function(round_mes){
            if (round_mes == -1) {
            }else{
                var round_rvmes = JSON.parse(round_mes);
                cc.log("回合切换轮询接受信息如下：");
                cc.log(round_rvmes);
                switch(round_rvmes.Type){
                    case 10029:
                        setTimeout(function(){
                            cc.log("猜牌方继续猜牌继续轮询结果");
                            self.stepCount = 21;
                            self.ResultEpoll(self.isepoll);//猜牌方继续猜牌继续轮询结果
                        },1000);
                        break;

                    case 10030:
                        cc.log(222222);                   
                        if(round_rvmes.Tcard!=null){//如果牌堆不为空
                           self.InsertCards()
                           setTimeout(function(){
                               cardactivity.Insert_card();
                           }, 500);
                           
                        }else{
                            userdata.restcard = false;
                            userdata.cardsAreNull += 1;
                        }
                        if(round_rvmes.Tcard==null&&userdata.cardsAreNull==1){//如果牌堆为空且刚好为空（用来将最后一张摸的牌插入手牌）
                            self.InsertCards();
                           setTimeout(function() {
                               cardactivity.Insert_card();
                           }, 500); 
                        }

                        setTimeout(function(){ 
                            self.UpdateCardsInfo();
if(userdata.mseat === userdata.ftplayer){
            for(var i=0;i<userdata.mcard.size;++i){
                cc.log((i+1)+".position="+self.myCards[i].posi+","+(i+1)+".point="+self.myCards[i].point+","+(i+1)+".color="+self.myCards[i].suit);
            }
        }else if(userdata.rseat === userdata.ftplayer){  
            for(var i=0;i<userdata.rcard.size;++i){
                 cc.log((i+1)+".position="+self.rightCards[i].posi+","+(i+1)+".point="+self.rightCards[i].point+","+(i+1)+".color="+self.rightCards[i].suit);
            }
        }else if(userdata.oseat === userdata.ftplayer){      
            for(var i=0;i<userdata.ocard.size;++i){
                 cc.log((i+1)+".position="+self.oppositeCards[i].posi+","+(i+1)+".point="+self.oppositeCards[i].point+","+(i+1)+".color="+self.oppositeCards[i].suit);              
            }
        }else if(userdata.lseat === userdata.ftplayer){            
            for(var i=0;i<userdata.lcard.size;++i){
                 cc.log((i+1)+".position="+self.leftCards[i].posi+","+(i+1)+".point="+self.leftCards[i].point+","+(i+1)+".color="+self.leftCards[i].suit);              
            }
        }                             
                           userdata.ftplayer=round_rvmes.Touchp;
                           if(round_rvmes.Tcard!=null){
                              cardactivity.Tcard(round_rvmes.Tcard);
                              self.DealCards();
                              self.blackCountLabel.string = round_rvmes.RestCard.black + "张";
                              self.whiteCountLabel.string = round_rvmes.RestCard.white + "张";
                           }
                            self.stepCount = 21;
                            if(userdata.ftplayer===userdata.mseat){
                                self.isepoll=false;
                            }else{
                                self.isepoll=true;
                            }
                            setTimeout(function(){
                                cc.log("不是猜牌方将继续轮询结果；是猜牌方时将失效");
                                self.ResultEpoll(self.isepoll);//不是猜牌方将继续轮询结果；是猜牌方时将失效
                            },3000);
                        }, 2000);
                        break;

                    case 10031:   
                        setTimeout(function(){
                            self.RoundChange();//不是猜牌方将继续轮询结果；是猜牌方时将失效
                        },500);
                        break;           
                }
            }
        });
    },

    //初始化场景
    InitView:function(){
        var self = this;
        //搜索需要的子节点
        var holdCardsChild = self.node.getChildByName("num_4");
        self.myHolds = holdCardsChild.getChildByName("player1_cards");//自己的手牌
        self.rightHolds = holdCardsChild.getChildByName("player2_cards");//右边的手牌
        self.oppositeHolds = holdCardsChild.getChildByName("player3_cards");//对面的手牌
        self.leftHolds = holdCardsChild.getChildByName("player4_cards");//左边的手牌
        
        for(var i = 0; i < self.myHolds.children.length; ++i){
            self.myHolds.children[i].active = false;
        }
        for(var i = 0; i < self.rightHolds.children.length; ++i){
            self.rightHolds.children[i].active = false;
        }
        for(var i = 0; i < self.oppositeHolds.children.length; ++i){
            self.oppositeHolds.children[i].active = false;
        }
        for(var i = 0; i < self.leftHolds.children.length; ++i){
            self.leftHolds.children[i].active = false;
        }
        
        setTimeout(function() {
           self.ShowPlayerInfo();//显示玩家信息 
        }, 2000);                           
    },

    //4人游戏开始，发牌
    InitCards:function() {
        var self = this;
        //确定猜牌人位置
        self.GuessTurn();   
        //发自己的牌，开始只有3张牌
        for(var i = 0;i < 3; i++){
             self.myHolds.children[i].active = true;
             var sprite = self.myHolds.children[i].getComponent(cc.Sprite);
             self.SetSpriteFrameByCardID("M_",userdata.mcard.get(i).suit,userdata.mcard.get(i).point,sprite);//我方的牌如实显示
             self.SetCardsInfo(self.myCards,i,userdata.mcard.get(i));
        }
       
        //发右边的牌，开始只有3张牌
        for(var i = 0;i < 3; i++){
             self.rightHolds.children[i].active = true;
             var sprite = self.rightHolds.children[i].getComponent(cc.Sprite);
             self.SetSpriteFrameByCardID("R_",userdata.rcard.get(i).suit,13,sprite); //右边的牌显示为未知的
             self.SetCardsInfo(self.rightCards,i,userdata.rcard.get(i));//存储右边卡牌信息
             self.GuessCards(sprite.node);//猜右边的牌
        }   
        //发对面的牌，开始只有3张牌
        for(var i = 0;i < 3; i++){
             self.oppositeHolds.children[i].active = true;
             var sprite = self.oppositeHolds.children[i].getComponent(cc.Sprite);
             self.SetSpriteFrameByCardID("O_",userdata.ocard.get(i).suit,13,sprite); //对面的牌显示为未知的
             self.SetCardsInfo(self.oppositeCards,i,userdata.ocard.get(i));//存储对面卡牌信息
             self.GuessCards(sprite.node);//猜对面的牌
        }
        //发左边的牌，开始只有3张牌
        for(var i = 0;i < 3; i++){
             self.leftHolds.children[i].active = true;
             var sprite = self.leftHolds.children[i].getComponent(cc.Sprite);
             self.SetSpriteFrameByCardID("L_",userdata.lcard.get(i).suit,13,sprite); //左边的牌显示为未知的
             self.SetCardsInfo(self.leftCards,i,userdata.lcard.get(i));//存储左边卡牌信息
             self.GuessCards(sprite.node); //猜左边的牌
        }                         
    },

     //4人游戏开始，摸牌
    DealCards:function(){
        var self = this;
        //确定猜牌人位置
        self.GuessTurn(); 
        var tcardLocation = self.myHolds.children.length - 1;
        if(userdata.mseat === userdata.ftplayer){//如果当前客户端玩家是摸牌方
            self.myHolds.children[8].active = true;
            var sprite = self.myHolds.children[8].getComponent(cc.Sprite);
            self.SetSpriteFrameByCardID("M_",userdata.mcard.get(userdata.mcard.size-1).suit,
                                        userdata.mcard.get(userdata.mcard.size-1).point,sprite);
            //如果摸到的牌是万能牌
            if(userdata.mcard.get(userdata.mcard.size-1).point==12){
                cc.log("摸到的牌是万能牌");
                self.random_suit = userdata.mcard.get(userdata.mcard.size-1).suit;
                self.RandomAppear();
            }
            self.SetCardsInfo(self.myCards,userdata.mcard.size-1,userdata.mcard.get(userdata.mcard.size-1));//存储摸的牌的信息
        }else if(userdata.rseat === userdata.ftplayer){//如果当前客户端玩家的右边是摸牌方
                self.rightHolds.children[8].active = true;
                var sprite = self.rightHolds.children[8].getComponent(cc.Sprite);
                self.SetSpriteFrameByCardID("R_",userdata.tcard.suit,13,sprite);
            self.SetCardsInfo(self.rightCards,userdata.rcard.size-1,userdata.rcard.get(userdata.rcard.size-1));//存储摸的牌的信息                
        }else if(userdata.oseat === userdata.ftplayer){//如果当前客户端玩家的对面是摸牌方
                self.oppositeHolds.children[8].active = true;
                var sprite = self.oppositeHolds.children[8].getComponent(cc.Sprite);
                self.SetSpriteFrameByCardID("O_",userdata.tcard.suit,13,sprite);
            self.SetCardsInfo(self.oppositeCards,userdata.ocard.size-1,userdata.ocard.get(userdata.ocard.size-1));//存储摸的牌的信息                
        }else if(userdata.lseat === userdata.ftplayer){//如果当前客户端玩家的左边是摸牌方
                self.leftHolds.children[8].active = true;
                var sprite = self.leftHolds.children[8].getComponent(cc.Sprite);
                self.SetSpriteFrameByCardID("L_",userdata.tcard.suit,13,sprite);
            self.SetCardsInfo(self.leftCards,userdata.lcard.size-1,userdata.lcard.get(userdata.lcard.size-1));//存储摸的牌的信息                
        }   
    },
   
    //4人游戏开始，猜牌
    GuessCards:function(node){
        var self = this; 
        node.on(cc.Node.EventType.TOUCH_START, function (event) {
            console.log("点击开始cc.Node.EventType.TOUCH_START");
            if (node.parent === self.myHolds) {//自己的牌不能点
                cc.log("自己的牌不能点");
                return;
            }

            if(userdata.ftplayer != userdata.mseat){
                cc.log('不是自己的回合，不能猜牌');
                return;
            }
            var mingtag = node.getChildByName("MingTag");
            if(mingtag.active === true){
                cc.log('已经明牌的牌，不能再猜');
                return;
            }
            node.interactable = node.getComponent(cc.Button).interactable;
            if (!node.interactable) {
                cc.log("3232323232");
                return;
            }
            self.guess.active = true;//让猜牌框出现
            self.guessbg.on('touchstart', self.EatTouch, self);//触摸吞噬

            self.guessPointDisplay.string = "7";//猜牌点数初始显示为7；
            self.guess_point = 7;

            self.GetGuessedman(node);//获取点击的牌的对手座位

            cc.log("点击的卡片的点数，颜色，位置："+self.GetCardsInfo(node).point+
            ","+self.GetCardsInfo(node).suit+","+self.GetCardsInfo(node).posi);

            self.guess_suit = self.GetCardsInfo(node).suit;
            self.guess_posi = self.GetCardsInfo(node).posi;

            if(userdata.ftplayer == userdata.mseat&&mingtag.active != true){
                self.GuessCardPop(node);
            }
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_Move, function (event) {
            console.log("cc.Node.EventType.TOUCH_MOVE");
            if (node.parent === self.myHolds) {
                return;
            }
            if (!node.interactable) {
                return;
            }
            var mingtag = node.getChildByName("MingTag");
            if(mingtag.active === true){
                return;
            }
            if (Math.abs(event.getDeltaX()) + Math.abs(event.getDeltaY()) < 0.5) {
                return;
            }
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_END, function (event) {
            var mingtag = node.getChildByName("MingTag");
            if (node.parent === self.myHolds) {
                return;
            }
            if (!node.interactable) {
                return;
            }
    
           if(userdata.ftplayer == userdata.mseat&&mingtag.active!= true){
              self.GuessCardPush(node);
            }

            console.log("\n点击结束cc.Node.EventType.TOUCH_END");
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_CANCEL, function (event) {
            if (node.parent === self.myHolds) {
                cc.log("不能点");
                return;
            }
            if (!node.interactable) {
                cc.log("不能点");
                return;
            }
            console.log("cc.Node.EventType.TOUCH_CANCEL");
        }.bind(this));            
    },

    //猜牌时，让点击的牌突出手牌
    GuessCardPop:function(node){
        var self  = this;
        var ox = node.getPositionX();
        var oy = node.getPositionY();
        if(node.parent===self.rightHolds){
            var move1=cc.moveTo(0.0001,cc.p(ox-40,oy));
            node.runAction(move1);
        }else if(node.parent===self.oppositeHolds){
            var move1=cc.moveTo(0.0001,cc.p(ox,oy-30));
            node.runAction(move1);
        }else if(node.parent===self.leftHolds){
            var move1=cc.moveTo(0.0001,cc.p(ox+40,oy));
            node.runAction(move1);
        }
    },

    //猜牌时，让点击的牌缩回手牌
    GuessCardPush:function(node){
        var self = this;
        var ox = node.getPositionX();
        var oy = node.getPositionY();
        if(node.parent===self.rightHolds){
            var move1=cc.moveTo(0.005,cc.p(ox+40,oy));
            node.runAction(move1);
        }else if(node.parent===self.oppositeHolds){
            var move1=cc.moveTo(0.005,cc.p(ox,oy+30));
            node.runAction(move1);
        }else if(node.parent===self.leftHolds){
            var move1=cc.moveTo(0.005,cc.p(ox-40,oy));
            node.runAction(move1);
        }          
    },
    //插牌动作模板
    Template_insert:function(map,seatHolds,cardlength){
        var self=this;
        var cardPositionX = 0;
        var cardPositionY = 0;
        seatHolds.children[cardlength-1].active = true;
        cardPositionX = seatHolds.children[map.get(cardlength-1).posi-1].getPositionX();
        cardPositionY = seatHolds.children[map.get(cardlength-1).posi-1].getPositionY();
        var m = cardlength;
        var n = map.get(cardlength-1).posi;
        // self.ExchangeCard1(seatHolds.children[cardlength-1], seatHolds.children[map.get(cardlength-1).posi-1]);
        for(var i = map.get(cardlength-1).posi; i < cardlength; i++){
                self.ExchangeCard1(seatHolds.children[i-1],seatHolds.children[i]);
        }
        setTimeout(function() {
            seatHolds.children[cardlength-1].setPosition(cardPositionX,cardPositionY);
            self.ExchangeIndex(seatHolds,cardlength,map.get(cardlength-1).posi);
            self.ExchangeCard2(seatHolds.children[seatHolds.children.length-1],seatHolds.children[map.get(cardlength-1).posi-1]);
            [seatHolds.children[seatHolds.children.length-1],seatHolds.children[map.get(cardlength-1).posi-1]]=
            [seatHolds.children[map.get(cardlength-1).posi-1],seatHolds.children[seatHolds.children.length-1]];       
            }, 300);
    },
    //4人游戏开始，在猜牌后，插牌
    InsertCards:function(){
        var self = this;
        if(userdata.ftplayer===userdata.mseat){//如果当前客户端玩家是摸牌方
            self.Template_insert(userdata.mcard,self.myHolds,userdata.mcard.size);
        }else if(userdata.ftplayer===userdata.rseat){//如果当前客户端右边玩家是摸牌方
            self.Template_insert(userdata.rcard,self.rightHolds,userdata.rcard.size);
        }else if(userdata.ftplayer===userdata.oseat){//如果当前客户端对面玩家是摸牌方
            self.Template_insert(userdata.ocard,self.oppositeHolds,userdata.ocard.size);
        }else if(userdata.ftplayer===userdata.lseat){//如果当前客户端左边玩家是摸牌方
            self.Template_insert(userdata.lcard,self.leftHolds,userdata.lcard.size);
        }                                 
    },
     //设置卡牌图片函数
    SetSpriteFrameByCardID :function(pre,color,cardId,sprite){
        var cardmgr = this.node.getComponent("CardMgr");
        sprite.spriteFrame = cardmgr.getSpriteFrameByCardID(pre,color,cardId);
    },
     
    //存储卡牌信息
    SetCardsInfo:function(myCards,//存储卡牌信息的数组
                          index,//卡牌对应node在手牌中的位置
                          oneCard,//从服务器接受到的卡牌信息
        ){  var self = this;
        myCards[index] = oneCard;
    },

    //提取卡牌信息
    GetCardsInfo:function(node){
        var self = this;        
        for(var i = 0; i < self.myHolds.children.length; i++){
            if(node == self.myHolds.children[i]){
                if(i == self.myHolds.children.length-1){//如果想获取摸得牌的信息
                    return self.myCards[userdata.mcard.size-1];//那么返回数组的最后一个
                }
               return self.myCards[i];
            }
         }
        for(var i = 0; i < self.rightHolds.children.length; i++){
            if(node == self.rightHolds.children[i]){
               if(i == self.rightHolds.children.length-1){//如果想获取摸得牌的信息
                    return self.rightCards[userdata.rcard.size-1];//那么返回数组的最后一个
                }
               return self.rightCards[i];
            }
         }
        for(var i = 0; i < self.oppositeHolds.children.length; i++){
            if(node == self.oppositeHolds.children[i]){
               if(i == self.oppositeHolds.children.length-1){//如果想获取摸得牌的信息
                    return self.oppositeCards[userdata.ocard.size-1];//那么返回数组的最后一个
                }                            
               return self.oppositeCards[i];
            }
         }
        for(var i = 0; i < self.leftHolds.children.length; i++){
            if(node == self.leftHolds.children[i]){
               if(i == self.leftHolds.children.length-1){//如果想获取摸得牌的信息
                    return self.leftCards[userdata.lcard.size-1];//那么返回数组的最后一个
                }                               
               return self.leftCards[i];
            }
         }                           
    },

    //点击猜牌浮框上的确定键，发送所猜的牌
    GuessConfirm:function(){
        var self=this;
        cc.log("Round:"+userdata.round);
        //所猜的卡牌信息
        var card = JSON.stringify({CardPoint:self.guess_point,
                                   CardSuit:self.guess_suit,
                                   Position:self.guess_posi,
        });
        card = JSON.parse(card);
        //加上猜的命令10022和所猜人位置seat       
        var content = JSON.stringify({Type:10022,
                                      Seat:userdata.guessedman,
                                      Card:card,                         
        });
        content = JSON.parse(content);
        //加上客户端session号id
        var guess_sdmes = JSON.stringify({Id:userdata.id,
                                      Content:content,
        });
        guess_sdmes = "msg="+guess_sdmes;
        cc.log("发送猜牌信息："+guess_sdmes);
        if(self.stepCount<=0){
            cc.log('已经超时了，不能再发送猜牌信息');
        }else{
            self.stepCount = 21;
            http.HttpPost(self.url,guess_sdmes,function(guess_rvmes){
                if (guess_rvmes === -1) {
                }else{
                    guess_rvmes=JSON.parse(guess_rvmes);
                    cc.log(guess_rvmes);
                    if(guess_rvmes.Type === 10035){//出现胜利者
                        cc.log("出现胜利者");
                        if(userdata.restcard!= false && userdata.cardsAreNull!=1){
                        cardactivity.Over(guess_rvmes);
                        self.MingBrang(userdata.ftplayer,userdata.tcard,self.myHolds.children.length);     
                        self.GameOver(guess_rvmes);
                        self.InsertCards();  
                        setTimeout(function(){
                        cardactivity.Insert_card();
                                }, 500);
                        }else{
                            cardactivity.Over(guess_rvmes);
                            self.GameOver(guess_rvmes);//牌堆里的牌发完了时出现胜利者
                        }
                    }else{
                        cardactivity.GuessResult(guess_rvmes);
                        if(guess_rvmes.Type===10023){//返回猜牌结果信息
                            userdata.round +=1;
                            self.roundCountLabel.string = userdata.round;
                            if(guess_rvmes.Tcard.CardPoint == 12){//如果摸得牌是万能牌，则改变其posi
                                self.ChangeRandomPosi(guess_rvmes);
                            }
                            switch(guess_rvmes.Result){
                                    case true://猜对
                                        cc.log("66666666猜对了");
                                        if(guess_rvmes.GuessCard.CardPoint==12){//上方飘过的提示消息
                                            self.newsDisplay.string = "玩家"+self.getNameBySeat(userdata.mseat)+
                                                                     "猜玩家"+self.getNameBySeat(userdata.guessedman)+"的第"+
                                                                     userdata.guessedcard.posi+"张牌为万能牌，猜对了";
                                        }else{
                                            self.newsDisplay.string = "玩家"+self.getNameBySeat(userdata.mseat)+
                                                                    "猜玩家"+self.getNameBySeat(userdata.guessedman)+"的第"+
                                                                     userdata.guessedcard.posi+"张牌为"+guess_rvmes.GuessCard.CardPoint+"点，猜对了";
                                        }
                                        self.newsHistory = self.newsHistory + "\n" + "第"+(userdata.round-1)+"回合："+self.newsDisplay.string;
                                        self.newsHistoryAdd+=1;
                                        self.newsDisplay.getComponent(cc.Animation).play('newsFlow');//提示信息飘过...
                                        self.MingBrang(userdata.guessedman,userdata.guessedcard,userdata.guessedcard.posi);
                                        self.ContinuePlay();
                                        break;
                                    case false://猜错
                                        if(guess_rvmes.TimeOut == false){//未超时猜错
                                        cc.log("23333333猜错了");
                                        if(guess_rvmes.GuessCard.CardPoint==12){//上方飘过的提示消息
                                            self.newsDisplay.string = "玩家"+self.getNameBySeat(userdata.mseat)+
                                                                     "猜玩家"+self.getNameBySeat(userdata.guessedman)+"的第"+
                                                                     userdata.guessedcard.posi+"张牌为万能牌，猜错了";
                                        }else{
                                            self.newsDisplay.string = "玩家"+self.getNameBySeat(userdata.mseat)+
                                                                    "猜玩家"+self.getNameBySeat(userdata.guessedman)+"的第"+
                                                                     userdata.guessedcard.posi+"张牌为"+guess_rvmes.GuessCard.CardPoint+"点，猜错了";
                                        }
                                        self.newsHistory = self.newsHistory + "\n" + "第"+(userdata.round-1)+"回合："+self.newsDisplay.string;
                                        self.newsHistoryAdd+=1;
                                        self.newsDisplay.getComponent(cc.Animation).play('newsFlow');//提示信息飘过...
                                        if(userdata.restcard){//如果牌堆有牌
                                        self.MingBrang(userdata.mseat,userdata.mcard.get(userdata.mcard.size-1),self.myHolds.children.length);
                                        }
                                        self.stepCount = 21;  
                                        self.RoundChange();
                                    }else if(guess_rvmes.TimeOut == true){//猜牌时恰好超时，就直接按超时处理
                                            if(userdata.ftplayer == userdata.mseat){
                                                cc.log("本方超时1");
                                                if(userdata.restcard == false){//如果牌堆无牌
                                                    cc.log("3333333333333牌堆无牌超时");
                                                }else{//如果牌堆有牌
                                                } 
                                                    self.ResultEpoll(true);
                                                } 
                                        }
                                }
                        }
                    }
                }
            })
        }
        self.guess.active = false;
    },

    //点击猜牌浮框上的叉键，取消猜牌，关闭猜牌浮框
    GuessCancel:function(){
        var self = this;
        self.guess.active = false;
    },
    //点击插随机牌框上的叉键，取消插牌，关闭插牌浮框
    InsertRandomCancel:function(){
        var self = this;
        self.insert_random.active = false;
    },

    //触摸吞噬
    EatTouch:function(event){
        cc.log('EatTouch');
	    event.stopPropagation();
    },

    //点击猜牌浮框上的加号键，增加猜牌点数
    AddGuessPoint:function(){
        var self = this;
        var a = 0;
        if(self.guessPointDisplay.string == "万能"){
            a = 12;      
        }else{
            a = parseInt(self.guessPointDisplay.string);
        }
        a++;
        if(a<=0){
           a= 0;
        }
        if(a>=12){
           a = 12; 
        }
        self.guess_point = a;
        if(a == 12)
        {
          self.guessPointDisplay.string = "万能";  
        }else{
          self.guessPointDisplay.string = a.toString();
        }
    },

    //点击插牌浮框上的加号键，增加插牌位置
    AddInsertNum:function(){
        var self = this;
        var a = 7;
        a = parseInt(self.insert_randomDisplay.string);
        a++;
        if(a<=1){
           a= 1;
        }
        if(a>=11){
           a = 11; 
        }
        self.random_point = a;
        self.insert_randomDisplay.string =a.toString();  
    },
    //点击猜牌浮框上的减号键，减少猜牌点数
    ReduceGuessPoint:function(){
        var self = this;
        var a = 0;
        if(self.guessPointDisplay.string == "万能"){
            a = 12;      
        }else{
            a = parseInt(self.guessPointDisplay.string);
        }
        a--;
        if(a<=0){
           a= 0;
        }
        if(a>=12){
           a = 12; 
        }
        self.guess_point = a;
        if(a == 12)
        {
          self.guessPointDisplay.string = "万能";  
        }else{
          self.guessPointDisplay.string = a.toString();
        }        
    },

    //点击插牌浮框上的减号键，减少插牌位置
    ReduceInsertNum:function(){
        var self = this;
        var a = 7;
        a = parseInt(self.insert_randomDisplay.string);
        a--;
        if(a<=1){
           a= 1;
        }
        if(a>=11){
           a = 11; 
        }
        self.random_point = a;
        self.insert_randomDisplay.string = a.toString();  
    },

    //明牌效果
    MingBrang:function(seat,carddata,pos){
        var self=this;
        if(seat===userdata.mseat){
            // var ss=cc.loader.removeItem(carddata.point);
            // self.myHolds.children[pos-1].runAction(ss);
            var tag=self.myHolds.children[pos-1].getChildByName("MingTag");
            tag.active=true;
        }else if(seat === userdata.rseat){
                var sprite = self.rightHolds.children[pos-1].getComponent(cc.Sprite);
                cc.log("R_"+carddata.suit+"_"+carddata.point);
                self.SetSpriteFrameByCardID("R_",carddata.suit,carddata.point,sprite);
                var tag=self.rightHolds.children[pos-1].getChildByName("MingTag");
                tag.active=true;
        }else if(seat ===userdata.oseat){
                var sprite = self.oppositeHolds.children[pos-1].getComponent(cc.Sprite);
                cc.log("O_"+carddata.suit+"_"+carddata.point);
                self.SetSpriteFrameByCardID("O_",carddata.suit,carddata.point,sprite);
                var tag=self.oppositeHolds.children[pos-1].getChildByName("MingTag");
                tag.active=true;
        }else if(seat === userdata.lseat){
                var sprite = self.leftHolds.children[pos-1].getComponent(cc.Sprite);
                cc.log("L_"+carddata.suit+"_"+carddata.point);
                self.SetSpriteFrameByCardID("L_",carddata.suit,carddata.point,sprite);
                var tag=self.leftHolds.children[pos-1].getChildByName("MingTag");
                tag.active=true;
        }

    },

    //获取被猜牌人的座位
    GetGuessedman:function(node){
        var self=this;
        if(node.parent === self.rightHolds){
            userdata.guessedman = userdata.rseat;
        }else if(node.parent ===self.oppositeHolds){
                userdata.guessedman = userdata.oseat;
        }else if(node.parent === self.leftHolds){
                userdata.guessedman = userdata.lseat;
        }        
    },
    
    //交换牌的位置和信息
    ExchangeCard1:function(node1,node2){
        var move2=cc.moveTo(0.2,cc.p(node2.getPositionX(),node2.getPositionY()));
        node1.runAction(move2);    
    },
    ExchangeCard2:function(node1,node2){
        var move1=cc.moveTo(0.2,cc.p(node2.getPositionX(),node2.getPositionY()));
        var move2=cc.moveTo(0.2,cc.p(node1.getPositionX(),node1.getPositionY()));
        node1.runAction(move1); 
        node2.runAction(move2);    
    },
    ExchangeIndex:function(holds,cardsLength,posi){
            for(var i = cardsLength;i > posi; i--){
                [holds.children[i-1],holds.children[i-2]]=[holds.children[i-2],holds.children[i-1]];

            }
    },

    UpdateCardsInfo:function(){
        var self = this;
        //如果当前客户端玩家是摸牌方
        if(userdata.mseat === userdata.ftplayer){
            for(var i=0;i<userdata.mcard.size;++i){
                self.myCards[i] = userdata.mcard.get(i);
                var sprite = self.myHolds.children[i].getComponent(cc.Sprite);
                self.GuessCards(sprite.node);//
            }
        }else if(userdata.rseat === userdata.ftplayer){  
            for(var i=0;i<userdata.rcard.size;++i){
                self.rightCards[i] = userdata.rcard.get(i);
                var sprite = self.rightHolds.children[i].getComponent(cc.Sprite);
                self.GuessCards(sprite.node);//
            }
        }else if(userdata.oseat === userdata.ftplayer){      
            for(var i=0;i<userdata.ocard.size;++i){
                self.oppositeCards[i] = userdata.ocard.get(i);
                var sprite = self.oppositeHolds.children[i].getComponent(cc.Sprite);
                self.GuessCards(sprite.node);//                
            }
        }else if(userdata.lseat === userdata.ftplayer){            
            for(var i=0;i<userdata.lcard.size;++i){
                self.leftCards[i] = userdata.lcard.get(i);
                var sprite = self.leftHolds.children[i].getComponent(cc.Sprite);
                self.GuessCards(sprite.node);// 
            }
        }                        
    },

    //猜牌成功后，延迟2秒弹出是否继续猜牌的弹框
    ContinuePlay:function(){
        var self = this;
                self.continue.active = true;//让否继续猜牌的弹出现
                self.continuebg.on('touchstart', self.EatTouch, self);//触摸吞噬  
        
    },
    ContinueConfirm:function(){
        var self = this;
        cc.log("继续猜牌");
        //是否继续猜牌      
        var content = JSON.stringify({Type:10026,
                                      ToContinue:true,                         
        });
        content = JSON.parse(content);
        //加上客户端session号id
        var continue_sdmes = JSON.stringify({Id:userdata.id,
                                      Content:content,
        });
        continue_sdmes = "msg="+continue_sdmes;
        cc.log("发送继续猜牌请求信息："+continue_sdmes);
        http.HttpPost(self.url,continue_sdmes,function(continue_rvmes){
            if (continue_rvmes === -1) {
                //console.log("请检查网络");
            }else{
                var rv=JSON.parse(continue_rvmes);
                if(rv.Type===10029){
                    cc.log(rv);
                    self.stepCount = 21;
                    self.continue.active = false;
                }
            }
        })
    },
    
    ContinueConcel:function(){
        var self = this;
        cc.log("不继续猜牌");
        //是否继续猜牌      
        var content = JSON.stringify({Type:10026,
                                      ToContinue:false,                         
        });
        content = JSON.parse(content);
        //加上客户端session号id
        var nocontinue_sdmes = JSON.stringify({Id:userdata.id,
                                      Content:content,
        });
         nocontinue_sdmes = "msg="+nocontinue_sdmes;
        cc.log("发送不继续猜牌请求信息："+nocontinue_sdmes);
        http.HttpPost(self.url,nocontinue_sdmes,function(nocontinue_rvmes){
            if (nocontinue_rvmes === -1) {
                //console.log("请检查网络");
            }else{
                self.continue.active = false;//让否继续猜牌的弹框消失
                var rv=JSON.parse(nocontinue_rvmes);
                cc.log(rv);
                if(rv.Type===10030){
                    cc.log("玩家放弃继续猜牌");
                        self.RoundChange();
                 }
              }
        })
    },

    //轮询猜牌时收到服务器发送的10035，则一个玩家胜利，其余玩家手牌被猜完，游戏结束
    GameOver:function(rvmes){
        var self  = this;
        self.gameover.active = true;      
        cc.log(userdata.guessedcard);
        self.MingBrang(userdata.guessedman,userdata.guessedcard,userdata.guessedcard.posi);//将最后一张猜的牌明牌

        for(var i = 0;i<rvmes.Hands.length;i++){
            if(userdata.winner_seat === userdata.mseat){
             self.MingBrang(userdata.winner_seat,userdata.mcard.get(i),userdata.mcard.get(i).posi);//将胜利者的牌明牌
            }else if(userdata.winner_seat === userdata.rseat){
            self.MingBrang(userdata.winner_seat,userdata.rcard.get(i),userdata.rcard.get(i).posi);//将胜利者的牌明牌
            }else if(userdata.winner_seat === userdata.oseat){
            self.MingBrang(userdata.winner_seat,userdata.ocard.get(i),userdata.ocard.get(i).posi);//将胜利者的牌明牌
            }else if(userdata.winner_seat === userdata.lseat){
            self.MingBrang(userdata.winner_seat,userdata.lcard.get(i),userdata.lcard.get(i).posi);//将胜利者的牌明牌
        }   
               
            }

        if(userdata.winner_seat === userdata.mseat){
            cc.log(userdata.mcard);
        }else if(userdata.winner_seat === userdata.rseat){
            cc.log(userdata.rcard);
        }else if(userdata.winner_seat === userdata.oseat){
            cc.log(userdata.ocard);
        }else if(userdata.winner_seat === userdata.lseat){
            cc.log(userdata.lcard);
        }       

        self.gameoverbg.on('touchstart', self.EatTouch, self);//触摸吞噬
        if(rvmes.SWinner == userdata.mseat){
            self.gameResultDisplay.string = "本方胜利！再接再厉！";
        }else{
            self.gameResultDisplay.string = "游戏失败！胜利者是："+rvmes.PWinner;
        }
        
    },


    //步时倒计时
    UpdateLeftTime:function () {
        var self = this;
         self.stepCountLabel.string = "20";
        self.schedule(function(){
                self.stepCount--;
                if(self.stepCount<=0){
                   //self.GuessTimeOut();
                   self.stepCountLabel.string = "0";
                   if(self.stepCount ==0){
                       self.GuessTimeOut();
                   }
                }else{
                    self.stepCountLabel.string = self.stepCount;
                }
            },1);
    },

    //猜牌超时
    GuessTimeOut:function(){
        var self = this;
        if(self.stepCount<=0){      
            if(userdata.ftplayer == userdata.mseat){
                cc.log("本方超时2");
                self.insert_random.active = false;
                if(userdata.restcard == false){//如果牌堆无牌
                    cc.log("3333333333333牌堆无牌超时");
                }
                self.ResultEpoll(true);
            }                               
        }
    },

    //确定当前猜牌方箭头指向谁
    GuessTurn:function(){
        var self = this;
        if(userdata.ftplayer == userdata.mseat){
            self.myTurn.active = true;
            self.rightTurn.active = false;
            self.oppositeTurn.active = false;
            self.leftTurn.active = false;
        }else if(userdata.ftplayer == userdata.rseat){
            self.myTurn.active = false;
            self.rightTurn.active = true;
            self.oppositeTurn.active = false;
            self.leftTurn.active = false;
        }else if(userdata.ftplayer == userdata.oseat){
            self.myTurn.active = false;
            self.rightTurn.active = false;
            self.oppositeTurn.active = true;
            self.leftTurn.active = false;
        }else if(userdata.ftplayer == userdata.lseat){
            self.myTurn.active = false;
            self.rightTurn.active = false;
            self.oppositeTurn.active = false;
            self.leftTurn.active = true;
        }
    },

    //万能牌出现
    RandomAppear:function(){
        var self = this;
        self.insert_random.active = true;
        if(self.insert_random.active==true){
            self.insert_randomDisplay.string = "7";
            self.random_point = 7;
            self.insert_randombg.on('touchstart', self.EatTouch, self);//触摸吞噬
            }
    },


    //确定假定的万能牌点数
    RandomConfirm:function(){
        var self = this;
        cc.log("确定万能牌假定点数");
        var content = JSON.stringify({Type:10041,
                                      SimPoint:self.random_point,
                                      Suit:self.random_suit                        
        });
        content = JSON.parse(content);
        //加上客户端session号id
        var random_sdmes = JSON.stringify({Id:userdata.id,
                                           Content:content,
        });
         random_sdmes = "msg="+random_sdmes;
        cc.log("发送万能牌假定点数信息："+random_sdmes);
        http.HttpPost(self.url,random_sdmes,function(random_rvmes){
            if (random_rvmes === -1) {
                //console.log("请检查网络");
            }else{
                var rv=JSON.parse(random_rvmes);
                cc.log("收到万能牌返回信息:"+random_rvmes); 
              }
        })
        self.insert_random.active = false;
        
    },

    //如果摸得牌是万能牌，要在map中改变其posi
    ChangeRandomPosi:function(rv){
        //如果摸牌人是本方
        if(rv.GuessSeat == userdata.mseat){
            var cardlength = userdata.mcard.size;
            cc.log("cardlength:"+cardlength);
            cc.log("改变posi前："+userdata.mcard.get(cardlength-1).posi);
            cc.log("改变posi后："+ rv.Tcard.Position);
            userdata.mcard.get(cardlength-1).posi = rv.Tcard.Position;
        }else if(rv.GuessSeat == userdata.rseat){
            var cardlength = userdata.rcard.size;
            cc.log("cardlength:"+cardlength);
            cc.log("改变posi前："+userdata.rcard.get(cardlength-1).posi);
            cc.log("改变posi后："+ rv.Tcard.Position);
            userdata.rcard.get(cardlength-1).posi = rv.Tcard.Position;
        }else if(rv.GuessSeat == userdata.oseat){
            var cardlength = userdata.ocard.size;
            cc.log("cardlength:"+cardlength);
            cc.log("改变posi前："+userdata.ocard.get(cardlength-1).posi);
            cc.log("改变posi后："+ rv.Tcard.Position);
            userdata.ocard.get(cardlength-1).posi = rv.Tcard.Position;
        }else if(rv.GuessSeat == userdata.lseat){
            var cardlength = userdata.lcard.size;
            cc.log("cardlength:"+cardlength);
            cc.log("改变posi前："+userdata.lcard.get(cardlength-1).posi);
            cc.log("改变posi后："+ rv.Tcard.Position);
            userdata.lcard.get(cardlength-1).posi = rv.Tcard.Position;
        }
    },

    //显示玩家信息
    ShowPlayerInfo:function(){
        var self = this;
        //显示右方玩家信息,按顺序是头像，等级，姓名，金币（现在只有姓名）
        var rightHeadImage = self.rightInfo.getChildByName("player_head");//头像
        var rightLevel = self.rightInfo.getChildByName("level");//等级
        var rightName = self.rightInfo.getChildByName("name");//姓名
        rightName = rightName.getComponent(cc.Label);
        var rightScore = self.rightInfo.getChildByName("score");//金币数


        //显示对面玩家信息,按顺序是头像，等级，姓名，金币（现在只有姓名）
        var oppositeHeadImage = self.oppositeInfo.getChildByName("player_head");//头像
        var oppositeLevel = self.oppositeInfo.getChildByName("level");//等级
        var oppositeName = self.oppositeInfo.getChildByName("name");//姓名
        oppositeName = oppositeName.getComponent(cc.Label);
        var oppositeScore = self.oppositeInfo.getChildByName("score");//金币数



        //显示左方玩家信息,按顺序是头像，等级，姓名，金币（现在只有姓名）
        var leftHeadImage = self.leftInfo.getChildByName("player_head");//头像
        var leftLevel = self.leftInfo.getChildByName("level");//等级
        var leftName = self.leftInfo.getChildByName("name");//姓名
        leftName = leftName.getComponent(cc.Label);
        var leftScore = self.leftInfo.getChildByName("score");//金币数

        for(var i =0; i < soket.seat.length; i++){
            if(soket.seat[i] == userdata.rseat){
                rightName.string = soket.name[i];
            }
            if(soket.seat[i] == userdata.oseat){
                oppositeName.string = soket.name[i];

            }
            if(soket.seat[i] == userdata.lseat){
                leftName.string = soket.name[i];

            }        
        }
    },

    //由玩家座位号得到相应用户名
    getNameBySeat:function(seat){
        var self = this;
        for(var i =0; i < soket.seat.length; i++){
            if(soket.seat[i] == seat){
                return soket.name[i];
            }      
        }
    },


    update:function (dt) {
        var self = this;
        soket.getChatMsg();//监听获取聊天信息
        self.chatLabel.string = soket.chatString;//更新聊天记录
        self.chatContent.height = 400 +soket.chatHeightAdd*60;//更新聊天框高度
        self.newsLabel.string = self.newsHistory;//更新游戏消息历史
        self.newsContent.height = 400 +self.newsHistoryAdd*60;//更新游戏消息历史框高度
        self.GuessTurn();//更新摸牌玩家方    
    }
});
