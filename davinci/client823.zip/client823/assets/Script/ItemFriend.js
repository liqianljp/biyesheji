var userdata = require('UserData');
cc.Class({
    extends: cc.Component,
    properties: {
        id: cc.Label,
        icon: cc.Sprite,
        friendName: cc.Label,
        friendGrade: cc.Label
    },


    init:function(data){
        this.id.string = data.id;
        this.icon.spriteFrame = data.iconSF;
        this.friendName.string = data.itemName;
        this.friendGrade.string = data.itemGrade;
    },

    //好友列表item的点击响应函数
    SelectFriend:function(node){
        var self = this;
        var id = node.getChildByName("id").getComponent(cc.Label).string;
        var name = node.getChildByName("name").getComponent(cc.Label).string; 
        node.on(cc.Node.EventType.TOUCH_START, function (event) {
            node.interactable = node.getComponent(cc.Button).interactable;
            if (!node.interactable) {
                return;
            }
            userdata.selectedFriendName = self.friendName.string;
            userdata.selectedFriendID = self.id.string;
            if(id == userdata.selectedFriendID){
            node.getChildByName("selecting").active = true;
             }
             if(name == userdata.selectedFriendName){
            node.getChildByName("selecting").active = true;
             }
             cc.log(userdata.selectedFriendName);
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_Move, function (event) {
            if (!node.interactable) {
                return;
            }
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_END, function (event) {
            if (!node.interactable) {
                return;
            }
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_CANCEL, function (event) {
            if (!node.interactable) {
                return;
            }
        }.bind(this));            
    },


    onLoad:function(){
        var self = this;
        self.SelectFriend(this.node);
    },
});
