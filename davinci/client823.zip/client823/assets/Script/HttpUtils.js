//httpUtils.js脚本用作模板module，提供向服务器发送消息，接收消息等功能
module.exports={
    isBackToHall:false,
    //向服务端发送post命令,要求改变信息
    HttpPost: function (url, params, callback) {
        if(this.isBackToHall==true){
            cc.log("返回大厅了"); 
            }else{  
             var xhr = cc.loader.getXMLHttpRequest();  
             xhr.open("POST", url, true);
             xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function (){  
                if (xhr.readyState === 4 && (xhr.status >= 200 && xhr.status < 300)) {  
                    var response = xhr.responseText; 
                    callback(response);  
                }else{  
                    callback(-1);  
                }  
            };        
            xhr.send(params);
        }  
    }, 

};