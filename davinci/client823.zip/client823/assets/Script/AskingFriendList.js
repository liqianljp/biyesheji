var userdata = require('UserData');
var friend = require('FriendActivity');
var http = require('HttpUtils');
var soket = require("SoketUtils");
var Item4 = cc.Class({
    name:"Item4",
    properties:{
        id:0,
        friendName:"",
        friendGrade:0,
        friendIcon:cc.SpriteFrame,
    },
});

cc.Class({
    extends: cc.Component,
    properties: {
        items:{
            default:[],
            type:Item4,
        },  
        itemFriendPrefab:cc.Prefab,
        headAtlas:{
            default:null,
            type:cc.SpriteAtlas
        },
        askingListContent:{//请求列表内容
            default:null,
            type:cc.Node,
        },
        askingList:{//请求列表
            default:null,
            type:cc.Node,
        },
        friendList:{//好友列表
            default:null,
            type:cc.Node,
        },
        friendListContent:{//好友列表内容
            default:null,
            type:cc.Node,
        },      
    },

    // use this for initialization
    onLoad: function (){
        var self = this;
        userdata.selectedFriendName = null;
        self.InitAskingList();
},

    //初始化请求好友列表
    InitAskingList:function(){
        var self = this;
        userdata.selectedMailID = null;
       if(userdata.askingFriendInfo==null||userdata.askingFriendInfo.length==0){

       }else{
            self.ClearAskingFriends();         
            self.items.length = userdata.askingFriendInfo.length;
            for (var i = 0; i < self.items.length; ++i) {
                var item = cc.instantiate(self.itemFriendPrefab);
                self.items[i] = userdata.askingFriendInfo[0];
                var data = self.items[i];
                self.node.addChild(item);
                item.color = new cc.Color(0,191,255);
                item.getComponent('ItemFriend').init({
                        id: data.ID,
                        itemName: data.FriendName,
                        itemGrade: "分数:"+data.FriendGrade,
                        iconSF: self.headAtlas.getSpriteFrame(data.FriendIcon),
                    });
            }
        }
    },


    //拒绝添加好友函数
    Reject:function(){
        var self = this;
        if(userdata.selectedFriendName == null){
            cc.log("请先选择想拒绝的人.");
        }else{
                //此处给服务器发送请求
                var  content = JSON.stringify({Type:10069,
                                              Answer:false,
                                              Name:userdata.selectedFriendName,
                                            });         
                cc.log("向好友服务器发送请求拒绝增加好友消息：");
                cc.log(JSON.parse(content));
                soket.ws.send(content);//发送消息 
                soket.getChatMsg();//监听获取信息
                self.UpdateAskingList(false);
                
            }
    },


    //同意添加好友函数
    Agree:function(){
        var self = this;
        if(userdata.selectedFriendName == null){
            cc.log("请先选择想同意的人.");
        }else{
                //此处给服务器发送请求
                var  content = JSON.stringify({Type:10069,
                                              Answer:true,
                                              Name:userdata.selectedFriendName,
                                            });         
                cc.log("向好友服务器发送请求同意增加好友消息：");
                cc.log(JSON.parse(content));
                soket.ws.send(content);//发送消息 
                soket.getChatMsg();//监听获取信息
                self.UpdateAskingList(true);
            }
    },

    //被请求方更新好友请求列表
    UpdateAskingList:function(choice){
        var self = this;
        //同意添加好友
        if(choice == true){
            self.friendList.active = true;
            self.ClearAskingFriends();
            friend.Clear_list(userdata.askingFriendInfo);
            self.friendListContent.getComponent("FriendsList").AskFriend();
        }
        //拒绝添加好友
        if(choice == false){
            self.friendList.active = true;
            self.ClearAskingFriends();
            friend.Clear_list(userdata.askingFriendInfo);
            self.friendListContent.getComponent("FriendsList").AskFriend();  
        }   
    },

    //关闭好友请求列表
    CloseList:function(){
        var self = this;
        self.askingList.active = false;
    },

    //确定要移除的item
    GetRemovedItem:function(mailID){
        var self = this;
    },

    //清空好友请求列表
    ClearAskingFriends:function(){
        var self = this;
        for(var i =self.askingListContent.children.length-1; i >=0;i--){
            self.askingListContent.removeChild(self.askingListContent.children[i]);
        }
    },
    
    //标记当前点击的好友
    SignSelectedFriend:function(){
        var self = this;
        for(var i = 0;i<self.askingListContent.children.length;++i){
            var name = self.askingListContent.children[i].getChildByName("name").getComponent(cc.Label).string;
            if( name == userdata.selectedFriendName){
                self.askingListContent.children[i].getChildByName("selecting").active = true;
            }else{
                self.askingListContent.children[i].getChildByName("selecting").active = false;
            }
        } 
    },
    // called every frame, uncomment this function to activate update callback
    update: function (dt) {
        var self = this;
        soket.getChatMsg();

        self.InitAskingList();
        self.SignSelectedFriend();
    },
});
