//储存卡牌信息
var userdata = require('UserData');
module.exports={
    //初始化函数模板，根据信息初始化卡牌信息，并储存在对应map里面，通用这一个函数初始化
    Init_card:function(cards,map){
        for(var x in cards){
            var card=new Map();
            card.point=cards[x].CardPoint;
            card.suit=cards[x].CardSuit;
            card.posi=cards[x].Position;
            card.state=cards[x].CardStatus;
            map.set(parseInt(x),card);
        }
    },

    Modify_card:function(cards,maps){
        for(var x =0;x<cards.length;x++){
            maps.get(x).point=cards[x].CardPoint;
            maps.get(x).suit=cards[x].CardSuit;
            maps.get(x).posi=cards[x].Position;
            maps.get(x).state=cards[x].CardStatus;
        }
    },

    //查找座位对应的OppPlayer下标
    GetSeat:function(seats,e){
        for(var x in e){
            if(e[x].Seat===seats){
                return x;
            }
        }
    },

    //两玩家对战时初始函数
    Init_two_players:function(mcards,ocards){
        userdata.mcard=new Map();
        userdata.ocard=new Map();
        this.Init_card(mcards,userdata.mcard);
        this.Init_card(ocards,userdata.ocard);

    },
    //三玩家对战时初始函数
    Init_three_players:function(mcards,lcards,rcards){
        userdata.mcard=new Map();
        userdata.lcard=new Map();
        userdata.rcard=new Map();
        this.Init_card(mcards,userdata.mcard);
        this.Init_card(lcards,userdata.lcard);
        this.Init_card(rcards,userdata.rcard);

    },

    //初始化四人对局时对手信息以及卡牌信息
    Init_four_opp:function(e){
        var r=this.GetSeat(userdata.rseat,e);
            this.Init_card(e[r].Card,userdata.rcard);
            userdata.rname=e[r].Uid;
            userdata.rgrade=e[r].Grade;
        var l=this.GetSeat(userdata.lseat,e);
            this.Init_card(e[l].Card,userdata.lcard);
            userdata.lname=e[l].Uid;
            userdata.lgrade=e[l].Grade;
        var o=this.GetSeat(userdata.oseat,e);
            this.Init_card(e[o].Card,userdata.ocard);
            userdata.oname=e[o].Uid;
            userdata.ograde=e[o].Grade;
    },
    //四玩家对战时初始函数
    Init_four_players:function(e){
        userdata.mcard=new Map();
        userdata.ocard=new Map();
        userdata.lcard=new Map();
        userdata.rcard=new Map();
        userdata.tcard=new Map();
        userdata.mseat=parseInt(e.Mseat);
        this.Init_card(e.Mcard,userdata.mcard);

        //根据我的座位固定对手座位
        if(userdata.mseat===1){
            userdata.rseat=2;
            userdata.oseat=3;
            userdata.lseat=4;
            this.Init_four_opp(e.OppPlayer);
        }else if(userdata.mseat===2){
            userdata.rseat=3;
            userdata.oseat=4;
            userdata.lseat=1;
            this.Init_four_opp(e.OppPlayer);
        }else if(userdata.mseat===3){
            userdata.rseat=4;
            userdata.oseat=1;
            userdata.lseat=2;
            this.Init_four_opp(e.OppPlayer);
        }else if(userdata.mseat===4){
            userdata.rseat=1;
            userdata.oseat=2;
            userdata.lseat=3;
            this.Init_four_opp(e.OppPlayer);
        }
        userdata.ftplayer=e.Touchp;
        this.Tcard(e.Tcard);
    },


    //根据摸牌人存储单摸的一张卡牌,tcard.suit记录单摸牌颜色
    Tcard:function(tcard){
        if(userdata.ftplayer===userdata.mseat){
            this.Insert_tcard(tcard,userdata.mcard);
        }else {
            userdata.tcard.suit=tcard.CardSuit;
            if(userdata.ftplayer===userdata.oseat){
                this.Insert_tcard(tcard,userdata.ocard);
            }else if(userdata.ftplayer===userdata.rseat){
                this.Insert_tcard(tcard,userdata.rcard);
            }else if(userdata.ftplayer===userdata.lseat){
                this.Insert_tcard(tcard,userdata.lcard);
            }
        }
    },

    //单摸牌插入到摸牌方的map
    Insert_tcard:function(tcard,map){
        if(tcard!=null){//如果牌堆有牌
        var map_length=map.size;
        var card=new Map();
        card.point=tcard.CardPoint;
        card.suit=tcard.CardSuit;
        card.posi=tcard.Position;
        card.state=tcard.CardStatus;
        map.set(parseInt(map_length),card);
        }
    },

    //接收猜牌结果信息
    GuessResult:function(e){
        userdata.guessedman=e.Seat;
        userdata.guessedcard.point=e.Card.CardPoint;
        userdata.guessedcard.suit=e.Card.CardSuit;
        userdata.guessedcard.posi=e.Card.Position;
        userdata.guessedcard.state=e.Card.CardStatus;
        if(e.Result===true){
            if(userdata.guessedman===userdata.mseat){
                userdata.mcard.get(e.Card.Position-1).state=e.Card.CardStatus;
            }
            else if(userdata.guessedman===userdata.oseat){
                userdata.ocard.get(e.Card.Position-1).point=e.Card.CardPoint;
                userdata.ocard.get(e.Card.Position-1).state=e.Card.CardStatus;
            }
            else if(userdata.guessedman===userdata.rseat){
                userdata.rcard.get(e.Card.Position-1).point=e.Card.CardPoint;
                userdata.rcard.get(e.Card.Position-1).state=e.Card.CardStatus;
            }
            else if(userdata.guessedman===userdata.lseat){
                userdata.lcard.get(e.Card.Position-1).point=e.Card.CardPoint;
                userdata.lcard.get(e.Card.Position-1).state=e.Card.CardStatus;
            }
        }else{
            userdata.tcard.point=e.Tcard.CardPoint;
            if(userdata.ftplayer===userdata.mseat){
                var card_length=userdata.mcard.size;
                userdata.mcard.get(card_length-1).state=e.Tcard.CardStatus;
            }else if(userdata.ftplayer===userdata.oseat){
                var card_length=userdata.ocard.size;
                userdata.ocard.get(card_length-1).point=e.Tcard.CardPoint;
                userdata.ocard.get(card_length-1).state=e.Tcard.CardStatus;
            }
            else if(userdata.ftplayer===userdata.rseat){
                var card_length=userdata.rcard.size;
                userdata.rcard.get(card_length-1).point=e.Tcard.CardPoint;
                userdata.rcard.get(card_length-1).state=e.Tcard.CardStatus;
            }
            else if(userdata.ftplayer===userdata.lseat){
                var card_length=userdata.lcard.size;
                userdata.lcard.get(card_length-1).point=e.Tcard.CardPoint;
                userdata.lcard.get(card_length-1).state=e.Tcard.CardStatus;
            }
        }
    },

    //正确位置插入的通用模板
    Insert_template:function(cards){
        var card_length=cards.size;
        var posbuff=cards.get(card_length-1).posi;
        cards.get(card_length-1).posi=card_length;
        for(var i=card_length;i>posbuff;i--){
            [cards.get(i-1).point,cards.get(i-2).point]=[cards.get(i-2).point,cards.get(i-1).point];
            [cards.get(i-1).suit,cards.get(i-2).suit]=[cards.get(i-2).suit,cards.get(i-1).suit];
            [cards.get(i-1).state,cards.get(i-2).state]=[cards.get(i-2).state,cards.get(i-1).state];
        }
    },

    //更新储存卡牌的map的信息
    Insert_card:function(){
        userdata.insert_count+=1;
        if(userdata.ftplayer===userdata.mseat){
            if(userdata.insert_count===1){
                var card_length=userdata.mcard.size;
                for(var i=card_length-2;i>=0;i--){
                    if((userdata.mcard.get(i).point>userdata.mcard.get(i+1).point)||
                            ((userdata.mcard.get(i).point===userdata.mcard.get(i+1).point)&&userdata.mcard.get(i).suit==="black")){
                        [userdata.mcard.get(i).point,userdata.mcard.get(i+1).point]=[userdata.mcard.get(i+1).point,userdata.mcard.get(i).point];
                        [userdata.mcard.get(i).suit,userdata.mcard.get(i+1).suit]=[userdata.mcard.get(i+1).suit,userdata.mcard.get(i).suit];
                        [userdata.mcard.get(i).state,userdata.mcard.get(i+1).state]=[userdata.mcard.get(i+1).state,userdata.mcard.get(i).state];
                        [userdata.mcard.get(i).posi,userdata.mcard.get(i+1).posi]=[userdata.mcard.get(i+1).posi,userdata.mcard.get(i).posi];
                    }else
                        break;
                }
            }else{
                this.Insert_template(userdata.mcard);
            }
        }else if(userdata.ftplayer===userdata.oseat){
            this.Insert_template(userdata.ocard);
        }else if(userdata.ftplayer===userdata.lseat){
            this.Insert_template(userdata.lcard);
        }else if(userdata.ftplayer===userdata.rseat){
            this.Insert_template(userdata.rcard);
        }
    },

    //结束数据接收
    Over:function(e){
        userdata.winner_seat=e.SWinner;
        userdata.guessedman=e.Seat;
        userdata.guessedcard = e.Card;
        userdata.guessedcard.point=e.Card.CardPoint;
        userdata.guessedcard.suit=e.Card.CardSuit;
        userdata.guessedcard.posi=e.Card.Position;
        userdata.guessedcard.state=e.Card.CardStatus;
        if(userdata.winner_seat===userdata.oseat){
            this.Modify_card(e.Hands,userdata.ocard);
        }else if(userdata.winner_seat===userdata.rseat){
            this.Modify_card(e.Hands,userdata.rcard);
        }else if(userdata.winner_seat===userdata.lseat){
            this.Modify_card(e.Hands,userdata.lcard);
        }
    },
};
