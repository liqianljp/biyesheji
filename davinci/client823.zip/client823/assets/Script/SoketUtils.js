var friend = require('FriendActivity');
var userdata = require('UserData');
//soket工具模板
module.exports = {
    ws:null,
    mes:null,
    //游戏内聊天
    chatString:"玩家发言如下：",//游戏内聊天信息
    chatHeightAdd:0,//游戏内聊天信息框高度增加
    seat:Array(),//收到的用户的座位号
    name:Array(),//收到的用户的姓名

    //好友系统（增删好友）
    isAddFriend:false,//是否增加好友
    isSendAddFriend:false,//是否已发送增加好友
    isRejectAddFriend:false,//是否拒绝增加好友
    isDeleteFriend:false,//是否删除好友
    hasBeenDeleted:false,//是否已被删除好友

    //好友系统（好友间聊天）
    chatFriend:Array(),//和好友聊天信息
    isInitChat:false,//是否初始化和好友的聊天信息
    
    connect: function(){
        var self=this;
        self.ws =new WebSocket("ws://192.168.0.229:1080/ws",[]);
    },
    close_ws: function(){
        var self=this;
        self.ws.close();
    },
    //收到聊天服务器的返回值
     getChatMsg:function (){
        var self = this;
        self.ws.onmessage = function(e){
            self.mes = e.data;
            cc.log("连接服务器成功......");
            cc.log("收到服务器消息");
            self.mes = JSON.parse(self.mes);
            cc.log(self.mes);
            switch (self.mes.Type) {
                case 10042:
                    cc.log("本用户进入聊天室成功ID为："+self.mes.Name);
                    self.seat.push(self.mes.Mseat);
                    self.name.push(self.mes.Name);
                    break;
                case 10046:
                    self.chatHeightAdd+=1;//content增加一次高度
                    self.chatString = self.chatString+"\n"+self.mes.Name+" 发言："+self.mes.Text;
                    cc.log(self.chatString);
                    break;
                case 10050:
                    cc.log("本用户进入聊天室失败");
                    break;
                case 10055:
                    cc.log("本用户收到好友信息");
                    friend.friendNum = self.mes.Fnum;
                    if(userdata.friendInfo != null&&userdata.friendInfo.length!=0){
                        friend.Clear_list(userdata.friendInfo);
                    }
                    friend.Init_friend(self.mes.Friends);
                    self.isInitChat = true;
                    break;
                case 10058:
                    cc.log("本用户收到搜索好友信息");
                    friend.searchFriendNum = self.mes.Fnum;
                    if(userdata.searchFriendInfo != null&&userdata.searchFriendInfo.length!=0){
                        friend.Clear_list(userdata.searchFriendInfo);
                    }
                    friend.Init_search_friend(self.mes.Friends);
                    break;
                case 10071:
                    self.isDeleteFriend = true;
                    cc.log("删除好友成功");
                    friend.Delete_friend(userdata.selectedFriendID);
                     break;
                case 10072:
                    cc.log("你被删除好友了");
                    self.hasBeenDeleted = true;
                     break;
                case 10063:
                    self.isAddFriend = true;
                    cc.log("增加好友成功");    
                    friend.Add_friend(userdata.selectedFriendID);
                     break;
                case 10064:  
                    cc.log("该玩家离线或不存在");
                     break;
                case 10065:    
                    cc.log("该玩家拒绝好友请求");
                    self.isRejectAddFriend = true;       
                     break;
                case 10066:  
                    cc.log("好友请求已发送");
                    self.isSendAddFriend = true;   
                     break;  
                case 10068:  
                    cc.log("出现好友请求");    
                    friend.Init_asking_friend(self.mes);
                     break;
                case 10076:  
                    cc.log("聊天信息已发送");    
                     break;
                case 10078:  
                    cc.log("聊天信息已转发成功");    
                    self.chatFriend[self.mes.P_id].chatFriendHeightAdd+=1;//content增加一次高度
                    self.chatFriend[self.mes.P_id].chatFriendString = 
                    self.chatFriend[self.mes.P_id].chatFriendString+"\n"+friend.GetFriendName(self.mes.P_id)+"："+self.mes.Text;
                     break;                                                     
                default:
                    break;
            }
        } 
     }  
}
