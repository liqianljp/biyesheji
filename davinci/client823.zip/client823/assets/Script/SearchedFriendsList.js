var userdata = require('UserData');
var friend = require('FriendActivity');
var http = require('HttpUtils');
var soket = require("SoketUtils");
var Item2 = cc.Class({
    name:"Item2",
    properties:{
        id:0,
        friendName:"",
        friendGrade:0,
        friendIcon:cc.SpriteFrame,
    },
});

cc.Class({
    extends: cc.Component,

    properties: {
        items:{
            default:[],
            type:Item2,
        },  
        itemFriendPrefab: cc.Prefab,
        headAtlas:{
            default:null,
            type:cc.SpriteAtlas
        },
        friendListContent:{//好友列表内容
            default:null,
            type:cc.Node,
        }, 
        searchedFriendName:{//输入的搜索的好友姓名
            default:null,
            type:cc.EditBox,
        },
        searchedFriendListContent:{//搜索的好友列表内容
            default:null,
            type:cc.Node,
        },
        friendList:{//现有的的玩家列表
            default:null,
            type:cc.Node,
        },
        searchedfriendList:{//搜索的玩家列表
            default:null,
            type:cc.Node,
        },
        friendChatName1:{//聊天，显示正选择的好友
            default:null,
            type:cc.Label, 
        },
        friendChatName2:{//邮件，显示正选择的好友
            default:null,
            type:cc.Label, 
        },
        searchCount:0,
    },

    // use this for initialization
    onLoad: function () {
        var self = this;
    },

    //搜索根据昵称搜索玩家按钮响应函数
    SearchFriend:function(){
        var self = this;
            self.searchCount+=1;
            userdata.selectedFriendID = null;
            self.friendList.active = false;
            self.searchedfriendList.active = true;
        //此处给服务器发送请求
        var  content = JSON.stringify({Type:10057,
                                       Words:self.searchedFriendName.string,
                                         });         

        if(self.searchedFriendName.string !=""){//发送搜索姓名不为空时
        cc.log("向好友服务器发送请求搜索好友消息：");
        cc.log(JSON.parse(content));
        cc.log(2);
        soket.ws.send(content);//发送消息 
        soket.getChatMsg();//监听获取信息 
        }else{
          self.friendList.active = true;
          self.searchedfriendList.active = false;  
        }
        self.searchedFriendName.Placeholder = "在此输入搜索姓名.......";
    },

    //初始化搜索玩家列表
    InitSearchedFriend:function(){
        var self = this;
        if(userdata.searchFriendInfo==null){

        }else{
            //  cc.log(self.searchCount);
            //  if(self.searchCount>1){
            //     self.ClearSearched();
            // }
            for(var i =self.searchedFriendListContent.children.length-1; i >=0;i--){
                self.searchedFriendListContent.removeChild(self.searchedFriendListContent.children[i]);
            }
            self.items.length = userdata.searchFriendInfo.length;
            for (var i = 0; i < self.items.length; ++i) {
                var item = cc.instantiate(self.itemFriendPrefab);
                item.color = new cc.Color(0,191,255);
                self.items[i] = userdata.searchFriendInfo[i];
                var data = self.items[i];
                self.node.addChild(item);
                item.getComponent('ItemFriend').init({
                    id: data.ID,
                    itemName: data.FriendName,
                    itemGrade: "分数:"+data.FriendGrade,
                    iconSF: self.headAtlas.getSpriteFrame(data.FriendIcon),
                });
            }
            self.searchedFriendListContent.height = 200 +　userdata.searchFriendInfo.length*60;                          
        }
    },


    //增加好友按钮响应函数
    AddFriend:function(){
        var self = this;
        //此处给服务器发送请求

        if(self.friendList.active == false&&self.searchedfriendList.active == true){
            if(userdata.selectedFriendID == null){
                cc.log("请先选择想添加的好友.");
            }else if(self.Contains(userdata.friendInfo,userdata.selectedFriendID)){
                     cc.log("现有好友中已存在想增加的好友");
                     self.friendList.active = true;
                     self.searchedfriendList.active = false; 
            }else{
                var  content = JSON.stringify({Type:10061,
                                               Name:self.GetAddItem(userdata.selectedFriendID).FriendName,
                                         });         
                cc.log("向好友服务器发送请求增加好友消息：");
                cc.log(JSON.parse(content));
                soket.ws.send(content);//发送消息 
                soket.getChatMsg();//监听获取信息
            }
        }else{
         cc.log("请先搜索想添加的好友.");
        }
    },

    //响应增加好友函数
    AnswerAddFriend:function(){
        var self = this;
        if(soket.isSendAddFriend == true){
            soket.isSendAddFriend = false;
            // self.friendList.active = true;
            // self.searchedfriendList.active = false;
        } 
        
        if(soket.isAddFriend == true){
            cc.log("已经增加好友成功");
            self.UpdateFriendList();
            soket.isAddFriend = false;
            self.friendList.active = true;
            self.searchedfriendList.active = false;
            userdata.selectedFriendName  = null;
            userdata.selectedFriendID = null;
        }

        if(soket.isRejectAddFriend == true){
            cc.log("该玩家已经拒绝添加好友");
            soket.isRejectAddFriend = false;
            self.friendList.active = true;
            self.searchedfriendList.active = false;
            userdata.selectedFriendName  = null;
            userdata.selectedFriendID = null;
        }
    },

    //请求方更新好友列表
    UpdateFriendList:function(){
        var self = this;   
        self.friendList.active = true;
        var item = cc.instantiate(self.itemFriendPrefab);
        var data = self.GetAddItem(userdata.selectedFriendID);
         item.getComponent('ItemFriend').init({
                id: data.ID,
                itemName: data.FriendName,
                itemGrade: "分数:"+data.FriendGrade,
                iconSF: self.headAtlas.getSpriteFrame(data.FriendIcon),
            });
        self.friendListContent.addChild(item);
        self.ClearSearched();
    },

    //清空搜索列表
    ClearSearched:function(){
        var self = this;
        for(var i =self.searchedFriendListContent.children.length-1; i >=0;i--){
            self.searchedFriendListContent.removeChild(self.searchedFriendListContent.children[i]);
        }
        friend.Clear_list(userdata.searchFriendInfo);
    },
    //确定要增加的item
    GetAddItem:function(friendID){
        var self = this;
        for(var i = 0; i<userdata.searchFriendInfo.length;++i){
            var id = userdata.searchFriendInfo[i].ID;
            if( id == friendID){
                return userdata.searchFriendInfo[i];
            }
        }
    },

    //标记当前点击的好友
    SignSelectedFriend:function(){
        var self = this;
        for(var i = 0;i<self.searchedFriendListContent.children.length;++i){
            var id = self.searchedFriendListContent.children[i].getChildByName("id").getComponent(cc.Label).string;
            if( id == userdata.selectedFriendID){
                self.searchedFriendListContent.children[i].getChildByName("selecting").active = true;
            }else{
                self.searchedFriendListContent.children[i].getChildByName("selecting").active = false;
            }
        } 
    },

    //判断现有好友中是否已存在想增加的好友
    Contains:function(array,friendID){
        var self = this;
        for(var i = 0; i < array.length;++i){
            var id = array[i].ID;
            if( id == friendID){
                return true;//存在
            }
        }
        return false;  
    },
    // called every frame, uncomment this function to activate update callback
    update: function (dt) {
        var self = this;
         soket.getChatMsg();//监听获取信息 
        self.friendChatName1.string = "聊天好友："+　userdata.selectedFriendName + "  "+userdata.selectedFriendID;
        self.friendChatName2.string = "收件人："+　userdata.selectedFriendName + "  "+userdata.selectedFriendID;
        self.InitSearchedFriend();
        self.AnswerAddFriend();
        self.SignSelectedFriend();
    },
});
