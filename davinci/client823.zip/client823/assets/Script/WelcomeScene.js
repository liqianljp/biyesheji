var http = require('HttpUtils');
var userdata = require("UserData");
cc.Class({
    extends: cc.Component,

    properties: {
        label1: {
            default: null,
            type: cc.Node
        },
        label2: {
            default: null,
            type: cc.Node
        },
         startGame: {
            default: null,
            type: cc.Node
        },
        
     
    },
    
    
    // use this for initialization
    onLoad: function (){
        this.label1.getComponent(cc.Animation).play('label1_moveright');
        this.label2.getComponent(cc.Animation).play('label2_moveright');
        this.startGame.getComponent(cc.Animation).play('startGame_moveright');
    
    },
    //点击开始游戏，跳转到登陆界面 
    ToLogin: function() {
        var bg=cc.find("Canvas/bg1");
        var seq2=cc.sequence(cc.fadeOut(1),cc.delayTime(1.01),cc.callFunc(
                 function(){
                 cc.director.loadScene("LoginScene");
                 }));
            bg.runAction(seq2);
        
    },
});
