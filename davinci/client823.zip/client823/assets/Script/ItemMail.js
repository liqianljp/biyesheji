var userdata = require('UserData');
cc.Class({
    extends: cc.Component,
    properties: {
        id: cc.Label,
        icon: cc.Sprite,
        title: cc.Label,
    },


    init:function(data){
        this.id.string = data.id;
        this.icon.spriteFrame = data.iconSF;
        this.title.string = data.title;
    },

    //好友列表item的点击响应函数
    SelectFriend:function(node){
        var self = this;
        var id = node.getChildByName("id").getComponent(cc.Label).string; 
        node.on(cc.Node.EventType.TOUCH_START, function (event) {
            node.interactable = node.getComponent(cc.Button).interactable;
            if (!node.interactable) {
                return;
            }
            cc.log("点击查看邮件");
            userdata.selectedMailID = self.id.string;
            if(id == userdata.selectedMailID){
                node.getChildByName("selecting").active = true;   
            }
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_Move, function (event) {
            if (!node.interactable) {
                return;
            }
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_END, function (event) {
            if (!node.interactable) {
                return;
            }
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_CANCEL, function (event) {
            if (!node.interactable) {
                return;
            }
        }.bind(this));            
    },


    onLoad:function(){
        var self = this;
        self.SelectFriend(this.node);
    },
});
