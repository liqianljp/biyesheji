var userdata = require('UserData');
var friend = require('FriendActivity');
var http = require('HttpUtils');
var soket = require("SoketUtils");
var Item3 = cc.Class({
    name:"Item3",
    properties:{
        id:0,
        friendName:"",
        friendIcon:cc.SpriteFrame,
    },
});

cc.Class({
    extends: cc.Component,
    properties: {
        items:{
            default:[],
            type:Item3,
        },  
        itemMailPrefab: cc.Prefab,
        headAtlas:{
            default:null,
            type:cc.SpriteAtlas
        },
        mailListContent:{//邮件列表内容
            default:null,
            type:cc.Node,
        },
        mailBox:{//邮箱
            default:null,
            type:cc.Node,
        },
        mailDetail:{//邮件具体信息浮框
            default:null,
            type:cc.Node,
        },
        mailAddresser:{//邮件发件人
            default:null,
            type:cc.Label,
        },
        mailDetailContent:{//邮件具体信息内容
            default:null,
            type:cc.Node,
        },
        mailDetailLabel:{//邮件具体信息文本
            default:null,
            type:cc.Label,
        },
    },

    // use this for initialization
    onLoad: function (){
        var self = this;
        userdata.selectedMailID = null;
        var e4 = JSON.stringify({Type:300000,
                                       "MailList":[{"ID":1,"FriendIcon":"head1","FriendName":"aa撒旦","Content":"唐太宗李世民（公元598年1月28日【一说599年1月23日】－公元649年7月10日），生于武功之别馆（今陕西武功），是唐高祖李渊和窦皇后的次子，唐朝第二位皇帝，杰出的政治家、战略家、军事家、诗人。李世民少年从军，曾去雁门关营救隋炀帝。唐朝建立后，李世民官居尚书令、右武候大将军，受封为秦国公，后晋封为秦王，先后率部平定了薛仁杲、刘武周、窦建德、王世充等军阀，在唐朝的建立与统一过程中立下赫赫战功。公元626年7月2日（武德九年六月初四），李世民发动“玄武门之变”，杀死自己的兄长太子李建成、四弟齐王李元吉及二人诸子，被立为太子，唐高祖李渊不久退位，李世民即位，改元贞观。[1] 李世民为帝之后，积极听取群臣的意见，对内以文治天下，虚心纳谏，厉行节约，劝课农桑，使百姓能够休养生息，国泰民安，开创了中国历史上著名的贞观之治。对外开疆拓土，攻灭东突厥与薛延陀，征服高昌、龟兹、吐谷浑，重创高句丽，设立安西四镇，各民族融洽相处，被各族人民尊称为天可汗，为后来唐朝一百多年的盛世奠定重要基础。公元649年7月10日（贞观二十三年五月己巳日），李世民因病驾崩于含风殿，享年五十二岁，在位二十三年，庙号太宗，葬于昭陵。李世民爱好文学与书法，有墨宝传世。"},
                                                  {"ID":2,"FriendIcon":"head2","FriendName":"bbb撒旦","Content":"22222222222222222222"},
                                                  {"ID":3,"FriendIcon":"head3","FriendName":"钟宇翔","Content":"33333333333333333333"},
                                                  {"ID":4,"FriendIcon":"head4","FriendName":"ddd","Content":"444444444444444"},
                                                  {"ID":5,"FriendIcon":"head5","FriendName":"Jack black","Content":"555555555555555555555"},
                                                  {"ID":6,"FriendIcon":"head6","FriendName":"fff","Content":"666666666666666666666"},
                                                  {"ID":8,"FriendIcon":"head8","FriendName":"hhh","Content":"77777777777777777777777"},
                                                  {"ID":9,"FriendIcon":"head9","FriendName":"iii","Content":"你好你好你ssss好你好"},
                                                  {"ID":10,"FriendIcon":"head10","FriendName":"jjj","Content":"你好你好qq你好"},
                                                  {"ID":11,"FriendIcon":"head11","FriendName":"kkk","Content":"你好你好dd你好你好你好你好"},
                                                 ],
                  });

                       
        e4 = JSON.parse(e4);
        friend.Init_mail(e4);
        cc.log(userdata.mailInfo);          
        self.items.length = userdata.mailInfo.length;
        for (var i = 0; i < self.items.length; ++i) {
             var item = cc.instantiate(self.itemMailPrefab);
             self.items[i] = userdata.mailInfo[i];
             var data = self.items[i];
             self.node.addChild(item);
             item.getComponent('ItemMail').init({
                id: data.ID,
                title: "标题：来自"+self.IgnoreLongName(data.FriendName)+"..的邮件",
                iconSF: self.headAtlas.getSpriteFrame(data.FriendIcon),
            });
        
        }
    },

    //如果邮件标题中玩家姓名过长，自动省略从第4位开始的字符
    IgnoreLongName:function(longName){
       var self = this;
       var ignoreedName = longName.slice(0,3);;
       return ignoreedName;

    },

    //删除邮件按钮响应函数
    DeleteMail:function(){
        var self = this;
            //此处给服务器发送请求
            if(userdata.selectedMailID == null){
            cc.log("请先选择想删除的邮件.");
            }else{
                friend.Delete_mail(userdata.selectedMailID);
                cc.log(userdata.mailInfo);
                self.UpdateMailList();
                cc.log("列表邮件item数量:"+self.mailListContent.children.length);
            }
        
        userdata.selectedMailID = null;
    },

    //更新邮件列表
    UpdateMailList:function(){
        var self = this;
           self.mailListContent.removeChild(self.GetRemovedItem(userdata.selectedMailID));
    },

    //查看邮件具体内容按钮响应函数
    ReadMail:function(){
        var self = this;
        if(userdata.selectedMailID == null){
            cc.log("请先选择想查看的邮件.");
            }else{
                self.mailDetail.active = true;
                cc.log("mailID"+userdata.selectedMailID);
                for(var i = 0; i<userdata.mailInfo.length;++i){
                    var id = userdata.mailInfo[i].ID;
                    if( id == userdata.selectedMailID){
                        self.mailAddresser.string = "发件人："+userdata.mailInfo[i].FriendName;
                        self.mailDetailLabel.string = "\n"+"\n"+"邮件信息如下:"+"\n"+userdata.mailInfo[i].Content;
                    }
                }
            }
            cc.log(self.mailDetailLabel.string.length);
    },

    CloseMail:function(){
        var self = this;
        self.mailDetail.active = false;
        userdata.selectedMailID = null;
    },

    //确定要移除的item
    GetRemovedItem:function(mailID){
        var self = this;
        for(var i = 0;i<self.mailListContent.children.length;++i){
            var id = self.mailListContent.children[i].getChildByName("id").getComponent(cc.Label).string;
            if( id == mailID){
                return self.mailListContent.children[i];
            }
        }
    },

    //标记当前点击的邮件
    SignSelectedFriend:function(){
        var self = this;
        for(var i = 0;i<self.mailListContent.children.length;++i){
            var id = self.mailListContent.children[i].getChildByName("id").getComponent(cc.Label).string;
            if( id == userdata.selectedMailID){
                self.mailListContent.children[i].getChildByName("selecting").active = true;
            }else{
                self.mailListContent.children[i].getChildByName("selecting").active = false;
            }
        } 
    },

    //更新邮件内容的高度
    UpdateMailHeight:function(){
        var self = this;
        var count = Math.round(self.mailDetailLabel.string.length/22);
        self.mailDetailContent.height = 200+　count*35;
    },
    
    // called every frame, uncomment this function to activate update callback
    update: function (dt) {
        var self = this;
        self.mailListContent.height = 230 +　userdata.mailInfo.length*60;
        self.SignSelectedFriend();
        self.UpdateMailHeight();
    },
});
