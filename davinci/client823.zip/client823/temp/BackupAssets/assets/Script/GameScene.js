var http = require('HttpUtils');
var userdata = require('UserData');
var cardactivity=require('CardActivity');
cc.Class({
    extends: cc.Component,

    properties: {
        holdCards_2:{//2人游戏卡牌
            default:null,
            type:cc.Node
        },
         holdCards_3:{//3人游戏卡牌
            default:null,
            type:cc.Node
        },
        holdCards_4:{//4人游戏卡牌
            default:null,
            type:cc.Node
        },
        guess:{//猜牌弹出框
            default:null,
            type:cc.Node
        },
        guessbg:{//猜牌弹出框的背景
            default:null,
            type:cc.Node   
        },
        guessPointDisplay:{//猜牌弹出框上的显示的猜牌点数
            default:null,
            type:cc.EditBox             
        },
        playersNum:null,
        myCards:null,
        rightCards:null,
        oppositeCards:null,
        leftCards:null,
        side:null,
        url:null,//服务器ip
        guess_suit:null,//所猜牌的颜色
        guess_posi:null,//所猜牌的位置
        guess_point:null,//所猜的点数
        isepoll:null,//用来决定是否轮询
        myHolds:null,
        rightHolds:null,
        oppositeHolds:null,
        leftHolds:null,
    },

    // use this for initialization
    onLoad: function () {
        var self=this;
        self.url="http://192.168.0.232:8080/test";
        self.OnlineEpoll();
        self.myCards=[];
        self.rightCards=[];
        self.oppositeCards=[];
        self.leftCards=[];
        self.bool1=false;
        self.bool2=false;
        userdata.guessedcard=new Map();
        self.holdCards_2.active = false;
        self.holdCards_3.active = false;
        self.holdCards_4.active = false;
        self.playersNum = 4;//默认4人游戏
        if(self.playersNum == 4){
            self.holdCards_4.active = true;
            this.InitView();//初始化场景
            this.InitCards();//4人游戏开始，发牌
            this.DealCards();//4人游戏开始，发牌
        }
        if(userdata.ftplayer===userdata.mseat){
                    self.isepoll=false;
                }else{
                    self.isepoll=true;
                }
        self.ResultEpoll(self.isepoll);
    },

    //在线轮询
    OnlineEpoll:function(){
        var self=this;
        var online_sdmes=JSON.stringify({Id:userdata.id,
                    "Content":{"Type":10018}});
        var content="msg="+online_sdmes;
        http.HttpPost(self.url,content,function(online_rvmes){
            if (online_rvmes === -1) {
                //console.log("请检查网络");
            }else{
                var rv=JSON.parse(online_rvmes);
                if(rv.Type===10020){
                    cc.log("online");
                    setTimeout(function(){
                        self.OnlineEpoll();
                    },15000);
                }
            }
        })
    },

    //轮询结果
    ResultEpoll:function(e){
        var self=this;
        if(e){
            var result_sdmes=JSON.stringify({Id:userdata.id,
                    "Content":{"Type":10025}});
            var content="msg="+result_sdmes;
            http.HttpPost(self.url,content,function(result_mes){
            if (result_mes === -1) {
            }else{
                cc.log("轮询");
                var result_rvmes=JSON.parse(result_mes);
                cc.log(result_rvmes);
                if(result_rvmes.Type===10024){
                    setTimeout(function(){
                        self.ResultEpoll(self.isepoll);//猜牌方并没有猜牌继续轮询
                    },2000);
                }else if(result_rvmes.Type===10023){
                        cardactivity.GuessResult(result_rvmes);
                        switch(result_rvmes.Result){
                            case true:
                                self.MingBrang(userdata.guessedman,userdata.guessedcard,userdata.guessedcard.posi);
                                self.RoundChange();
                                break;
    
                            case false:
                                self.MingBrang(userdata.ftplayer,userdata.tcard,7);
                                cc.log("123456");
                                self.InsertCards();
                                setTimeout(function(){
                                    cardactivity.Insert_card();
                                    self.UpdateCardsInfo();
                                    self.RoundChange();
                                },2000);

                                break;
                        }
                    }
                }
            });
        }
    },

    //回合切换
    RoundChange:function(){
        var self=this;
        var round_sdmes=JSON.stringify({Id:userdata.id,
                    "Content":{"Type":10028}});
        var content="msg="+round_sdmes;
        http.HttpPost(self.url,content,function(round_mes){
            if (round_mes === -1) {
            }else{
                var round_rvmes=JSON.parse(round_mes);
                cc.log(round_rvmes);
                if(round_rvmes.Type===10029){
                    setTimeout(function(){
                        self.ResultEpoll(self.isepoll);//猜牌方继续猜牌继续轮询结果
                    },1000);
                }else if(round_rvmes.Type===10030){
                    userdata.ftplayer=round_rvmes.Touchp;
                    cardactivity.Tcard(round_rvmes.Tcard);
                    self.DealCards();
                    if(userdata.ftplayer===userdata.mseat){
                        self.isepoll=false;
                    }
                    setTimeout(function(){
                        self.ResultEpoll(self.iseopll);//不是猜牌方将继续轮询结果；是猜牌方时将失效
                    },2000);
                }
            }
        });
    },

    //初始化场景
    InitView:function(){
        var self = this;
        //搜索需要的子节点
        var holdCardsChild = this.node.getChildByName("num_4");
        self.myHolds = holdCardsChild.getChildByName("player1_cards");//自己的手牌
        self.rightHolds = holdCardsChild.getChildByName("player2_cards");//右边的手牌
        self.oppositeHolds = holdCardsChild.getChildByName("player3_cards");//对面的手牌
        self.leftHolds = holdCardsChild.getChildByName("player4_cards");//左边的手牌
        
        for(var i = 0; i < self.myHolds.children.length; ++i){
            self.myHolds.children[i].active = false;
        }
        for(var i = 0; i < self.rightHolds.children.length; ++i){
            self.rightHolds.children[i].active = false;
        }
        for(var i = 0; i < self.oppositeHolds.children.length; ++i){
            self.oppositeHolds.children[i].active = false;
        }
        for(var i = 0; i < self.leftHolds.children.length; ++i){
            self.leftHolds.children[i].active = false;
        }                               
    },

    //4人游戏开始，发牌
    InitCards:function() {
        var self = this;   
        //发自己的牌，开始只有4张牌
        for(var i = 0;i < 3; i++){
             self.myHolds.children[i].active = true;
             var sprite = self.myHolds.children[i].getComponent(cc.Sprite);
             self.SetSpriteFrameByCardID("M_",userdata.mcard.get(i).suit,userdata.mcard.get(i).point,sprite);//我方的牌如实显示
             self.SetCardsInfo(self.myCards,i,userdata.mcard.get(i));
        }
       
        //发右边的牌，开始只有4张牌
        for(var i = 0;i < 3; i++){
             self.rightHolds.children[i].active = true;
             var sprite = self.rightHolds.children[i].getComponent(cc.Sprite);
             self.SetSpriteFrameByCardID("R_",userdata.rcard.get(i).suit,13,sprite); //右边的牌显示为未知的
             self.SetCardsInfo(self.rightCards,i,userdata.rcard.get(i));//存储右边卡牌信息
             self.GuessCards(sprite.node);//猜右边的牌
        }
        //发对面的牌，开始只有4张牌
        for(var i = 0;i < 3; i++){
             self.oppositeHolds.children[i].active = true;
             var sprite = self.oppositeHolds.children[i].getComponent(cc.Sprite);
             self.SetSpriteFrameByCardID("O_",userdata.ocard.get(i).suit,13,sprite); //对面的牌显示为未知的
             self.SetCardsInfo(self.oppositeCards,i,userdata.ocard.get(i));//存储对面卡牌信息
             self.GuessCards(sprite.node);//猜对面的牌
        }
        //发左边的牌，开始只有4张牌
        for(var i = 0;i < 3; i++){
             self.leftHolds.children[i].active = true;
             var sprite = self.leftHolds.children[i].getComponent(cc.Sprite);
             self.SetSpriteFrameByCardID("L_",userdata.lcard.get(i).suit,13,sprite); //左边的牌显示为未知的
             self.SetCardsInfo(self.leftCards,i,userdata.lcard.get(i));//存储左边卡牌信息
             self.GuessCards(sprite.node); //猜左边的牌
        }                        
    },

     //4人游戏开始，摸牌
    DealCards:function(){
        var self = this;
        var tcardLocation = self.myHolds.children.length - 1;

        if(userdata.mseat === userdata.ftplayer){//如果当前客户端玩家是摸牌方
            self.myHolds.children[7].active = true;
            var sprite = self.myHolds.children[7].getComponent(cc.Sprite);
            self.SetSpriteFrameByCardID("M_",userdata.mcard.get(userdata.mcard.size-1).suit,
                                        userdata.mcard.get(userdata.mcard.size-1).point,sprite);
            self.SetCardsInfo(self.myCards,userdata.mcard.size-1,userdata.mcard.get(userdata.mcard.size-1));//存储摸的牌的信息
        }else if(userdata.rseat === userdata.ftplayer){//如果当前客户端玩家的右边是摸牌方
                self.rightHolds.children[7].active = true;
                var sprite = self.rightHolds.children[7].getComponent(cc.Sprite);
                self.SetSpriteFrameByCardID("R_",userdata.tcard.suit,13,sprite);
        }else if(userdata.oseat === userdata.ftplayer){//如果当前客户端玩家的对面是摸牌方
                self.oppositeHolds.children[7].active = true;
                var sprite = self.oppositeHolds.children[7].getComponent(cc.Sprite);
                self.SetSpriteFrameByCardID("O_",userdata.tcard.suit,13,sprite);
        }else if(userdata.lseat === userdata.ftplayer){//如果当前客户端玩家的左边是摸牌方
                self.leftHolds.children[7].active = true;
                var sprite = self.leftHolds.children[7].getComponent(cc.Sprite);
                self.SetSpriteFrameByCardID("L_",userdata.tcard.suit,13,sprite);
        }   
    },
   
    //4人游戏开始，猜牌
    GuessCards:function(node){
        var self = this;
       
        node.on(cc.Node.EventType.TOUCH_START, function (event) {
            console.log("点击开始cc.Node.EventType.TOUCH_START");
            if (node.parent === self.myHolds) {
                return;
            }
            node.interactable = node.getComponent(cc.Button).interactable;
            if (!node.interactable) {
                return;
            }
            self.guess.active = true;//让猜牌框出现
            self.guessbg.on('touchstart', self.EatTouch, self);//触摸吞噬
            self.guessPointDisplay.string = "0";//猜牌点数初始显示为0；
            self.GetGuessedman(node);//获取点击的牌的对手座位
            cc.log("点击的卡片的点数，颜色，位置："+self.GetCardsInfo(node).point+
            ","+self.GetCardsInfo(node).suit+","+self.GetCardsInfo(node).posi);
            self.guess_suit = self.GetCardsInfo(node).suit;
            self.guess_posi = self.GetCardsInfo(node).posi;
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_Move, function (event) {
            console.log("cc.Node.EventType.TOUCH_MOVE");
            if (node.parent === self.myHolds) {
                cc.log("不能点");
                return;
            }
            if (!node.interactable) {
                cc.log("不能点");
                return;
            }
            if (Math.abs(event.getDeltaX()) + Math.abs(event.getDeltaY()) < 0.5) {
                return;
            }
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_END, function (event) {
            if (node.parent === self.myHolds) {
                return;
            }
            if (!node.interactable) {
                return;
            }
            console.log("\n点击结束cc.Node.EventType.TOUCH_END");
        }.bind(this));

        node.on(cc.Node.EventType.TOUCH_CANCEL, function (event) {
            if (node.parent === self.myHolds) {
                cc.log("不能点");
                return;
            }
            if (!node.interactable) {
                cc.log("不能点");
                return;
            }
            console.log("cc.Node.EventType.TOUCH_CANCEL");
        }.bind(this));            
    },

    //插牌动作模板
    Template_insert:function(map,seatHolds){
        var self=this;
        var cardlength=map.size;
        seatHolds.children[cardlength-1].active = true;

        //然后遍历卡牌数组，将摸的牌移动到正确位置.移动次数是卡牌数组长度减去摸的牌的正确位
        self.ExchangeCard1(seatHolds.children[cardlength-1], seatHolds.children[map.get(cardlength-1).posi-1]);
        for(var i = map.get(cardlength-1).posi; i < cardlength; i++){
                self.ExchangeCard1(seatHolds.children[i-1],seatHolds.children[i]);
        }
        self.ExchangeIndex(seatHolds,cardlength,map.get(cardlength-1).posi);
        setTimeout(function() {
            self.ExchangeCard2(seatHolds.children[seatHolds.children.length-1],seatHolds.children[map.get(cardlength-1).posi-1]);
            //seatHolds.children[seatHolds.children.length-1].active = false;
        }, 520);

    },
    //4人游戏开始，在猜牌后，插牌
    InsertCards:function(){
        var self = this;
        var tcardLocation = self.myHolds.children.length - 1;

        if(userdata.mseat === userdata.ftplayer){//如果当前客户端玩家是摸牌方
            self.Template_insert(userdata.mcard,self.myHolds);
        }else if(userdata.rseat === userdata.ftplayer){//如果当前客户端右边玩家是摸牌方
            self.Template_insert(userdata.rcard,self.rightHolds);
        }else if(userdata.oseat === userdata.ftplayer){//如果当前客户端对面玩家是摸牌方
            self.Template_insert(userdata.ocard,self.oppositeHolds);
        }else if(userdata.lseat === userdata.ftplayer){//如果当前客户端左边玩家是摸牌方
            self.Template_insert(userdata.lcard,self.leftHolds);
        }                                 
    },
     //设置卡牌图片函数
    SetSpriteFrameByCardID :function(pre,color,cardId,sprite){
        var cardmgr = this.node.getComponent("CardMgr");
        sprite.spriteFrame = cardmgr.getSpriteFrameByCardID(pre,color,cardId);
    },
     
    //存储卡牌信息
    SetCardsInfo:function(myCards,//存储卡牌信息的数组
                          index,//卡牌对应node在手牌中的位置
                          oneCard,//从服务器接受到的卡牌信息
        ){  var self = this;
        myCards[index] = oneCard;
    },

    //提取卡牌信息
    GetCardsInfo:function(node){
        var self = this;
        for(var i = 0; i < self.myHolds.children.length; ++i){
            if(node === self.myHolds.children[i]){
                if(i == self.myHolds.children.length-1){//如果想获取摸得牌的信息
                    return self.myCards[userdata.mcard.size-1];//那么返回数组的最后一个
                }
               return self.myCards[i];
            }
         }
        for(var i = 0; i < self.rightHolds.children.length; ++i){
            if(node === self.rightHolds.children[i])
               if(i == self.rightHolds.children.length-1){//如果想获取摸得牌的信息
                    return self.rightCards[userdata.rcard.size-1];//那么返回数组的最后一个
                }
               return self.rightCards[i];
         }
        for(var i = 0; i < self.oppositeHolds.children.length; ++i){
            if(node === self.oppositeHolds.children[i])
               if(i == self.oppositeHolds.children.length-1){//如果想获取摸得牌的信息
                    return self.oppositeCards[userdata.ocard.size-1];//那么返回数组的最后一个
                }            
               return self.oppositeCards[i];
         }
        for(var i = 0; i < self.leftHolds.children.length; ++i){
            if(node === self.leftHolds.children[i])
               if(i == self.leftHolds.children.length-1){//如果想获取摸得牌的信息
                    return self.leftCards[userdata.lcard.size-1];//那么返回数组的最后一个
                }            
               return self.leftCards[i];
         }                           
    },

    //点击猜牌浮框上的确定键，发送所猜的牌
    GuessConfirm:function(){
        var self=this;
        //所猜的卡牌信息
        
        var card = JSON.stringify({CardPoint:self.guess_point,
                                   CardSuit:self.guess_suit,
                                   Position:self.guess_posi,
        });
        card = JSON.parse(card); 
        //加上猜的命令10022和所猜人位置seat       
        var content = JSON.stringify({Type:10022,
                                      Seat:userdata.guessedman,
                                      Card:card,                         
        });
        content = JSON.parse(content);
        //加上客户端session号id
        var guess_sdmes = JSON.stringify({Id:userdata.id,
                                      Content:content,
        });
        guess_sdmes = "msg="+guess_sdmes;
        cc.log("发送猜牌信息："+guess_sdmes);
        
        http.HttpPost(self.url,guess_sdmes,function(guess_rvmes){
            if (guess_rvmes === -1) {
            }else{
                guess_rvmes=JSON.parse(guess_rvmes);
                cc.log(guess_rvmes);
                cardactivity.GuessResult(guess_rvmes);
                if(guess_rvmes.Type===10023){
                    switch(guess_rvmes.Result){
                            case true:
                                self.MingBrang(userdata.guessedman,userdata.guessedcard,userdata.guessedcard.posi);
                                self.RoundChange();
                                break;
    
                            case false:
                                cc.log("456789");
                                self.MingBrang(userdata.mseat,userdata.mcard.get(userdata.mcard.size-1),self.myHolds.children.length);
                                self.InsertCards();
                                setTimeout(function(){
                                    cardactivity.Insert_card();
                                    self.UpdateCardsInfo();
                                    self.RoundChange();
                                },2000);
                                break;
                        }
                }
            }
        })
        self.guess.active = false;
    },

    //点击猜牌浮框上的叉键，取消猜牌，关闭猜牌浮框
    GuessCancel:function(){
        var self = this;
        self.guess.active = false;
    },

    //触摸吞噬
    EatTouch:function(event){
        cc.log('EatTouch');
	    event.stopPropagation();
    },

    //点击猜牌浮框上的加号键，增加猜牌点数
    AddGuessPoint:function(){
        var self = this;
        var a = 0;
        if(self.guessPointDisplay.string == "万能"){
            a = 12;      
        }else{
            a = parseInt(self.guessPointDisplay.string);
        }
        a++;
        if(a<=0){
           a= 0;
        }
        if(a>=12){
           a = 12; 
        }
        self.guess_point = a;
        if(a == 12)
        {
          self.guessPointDisplay.string = "万能";  
        }else{
          self.guessPointDisplay.string = a.toString();
        }
    },

    //点击猜牌浮框上的减号键，减少猜牌点数
    ReduceGuessPoint:function(){
        var self = this;
        var a = 0;
        if(self.guessPointDisplay.string == "万能"){
            a = 12;      
        }else{
            a = parseInt(self.guessPointDisplay.string);
        }
        a--;
        if(a<=0){
           a= 0;
        }
        if(a>=12){
           a = 12; 
        }
        self.guess_point = a;
        if(a == 12)
        {
          self.guessPointDisplay.string = "万能";  
        }else{
          self.guessPointDisplay.string = a.toString();
        }        
    },

    //明牌效果
    MingBrang:function(seat,carddata,pos){
        var self=this;
        if(seat===userdata.mseat){
            // var ss=cc.loader.removeItem(carddata.point);
            // self.myHolds.children[pos-1].runAction(ss);
            var tag=self.myHolds.children[pos-1].getChildByName("MingTag");
            tag.active=true;
        }else if(seat === userdata.rseat){
            var sprite = self.rightHolds.children[pos-1].getComponent(cc.Sprite);
            self.SetSpriteFrameByCardID("R_",carddata.suit,carddata.point,sprite);
            var tag=self.rightHolds.children[pos-1].getChildByName("MingTag");
            tag.active=true;
        }else if(seat ===userdata.oseat){
            var sprite = self.oppositeHolds.children[pos-1].getComponent(cc.Sprite);
            self.SetSpriteFrameByCardID("O_",carddata.suit,carddata.point,sprite);
            var tag=self.oppositeHolds.children[pos-1].getChildByName("MingTag");
            tag.active=true;
        }else if(seat === userdata.lseat){
            var sprite = self.leftHolds.children[pos-1].getComponent(cc.Sprite);
            self.SetSpriteFrameByCardID("L_",carddata.suit,carddata.point,sprite);
            var tag=self.leftHolds.children[pos-1].getChildByName("MingTag");
            tag.active=true;
        }

    },

    //获取被猜牌人的座位
    GetGuessedman:function(node){
        var self=this;
        if(node.parent === self.rightHolds){
            userdata.guessedman = userdata.rseat;
        }else if(node.parent ===self.oppositeHolds){
                userdata.guessedman = userdata.oseat;
        }else if(node.parent === self.leftHolds){
                userdata.guessedman = userdata.lseat;
        }        
    },
    
    //交换牌的位置和信息
    ExchangeCard1:function(node1,node2){
        var move2=cc.moveTo(0.5,cc.p(node2.getPositionX(),node2.getPositionY()));
        node1.runAction(move2);    
    },
    ExchangeCard2:function(node1,node2){
        var move1=cc.moveTo(0.5,cc.p(node2.getPositionX(),node2.getPositionY()));
        node1.runAction(move1); 
        var move2=cc.moveTo(0.5,cc.p(node1.getPositionX(),node1.getPositionY()));
        node2.runAction(move2);    
    },
    ExchangeIndex:function(holds,cardsLength,posi){
        setTimeout(function() {
            for(var i = cardsLength;i > posi; i--){
                [holds.children[i-1],holds.children[i-2]]=[holds.children[i-2],holds.children[i-1]];
            }
        }, 503);
        setTimeout(function() {
            [holds.children[holds.children.length-1],holds.children[posi-1]]=[holds.children[posi],holds.children[holds.children.length-1]];       
        }, 1500);
    },
    //插牌后，更新卡牌数组的信息
    UpdateCardsInfo:function(){
        //如果当前客户端玩家是摸牌方
        if(userdata.mseat === userdata.ftplayer){
            for(var i in userdata.mcard){
                self.myCards[i] = userdata.mcard.get(i);
            }
        }
        if(userdata.rseat === userdata.ftplayer){
            for(var i in userdata.rcard){
                self.rightCards[i] = userdata.rcard.get(i);
            }
        }
        if(userdata.oseat === userdata.ftplayer){
            for(var i in userdata.ocard){
                self.oppositeCards[i] = userdata.ocard.get(i);
            }
        }
        if(userdata.lseat === userdata.ftplayer){
            for(var i in userdata.lcard){
                self.leftCards[i] = userdata.lcard.get(i);
            }
        }                        
    },
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
