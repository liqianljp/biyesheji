//储存卡牌信息
var userdata = require('UserData');
module.exports={
    //初始化函数模板，根据信息初始化卡牌信息，并储存在对应map里面，通用这一个函数初始化
    Init_card:function(cards,map){
        for(var x in cards){
            var card=new Map();
            card.point=cards[x].CardPoint;
            card.suit=cards[x].CardSuit;
            card.posi=cards[x].Position;
            map.set(parseInt(x),card);
        }
    },

    //查找座位对应的OppPlayer下标
    GetSeat:function(seats,e){
        for(var x in e){
            if(e[x].Seat===seats){
                return x;
                //break;
            }
        }
    },

    //两玩家对战时初始函数
    Init_two_players:function(mcards,ocards){
        userdata.mcard=new Map();
        userdata.ocard=new Map();
        this.Init_card(mcards,userdata.mcard);
        this.Init_card(ocards,userdata.ocard);

    },
    //三玩家对战时初始函数
    Init_three_players:function(mcards,lcards,rcards){
        userdata.mcard=new Map();
        userdata.lcard=new Map();
        userdata.rcard=new Map();
        this.Init_card(mcards,userdata.mcard);
        this.Init_card(lcards,userdata.lcard);
        this.Init_card(rcards,userdata.rcard);

    },

    //初始化四人对局时对手信息以及卡牌信息
    Init_four_opp:function(e){
        var r=this.GetSeat(userdata.rseat,e);
            this.Init_card(e[r].Card,userdata.rcard);
            userdata.rname=e[r].Uid;
            userdata.rgrade=e[r].Grade;
        var l=this.GetSeat(userdata.lseat,e);
            this.Init_card(e[l].Card,userdata.lcard);
            userdata.lname=e[l].Uid;
            userdata.lgrade=e[l].Grade;
        var o=this.GetSeat(userdata.oseat,e);
            this.Init_card(e[o].Card,userdata.ocard);
            userdata.oname=e[o].Uid;
            userdata.ograde=e[o].Grade;
    },
    //四玩家对战时初始函数
    Init_four_players:function(e){
        userdata.mcard=new Map();
        userdata.ocard=new Map();
        userdata.lcard=new Map();
        userdata.rcard=new Map();
        userdata.mseat=parseInt(e.Mseat);
        this.Init_card(e.Mcard,userdata.mcard);

        //根据我的座位固定对手座位
        if(userdata.mseat===1){
            userdata.rseat=2;
            userdata.oseat=3;
            userdata.lseat=4;
            this.Init_four_opp(e.OppPlayer);
        }else if(userdata.mseat===2){
            userdata.rseat=3;
            userdata.oseat=4;
            userdata.lseat=1;
            this.Init_four_opp(e.OppPlayer);
        }else if(userdata.mseat===3){
            userdata.rseat=4;
            userdata.oseat=1;
            userdata.lseat=2;
            this.Init_four_opp(e.OppPlayer);
        }else if(userdata.mseat===4){
            userdata.rseat=1;
            userdata.oseat=2;
            userdata.lseat=3;
            this.Init_four_opp(e.OppPlayer);
        }
        userdata.ftplayer=e.Touchp;
        this.Tcard(e.Tcard);
    },


    //作为猜牌方的时候单摸一张卡牌,非猜牌方时记录猜牌人单摸牌颜色
    Tcard:function(tcard){
        if(userdata.ftplayer===userdata.mseat){
            var mcard_length=userdata.mcard.size;
                var card=new Map();
                card.point=tcard.CardPoint;
                card.suit=tcard.CardSuit;
                card.posi=tcard.Position;
                userdata.mcard.set(parseInt(mcard_length),card);
        }else{
            userdata.tsuit=tcard.CardSuit;
        }
    },

};
