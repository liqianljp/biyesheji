cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        label1: {
            default: null,
            type: cc.Node
        },
        label2: {
            default: null,
            type: cc.Node
        },
         startGame: {
            default: null,
            type: cc.Node
        },
    },

    // use this for initialization
    onLoad: function () {
      this.label1.getComponent(cc.Animation).play('label1_moveright');
      this.label2.getComponent(cc.Animation).play('label2_moveright');
      this.startGame.getComponent(cc.Animation).play('startGame_moveright');
      
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
